/**
 * Database operations for trust score system
 */

import { getDb } from "./db";
import { prices, priceVerificationLogs } from "../drizzle/schema";
import { calculateTrustScore, isPriceValid, TrustScoreResult } from "./trust";
import { eq, and, desc } from "drizzle-orm";

/**
 * Update trust score for a price record
 */
export async function updatePriceTrustScore(
  priceId: number,
  productId: number,
  trustResult: TrustScoreResult,
  previousTrustScore: number | null
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get current price before update
  const currentPrice = await db
    .select()
    .from(prices)
    .where(eq(prices.id, priceId))
    .limit(1);

  if (!currentPrice.length) {
    throw new Error(`Price record not found: ${priceId}`);
  }

  const current = currentPrice[0];

  // Update price with new trust score
  await db
    .update(prices)
    .set({
      trustScore: trustResult.trustScore,
      trustLevel: trustResult.trustLevel,
      verificationStatus: trustResult.verificationStatus,
      flags: trustResult.flags.length > 0 ? JSON.stringify(trustResult.flags) : null,
      lastVerified: new Date(),
    })
    .where(eq(prices.id, priceId));

  // Log the change
  await db.insert(priceVerificationLogs).values({
    priceId,
    productId,
    previousPrice: current.price,
    newPrice: current.price,
    previousTrustScore: previousTrustScore || current.trustScore,
    newTrustScore: trustResult.trustScore,
    changeReason: "trust_score_update",
    verifiedBy: "system",
  });
}

/**
 * Get all prices for a product with trust info
 */
export async function getPricesWithTrust(productId: number) {
  const db = await getDb();
  if (!db) return [];

  const productPrices = await db
    .select()
    .from(prices)
    .where(eq(prices.productId, productId))
    .orderBy(desc(prices.lastUpdated));

  return productPrices.map((p) => ({
    ...p,
    sources: p.sources ? JSON.parse(p.sources as string) : [],
    flags: p.flags ? JSON.parse(p.flags as string) : [],
    isValid: isPriceValid(p.trustScore, p.verificationStatus),
  }));
}

/**
 * Get the best (most trusted) price for a product
 */
export async function getBestTrustedPrice(productId: number) {
  const allPrices = await getPricesWithTrust(productId);

  // Filter to only valid prices
  const validPrices = allPrices.filter((p) => p.isValid);

  if (validPrices.length === 0) {
    return null;
  }

  // Sort by trust score (descending), then by price (ascending)
  return validPrices.sort((a: any, b: any) => {
    if (b.trustScore !== a.trustScore) {
      return b.trustScore - a.trustScore;
    }
    return a.price - b.price;
  })[0];
}

/**
 * Flag prices that need manual review
 */
export async function getFlaggedPrices(limit = 50) {
  const db = await getDb();
  if (!db) return [];

  const flagged = await db
    .select()
    .from(prices)
    .where(eq(prices.verificationStatus, "FLAGGED"))
    .orderBy(desc(prices.trustScore))
    .limit(limit);

  return flagged.map((p: any) => ({
    ...p,
    sources: p.sources ? JSON.parse(p.sources as string) : [],
    flags: p.flags ? JSON.parse(p.flags as string) : [],
  }));
}

/**
 * Get low confidence prices (trust score < 70)
 */
export async function getLowConfidencePrices(limit = 50) {
  const db = await getDb();
  if (!db) return [];

  const lowConfidence = await db
    .select()
    .from(prices)
    .where(
      and(
        // @ts-ignore - drizzle comparison with number
        prices.trustScore < 70
      )
    )
    .orderBy(prices.trustScore)
    .limit(limit);

  return lowConfidence.map((p: any) => ({
    ...p,
    sources: p.sources ? JSON.parse(p.sources as string) : [],
    flags: p.flags ? JSON.parse(p.flags as string) : [],
  }));
}

/**
 * Get stale prices (not updated in > 6 hours)
 */
export async function getStalePrices(limit = 50) {
  const db = await getDb();
  if (!db) return [];

  const sixHoursAgo = new Date(Date.now() - 6 * 60 * 60 * 1000);

  const stale = await db
    .select()
    .from(prices)
    .where(
      and(
        // @ts-ignore - drizzle date comparison
        prices.lastUpdated < sixHoursAgo
      )
    )
    .orderBy(prices.lastUpdated)
    .limit(limit);

  return stale.map((p: any) => ({
    ...p,
    sources: p.sources ? JSON.parse(p.sources as string) : [],
    flags: p.flags ? JSON.parse(p.flags as string) : [],
  }));
}

/**
 * Get verification statistics
 */
export async function getVerificationStats() {
  const db = await getDb();
  if (!db) return null;

  const allPrices = await db.select().from(prices);

  const stats = {
    total: allPrices.length,
    verified: allPrices.filter((p: any) => p.verificationStatus === "VERIFIED").length,
    unverified: allPrices.filter((p: any) => p.verificationStatus === "UNVERIFIED").length,
    flagged: allPrices.filter((p: any) => p.verificationStatus === "FLAGGED").length,
    highTrust: allPrices.filter((p: any) => p.trustLevel === "HIGH").length,
    mediumTrust: allPrices.filter((p: any) => p.trustLevel === "MEDIUM").length,
    lowTrust: allPrices.filter((p: any) => p.trustLevel === "LOW").length,
    averageTrustScore: Math.round(
      allPrices.reduce((sum: number, p: any) => sum + p.trustScore, 0) / allPrices.length
    ),
  };

  return stats;
}
