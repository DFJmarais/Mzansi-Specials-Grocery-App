/**
 * SMS Phone Verification System
 * Sends OTP codes via Twilio for phone verification
 */

import { sendSMS, sendWhatsApp } from './twilio-service';

interface VerificationCode {
  phoneNumber: string;
  code: string;
  expiresAt: Date;
  attempts: number;
  verified: boolean;
}

// Store verification codes in memory (in production, use database)
const verificationStore = new Map<string, VerificationCode>();

/**
 * Generate random 6-digit OTP code
 */
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Send verification code via SMS
 */
export async function sendVerificationSMS(phoneNumber: string): Promise<boolean> {
  try {
    const code = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store verification code
    verificationStore.set(phoneNumber, {
      phoneNumber,
      code,
      expiresAt,
      attempts: 0,
      verified: false,
    });

    const message = `Your Mzansi Specials verification code is: ${code}\n\nThis code expires in 10 minutes.\n\nDo not share this code with anyone.`;

    console.log(`[SMS Verification] Sending OTP to ${phoneNumber}`);
    return await sendSMS(phoneNumber, message);
  } catch (error) {
    console.error('[SMS Verification] Error sending SMS:', error);
    return false;
  }
}

/**
 * Send verification code via WhatsApp
 */
export async function sendVerificationWhatsApp(phoneNumber: string): Promise<boolean> {
  try {
    const code = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store verification code
    verificationStore.set(phoneNumber, {
      phoneNumber,
      code,
      expiresAt,
      attempts: 0,
      verified: false,
    });

    const message = `🔐 Your Mzansi Specials verification code is: *${code}*\n\nThis code expires in 10 minutes.\n\n⚠️ Do not share this code with anyone.`;

    console.log(`[WhatsApp Verification] Sending OTP to ${phoneNumber}`);
    return await sendWhatsApp(phoneNumber, message);
  } catch (error) {
    console.error('[WhatsApp Verification] Error sending WhatsApp:', error);
    return false;
  }
}

/**
 * Verify OTP code
 */
export function verifyOTP(phoneNumber: string, code: string): boolean {
  try {
    const verification = verificationStore.get(phoneNumber);

    if (!verification) {
      console.log(`[SMS Verification] No verification record for ${phoneNumber}`);
      return false;
    }

    // Check if code has expired
    if (new Date() > verification.expiresAt) {
      console.log(`[SMS Verification] Code expired for ${phoneNumber}`);
      verificationStore.delete(phoneNumber);
      return false;
    }

    // Check attempts
    if (verification.attempts >= 3) {
      console.log(`[SMS Verification] Too many attempts for ${phoneNumber}`);
      verificationStore.delete(phoneNumber);
      return false;
    }

    // Check code
    if (verification.code !== code) {
      verification.attempts++;
      console.log(`[SMS Verification] Invalid code for ${phoneNumber} (attempt ${verification.attempts})`);
      return false;
    }

    // Mark as verified
    verification.verified = true;
    console.log(`[SMS Verification] ✓ Phone verified: ${phoneNumber}`);
    return true;
  } catch (error) {
    console.error('[SMS Verification] Error verifying OTP:', error);
    return false;
  }
}

/**
 * Check if phone is verified
 */
export function isPhoneVerified(phoneNumber: string): boolean {
  const verification = verificationStore.get(phoneNumber);
  return verification?.verified || false;
}

/**
 * Get verification status
 */
export function getVerificationStatus(phoneNumber: string): {
  verified: boolean;
  expiresAt?: Date;
  attemptsRemaining?: number;
} {
  const verification = verificationStore.get(phoneNumber);

  if (!verification) {
    return { verified: false };
  }

  return {
    verified: verification.verified,
    expiresAt: verification.expiresAt,
    attemptsRemaining: Math.max(0, 3 - verification.attempts),
  };
}

/**
 * Clear verification code
 */
export function clearVerification(phoneNumber: string): void {
  verificationStore.delete(phoneNumber);
  console.log(`[SMS Verification] Cleared verification for ${phoneNumber}`);
}

/**
 * Send welcome message after verification
 */
export async function sendWelcomeMessage(
  phoneNumber: string,
  userName: string,
  channel: 'sms' | 'whatsapp' = 'whatsapp'
): Promise<boolean> {
  const message = `Welcome to Mzansi Specials, ${userName}! 🎉\n\nYou'll now receive price alerts and exclusive deals via WhatsApp.\n\nStart saving on groceries today!`;

  if (channel === 'sms') {
    return await sendSMS(phoneNumber, message);
  } else {
    return await sendWhatsApp(phoneNumber, message);
  }
}

/**
 * Send daily deals digest
 */
export async function sendDailyDealsDigest(
  phoneNumber: string,
  deals: Array<{ productName: string; retailer: string; price: number; discount: number }>,
  channel: 'sms' | 'whatsapp' = 'whatsapp'
): Promise<boolean> {
  const dealsText = deals
    .slice(0, 5)
    .map((d) => `• ${d.productName} @ ${d.retailer} - R${d.price.toFixed(2)} (${d.discount}% off)`)
    .join('\n');

  const message = `📬 Today's Hot Deals!\n\n${dealsText}\n\nShop now on Mzansi Specials!`;

  if (channel === 'sms') {
    return await sendSMS(phoneNumber, message);
  } else {
    return await sendWhatsApp(phoneNumber, message);
  }
}

/**
 * Test verification system
 */
export async function testVerificationSystem(): Promise<{ status: string; message: string }> {
  try {
    console.log('[SMS Verification] Testing verification system...');

    const testPhone = '+27604220217'; // Your test number
    const sent = await sendVerificationSMS(testPhone);

    if (!sent) {
      return {
        status: 'warning',
        message: 'SMS not sent - check Twilio credentials',
      };
    }

    return {
      status: 'success',
      message: 'Verification system is working - check your phone for OTP',
    };
  } catch (error) {
    console.error('[SMS Verification] Test failed:', error);
    return {
      status: 'error',
      message: 'Verification system test failed',
    };
  }
}
