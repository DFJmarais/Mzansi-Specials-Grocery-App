/**
 * Twilio Integration Service
 * Sends SMS and WhatsApp messages for price alerts and notifications
 */

import axios from 'axios';

const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID || 'ACd22b309ea828569cefd1a328039ccbd6';
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN || '';
const TWILIO_PHONE_NUMBER = process.env.TWILIO_PHONE_NUMBER || '+14155238886';
const TWILIO_API_URL = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}`;

interface TwilioMessage {
  to: string;
  body: string;
  mediaUrl?: string;
}

/**
 * Send SMS message via Twilio
 */
export async function sendSMS(to: string, message: string): Promise<boolean> {
  try {
    // Format phone number to international format
    const formattedTo = formatPhoneNumber(to);

    console.log(`[Twilio SMS] Sending to ${formattedTo}: ${message.substring(0, 50)}...`);

    const response = await axios.post(
      `${TWILIO_API_URL}/Messages.json`,
      new URLSearchParams({
        To: formattedTo,
        From: TWILIO_PHONE_NUMBER,
        Body: message,
      }),
      {
        auth: {
          username: TWILIO_ACCOUNT_SID,
          password: TWILIO_AUTH_TOKEN,
        },
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    console.log(`[Twilio SMS] ✓ Message sent: ${response.data.sid}`);
    return true;
  } catch (error) {
    console.error('[Twilio SMS] ✗ Error:', error);
    return false;
  }
}

/**
 * Send WhatsApp message via Twilio
 */
export async function sendWhatsApp(to: string, message: string): Promise<boolean> {
  try {
    // Format phone number to WhatsApp format
    const formattedTo = `whatsapp:${formatPhoneNumber(to)}`;
    const formattedFrom = `whatsapp:${TWILIO_PHONE_NUMBER}`;

    console.log(`[Twilio WhatsApp] Sending to ${formattedTo}: ${message.substring(0, 50)}...`);

    const response = await axios.post(
      `${TWILIO_API_URL}/Messages.json`,
      new URLSearchParams({
        To: formattedTo,
        From: formattedFrom,
        Body: message,
      }),
      {
        auth: {
          username: TWILIO_ACCOUNT_SID,
          password: TWILIO_AUTH_TOKEN,
        },
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      }
    );

    console.log(`[Twilio WhatsApp] ✓ Message sent: ${response.data.sid}`);
    return true;
  } catch (error) {
    console.error('[Twilio WhatsApp] ✗ Error:', error);
    return false;
  }
}

/**
 * Send price alert notification
 */
export async function sendPriceAlert(
  phoneNumber: string,
  productName: string,
  retailer: string,
  oldPrice: number,
  newPrice: number,
  discount: number,
  channel: 'sms' | 'whatsapp' | 'both' = 'whatsapp'
): Promise<boolean> {
  const savings = oldPrice - newPrice;
  const message = `🔥 Price Drop Alert!\n\n${productName}\n${retailer}\n\nWas: R${oldPrice.toFixed(2)}\nNow: R${newPrice.toFixed(2)}\nSave: R${savings.toFixed(2)} (${discount}% off)\n\nShop now on Mzansi Specials!`;

  let sent = false;

  if (channel === 'sms' || channel === 'both') {
    sent = await sendSMS(phoneNumber, message);
  }

  if (channel === 'whatsapp' || channel === 'both') {
    sent = await sendWhatsApp(phoneNumber, message);
  }

  return sent;
}

/**
 * Send deal notification
 */
export async function sendDealNotification(
  phoneNumber: string,
  productName: string,
  retailer: string,
  price: number,
  discount: number,
  channel: 'sms' | 'whatsapp' | 'both' = 'whatsapp'
): Promise<boolean> {
  const message = `🛍️ Hot Deal Alert!\n\n${productName}\n${retailer}\n\nPrice: R${price.toFixed(2)}\nDiscount: ${discount}% off\n\nAdd to your list on Mzansi Specials!`;

  let sent = false;

  if (channel === 'sms' || channel === 'both') {
    sent = await sendSMS(phoneNumber, message);
  }

  if (channel === 'whatsapp' || channel === 'both') {
    sent = await sendWhatsApp(phoneNumber, message);
  }

  return sent;
}

/**
 * Send weekly digest
 */
export async function sendWeeklyDigest(
  phoneNumber: string,
  deals: Array<{ productName: string; retailer: string; price: number; discount: number }>,
  channel: 'sms' | 'whatsapp' | 'both' = 'whatsapp'
): Promise<boolean> {
  const dealsText = deals
    .slice(0, 5)
    .map((d) => `• ${d.productName} @ ${d.retailer} - R${d.price.toFixed(2)} (${d.discount}% off)`)
    .join('\n');

  const message = `📬 Your Weekly Mzansi Specials Digest\n\nTop Deals This Week:\n\n${dealsText}\n\nView more on Mzansi Specials!`;

  let sent = false;

  if (channel === 'sms' || channel === 'both') {
    sent = await sendSMS(phoneNumber, message);
  }

  if (channel === 'whatsapp' || channel === 'both') {
    sent = await sendWhatsApp(phoneNumber, message);
  }

  return sent;
}

/**
 * Format phone number to international format
 */
function formatPhoneNumber(phoneNumber: string): string {
  // Remove any non-digit characters except +
  const cleaned = phoneNumber.replace(/[^\d+]/g, '');

  // If starts with 0, replace with +27
  if (cleaned.startsWith('0')) {
    return '+27' + cleaned.slice(1);
  }

  // If doesn't start with +, add +27
  if (!cleaned.startsWith('+')) {
    return '+27' + cleaned;
  }

  return cleaned;
}

/**
 * Validate phone number
 */
export function validatePhoneNumber(phoneNumber: string): boolean {
  const formatted = formatPhoneNumber(phoneNumber);
  // South African numbers should be +27XXXXXXXXX (12 digits total)
  return /^\+27\d{9}$/.test(formatted);
}

/**
 * Test Twilio connection
 */
export async function testTwilioConnection(): Promise<{ status: string; message: string }> {
  try {
    console.log('[Twilio] Testing connection...');

    if (!TWILIO_AUTH_TOKEN) {
      return {
        status: 'warning',
        message: 'Twilio Auth Token not configured',
      };
    }

    // Try to fetch account info
    const response = await axios.get(`${TWILIO_API_URL}.json`, {
      auth: {
        username: TWILIO_ACCOUNT_SID,
        password: TWILIO_AUTH_TOKEN,
      },
    });

    console.log('[Twilio] ✓ Connection successful');
    return {
      status: 'success',
      message: `Connected to Twilio account: ${response.data.friendly_name}`,
    };
  } catch (error) {
    console.error('[Twilio] ✗ Connection failed:', error);
    return {
      status: 'error',
      message: 'Failed to connect to Twilio',
    };
  }
}
