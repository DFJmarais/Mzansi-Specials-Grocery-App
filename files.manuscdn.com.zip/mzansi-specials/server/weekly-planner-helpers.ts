import { getDb } from "./db";
import { weeklyPlans, weeklyMeals, mealIngredients, weeklyShoppingLists, weeklyShoppingItems, mealTemplates } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

/**
 * Create a new weekly plan
 */
export async function createWeeklyPlan(
  userId: number,
  name: string,
  startDate: Date,
  endDate: Date,
  budget?: number,
  description?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(weeklyPlans).values({
    userId,
    name,
    startDate,
    endDate,
    budget: budget ? budget.toString() : null,
    description,
  });

  return result;
}

/**
 * Get all weekly plans for a user
 */
export async function getUserWeeklyPlans(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(weeklyPlans).where(eq(weeklyPlans.userId, userId));
}

/**
 * Get a specific weekly plan with all meals and shopping list
 */
export async function getWeeklyPlanDetails(planId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const plans = await db.select().from(weeklyPlans).where(and(eq(weeklyPlans.id, planId), eq(weeklyPlans.userId, userId)));
  const plan = plans[0];

  if (!plan) return null;

  const meals = await db.select().from(weeklyMeals).where(eq(weeklyMeals.planId, planId));

  const shoppingLists = await db.select().from(weeklyShoppingLists).where(eq(weeklyShoppingLists.planId, planId));
  const shoppingList = shoppingLists[0];

  const shoppingItems = shoppingList
    ? await db.select().from(weeklyShoppingItems).where(eq(weeklyShoppingItems.listId, shoppingList.id))
    : [];

  return {
    plan,
    meals,
    shoppingList,
    shoppingItems,
  };
}

/**
 * Add a meal to a weekly plan
 */
export async function addMealToWeeklyPlan(
  planId: number,
  dayOfWeek: number,
  mealType: string,
  mealName: string,
  description?: string,
  servings: number = 1
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(weeklyMeals).values({
    planId,
    dayOfWeek,
    mealType,
    mealName,
    description,
    servings,
  });

  return result;
}

/**
 * Add ingredients to a meal
 */
export async function addMealIngredients(
  mealId: number,
  ingredients: Array<{
    ingredientName: string;
    quantity: number;
    unit: string;
    productId?: number;
    estimatedPrice?: number;
  }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(mealIngredients).values(
    ingredients.map((ing) => ({
      mealId,
      ingredientName: ing.ingredientName,
      quantity: String(ing.quantity),
      unit: ing.unit,
      productId: ing.productId || null,
      estimatedPrice: ing.estimatedPrice ? String(ing.estimatedPrice) : null,
    }))
  );

  return result;
}

/**
 * Generate shopping list from weekly plan
 */
export async function generateShoppingListFromPlan(planId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Get all meals for the plan
  const meals = await db.select().from(weeklyMeals).where(eq(weeklyMeals.planId, planId));

  // Get all ingredients for all meals
  const allIngredients: any[] = [];
  for (const meal of meals) {
    const ingredients = await db.select().from(mealIngredients).where(eq(mealIngredients.mealId, meal.id));
    allIngredients.push(...ingredients);
  }

  // Group ingredients by name and sum quantities
  const ingredientMap = new Map<string, any>();
  for (const ing of allIngredients) {
    const key = ing.ingredientName.toLowerCase();
    if (ingredientMap.has(key)) {
      const existing = ingredientMap.get(key);
      existing.quantity = Number(existing.quantity) + Number(ing.quantity);
      existing.estimatedPrice = (Number(existing.estimatedPrice || 0) + Number(ing.estimatedPrice || 0));
    } else {
      ingredientMap.set(key, ing);
    }
  }

  // Create shopping list
  const shoppingListResult = await db.insert(weeklyShoppingLists).values({
    planId,
    name: `Shopping List - Week of ${new Date().toLocaleDateString()}`,
    totalItems: ingredientMap.size,
  });

  const listId = (shoppingListResult as any).insertId || 1;

  // Add items to shopping list
  const items = Array.from(ingredientMap.values()).map((ing) => ({
    listId,
    itemName: ing.ingredientName,
    quantity: String(ing.quantity),
    unit: ing.unit,
    productId: ing.productId || null,
    estimatedPrice: ing.estimatedPrice ? String(ing.estimatedPrice) : null,
    category: categorizeIngredient(ing.ingredientName),
  }));

  await db.insert(weeklyShoppingItems).values(items);

  return { listId, itemCount: items.length };
}

/**
 * Update shopping item checked status
 */
export async function updateShoppingItemStatus(itemId: number, isChecked: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db
    .update(weeklyShoppingItems)
    .set({ isChecked: isChecked ? 1 : 0 })
    .where(eq(weeklyShoppingItems.id, itemId));
}

/**
 * Get meal templates by category
 */
export async function getMealTemplatesByCategory(category: string) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(mealTemplates).where(and(eq(mealTemplates.category, category), eq(mealTemplates.isPublic, 1)));
}

/**
 * Get all meal template categories
 */
export async function getMealTemplateCategories() {
  const db = await getDb();
  if (!db) return [];
  const templates = await db.select().from(mealTemplates);
  const categories = new Set(templates.map((t: any) => t.category));
  return Array.from(categories);
}

/**
 * Calculate total estimated cost for a weekly plan
 */
export async function calculateWeeklyPlanCost(planId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Get all meals for this plan
  const meals = await db.select().from(weeklyMeals).where(eq(weeklyMeals.planId, planId));

  let totalCost = 0;
  for (const meal of meals) {
    // Get all ingredients for this meal
    const ingredients = await db.select().from(mealIngredients).where(eq(mealIngredients.mealId, meal.id));
    for (const ing of ingredients) {
      totalCost += Number(ing.estimatedPrice || 0);
    }
  }

  // Update the plan with estimated total
  await db
    .update(weeklyPlans)
    .set({ estimatedTotal: String(totalCost) })
    .where(eq(weeklyPlans.id, planId));

  return totalCost;
}

/**
 * Categorize ingredient for shopping list organization
 */
function categorizeIngredient(ingredientName: string): string {
  const name = ingredientName.toLowerCase();

  if (
    name.includes("milk") ||
    name.includes("cheese") ||
    name.includes("yogurt") ||
    name.includes("butter") ||
    name.includes("cream")
  ) {
    return "Dairy";
  }
  if (
    name.includes("chicken") ||
    name.includes("beef") ||
    name.includes("pork") ||
    name.includes("fish") ||
    name.includes("meat") ||
    name.includes("steak")
  ) {
    return "Meat & Protein";
  }
  if (
    name.includes("tomato") ||
    name.includes("carrot") ||
    name.includes("broccoli") ||
    name.includes("spinach") ||
    name.includes("lettuce") ||
    name.includes("pepper") ||
    name.includes("onion") ||
    name.includes("garlic")
  ) {
    return "Vegetables";
  }
  if (
    name.includes("apple") ||
    name.includes("banana") ||
    name.includes("orange") ||
    name.includes("berry") ||
    name.includes("grape") ||
    name.includes("fruit")
  ) {
    return "Fruits";
  }
  if (
    name.includes("bread") ||
    name.includes("rice") ||
    name.includes("pasta") ||
    name.includes("grain") ||
    name.includes("cereal") ||
    name.includes("flour")
  ) {
    return "Grains & Bread";
  }
  if (
    name.includes("oil") ||
    name.includes("salt") ||
    name.includes("sugar") ||
    name.includes("spice") ||
    name.includes("sauce") ||
    name.includes("vinegar")
  ) {
    return "Pantry & Condiments";
  }

  return "Other";
}

/**
 * Delete a weekly plan and all associated data
 */
export async function deleteWeeklyPlan(planId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Verify ownership
  const plans = await db.select().from(weeklyPlans).where(and(eq(weeklyPlans.id, planId), eq(weeklyPlans.userId, userId)));
  const plan = plans[0];

  if (!plan) {
    throw new Error("Plan not found or unauthorized");
  }

  // Delete the plan (cascade will handle related data)
  return await db.delete(weeklyPlans).where(eq(weeklyPlans.id, planId));
}

/**
 * Update weekly plan budget
 */
export async function updateWeeklyPlanBudget(planId: number, userId: number, budget: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const plans = await db.select().from(weeklyPlans).where(and(eq(weeklyPlans.id, planId), eq(weeklyPlans.userId, userId)));
  const plan = plans[0];

  if (!plan) {
    throw new Error("Plan not found or unauthorized");
  }

  return await db
    .update(weeklyPlans)
    .set({ budget: String(budget) })
    .where(eq(weeklyPlans.id, planId))
}
