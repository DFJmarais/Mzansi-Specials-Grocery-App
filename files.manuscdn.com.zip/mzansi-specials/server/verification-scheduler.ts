/**
 * Hourly Price Verification & Revalidation System
 * Runs every hour to recheck prices and recalculate trust scores
 */

import { getDb } from "./db";
import { prices, products } from "../drizzle/schema";
import { calculateTrustScore, PriceSource } from "./trust";
import { updatePriceTrustScore } from "./trust-db";
import { eq, desc } from "drizzle-orm";

let verificationInterval: NodeJS.Timeout | null = null;

/**
 * Start the hourly verification scheduler
 */
export function startVerificationScheduler() {
  if (verificationInterval) {
    console.log("[Verification] Scheduler already running");
    return;
  }

  console.log("[Verification] Starting hourly verification scheduler");

  // Run immediately on startup
  runVerification();

  // Then run every hour
  verificationInterval = setInterval(() => {
    runVerification();
  }, 60 * 60 * 1000); // 1 hour
}

/**
 * Stop the verification scheduler
 */
export function stopVerificationScheduler() {
  if (verificationInterval) {
    clearInterval(verificationInterval);
    verificationInterval = null;
    console.log("[Verification] Stopped verification scheduler");
  }
}

/**
 * Run the verification process
 */
async function runVerification() {
  const startTime = Date.now();
  console.log(`[Verification] Starting hourly verification at ${new Date().toISOString()}`);

  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Verification] Database not available");
      return;
    }

    // Get all prices
    const allPrices = await db.select().from(prices);
    console.log(`[Verification] Processing ${allPrices.length} prices`);

    let processed = 0;
    let updated = 0;
    let flagged = 0;

    for (const priceRecord of allPrices) {
      try {
        // Get product info
        const product = await db
          .select()
          .from(products)
          .where(eq(products.id, priceRecord.productId))
          .limit(1);

        if (!product.length) {
          continue;
        }

        // Parse sources if they exist
        let sources: PriceSource[] = [];
        if (priceRecord.sources) {
          try {
            sources = JSON.parse(priceRecord.sources as string);
          } catch (e) {
            sources = [];
          }
        }

        // Get price history (last 10 prices for this product/store)
        const history = await db
          .select()
          .from(prices)
          .where(eq(prices.productId, priceRecord.productId))
          .orderBy(desc(prices.lastUpdated))
          .limit(10);

        const priceHistory = history.map((p) => ({
          price: p.price,
          date: p.lastUpdated,
        }));

        // Recalculate trust score
        const trustResult = calculateTrustScore(
          sources,
          priceRecord.price,
          priceRecord.originalPrice,
          priceRecord.lastUpdated,
          priceHistory
        );

        // Check if trust score changed significantly
        const scoreDifference = Math.abs(trustResult.trustScore - priceRecord.trustScore);

        if (scoreDifference > 5 || trustResult.verificationStatus !== priceRecord.verificationStatus) {
          // Update the price record
          await updatePriceTrustScore(
            priceRecord.id,
            priceRecord.productId,
            trustResult,
            priceRecord.trustScore
          );
          updated++;

          if (trustResult.verificationStatus === "FLAGGED") {
            flagged++;
            console.log(
              `[Verification] ⚠️  Flagged: ${product[0].name} at ${priceRecord.storeName} - Score: ${trustResult.trustScore}`
            );
          }
        }

        processed++;
      } catch (error) {
        console.error(`[Verification] Error processing price ${priceRecord.id}:`, error);
      }
    }

    const duration = Date.now() - startTime;
    console.log(
      `[Verification] ✅ Completed in ${duration}ms | Processed: ${processed} | Updated: ${updated} | Flagged: ${flagged}`
    );
  } catch (error) {
    console.error("[Verification] Fatal error during verification:", error);
  }
}

/**
 * Manually trigger verification (for testing)
 */
export async function triggerVerification() {
  console.log("[Verification] Manual verification triggered");
  await runVerification();
}
