/**
 * Trust Score Calculation System
 * Implements comprehensive trust scoring for prices with verification tracking
 */

export type TrustLevel = "HIGH" | "MEDIUM" | "LOW";
export type VerificationStatus = "VERIFIED" | "UNVERIFIED" | "FLAGGED";

export interface PriceSource {
  sourceName: string;
  sourceType: "ONLINE" | "OFFLINE" | "API" | "SCRAPE";
  sourceUrl?: string;
  price?: number;
  verified: boolean;
  timestamp: Date;
}

export interface TrustScoreResult {
  trustScore: number; // 0-100
  trustLevel: TrustLevel;
  verificationStatus: VerificationStatus;
  flags: string[];
  reasoning: string;
}

/**
 * Calculate trust score based on multiple factors
 * Base: 100 points
 * Positive adjustments: +20 (2+ sources), +15 (recent), +10 (range match), +10 (consistent)
 * Negative adjustments: -15 (1 source), -20 (stale), -25 (outlier), -30 (no verified), -20 (manual), -25 (conflict)
 */
export function calculateTrustScore(
  sources: PriceSource[],
  price: number,
  originalPrice: number | null,
  lastUpdated: Date,
  priceHistory: Array<{ price: number; date: Date }> = []
): TrustScoreResult {
  let score = 100;
  const flags: string[] = [];
  const reasons: string[] = [];

  // 1. Source Count Analysis
  const verifiedSources = sources.filter((s) => s.verified);
  const sourcesCount = verifiedSources.length;

  if (sourcesCount >= 2) {
    score += 20;
    reasons.push("Verified from 2+ independent sources");
  } else if (sourcesCount === 1) {
    score -= 15;
    flags.push("single_source");
    reasons.push("Only 1 verified source");
  } else if (sourcesCount === 0) {
    score -= 30;
    flags.push("no_verified_source");
    reasons.push("No verified sources");
  }

  // 2. Freshness Check (within 6 hours = +15, stale > 6 hours = -20)
  const hoursOld = (Date.now() - lastUpdated.getTime()) / (1000 * 60 * 60);
  if (hoursOld <= 6) {
    score += 15;
    reasons.push("Updated within last 6 hours");
  } else if (hoursOld > 24) {
    score -= 20;
    flags.push("stale_data");
    reasons.push(`Data is ${Math.round(hoursOld)} hours old`);
  }

  // 3. Price Range Validation
  if (originalPrice && price > originalPrice) {
    score -= 25;
    flags.push("price_outlier");
    reasons.push("Sale price exceeds original price");
  } else if (originalPrice && price > 0) {
    const discountPercent = ((originalPrice - price) / originalPrice) * 100;
    if (discountPercent >= 0 && discountPercent <= 50) {
      score += 10;
      reasons.push("Price within expected discount range (0-50%)");
    } else if (discountPercent > 50) {
      score -= 25;
      flags.push("price_outlier");
      reasons.push(`Unrealistic discount: ${discountPercent.toFixed(1)}%`);
    }
  }

  // 4. Price History Consistency
  if (priceHistory.length >= 2) {
    const recentPrices = priceHistory.slice(-5).map((p) => p.price);
    const avgPrice = recentPrices.reduce((a, b) => a + b, 0) / recentPrices.length;
    const deviation = Math.abs(price - avgPrice) / avgPrice;

    if (deviation < 0.1) {
      // Less than 10% deviation
      score += 10;
      reasons.push("Price consistent with recent history");
    } else if (deviation > 0.3) {
      score -= 25;
      flags.push("conflicting_sources");
      reasons.push(`Price deviates ${(deviation * 100).toFixed(1)}% from average`);
    }
  }

  // 5. Source Conflict Detection
  if (sources.length > 1) {
    const prices = sources.map((s) => s.price).filter((p) => p !== undefined) as number[];
    if (prices.length > 1) {
      const maxPrice = Math.max(...prices);
      const minPrice = Math.min(...prices);
      const priceSpread = ((maxPrice - minPrice) / minPrice) * 100;

      if (priceSpread > 20) {
        score -= 25;
        flags.push("conflicting_sources");
        reasons.push(`Sources conflict: ${priceSpread.toFixed(1)}% spread`);
      }
    }
  }

  // Clamp score between 0 and 100
  score = Math.max(0, Math.min(100, score));

  // Determine trust level
  let trustLevel: TrustLevel;
  if (score >= 85) {
    trustLevel = "HIGH";
  } else if (score >= 70) {
    trustLevel = "MEDIUM";
  } else {
    trustLevel = "LOW";
  }

  // Determine verification status
  let verificationStatus: VerificationStatus;
  if (flags.length > 0) {
    verificationStatus = "FLAGGED";
  } else if (sourcesCount >= 1) {
    verificationStatus = "VERIFIED";
  } else {
    verificationStatus = "UNVERIFIED";
  }

  return {
    trustScore: score,
    trustLevel,
    verificationStatus,
    flags,
    reasoning: reasons.join(" | "),
  };
}

/**
 * Determine if a price should be displayed to users
 * Minimum threshold: trust score >= 70
 */
export function isPriceValid(trustScore: number, verificationStatus: VerificationStatus): boolean {
  // Must have at least 1 verified source OR be explicitly marked as "Not Available"
  if (verificationStatus === "UNVERIFIED") {
    return false;
  }

  // Trust score must meet minimum threshold
  return trustScore >= 70;
}

/**
 * Get human-readable trust indicator
 */
export function getTrustIndicator(trustLevel: TrustLevel): {
  emoji: string;
  label: string;
  color: string;
} {
  const indicators = {
    HIGH: {
      emoji: "🟢",
      label: "Trusted",
      color: "green",
    },
    MEDIUM: {
      emoji: "🟡",
      label: "Verified",
      color: "yellow",
    },
    LOW: {
      emoji: "🔴",
      label: "Low Confidence",
      color: "red",
    },
  };
  return indicators[trustLevel];
}

/**
 * Format trust information for display
 */
export function formatTrustInfo(
  trustScore: number,
  trustLevel: TrustLevel,
  sourcesCount: number,
  lastVerified: Date | null
): string {
  const indicator = getTrustIndicator(trustLevel);
  const hoursAgo = lastVerified
    ? Math.round((Date.now() - lastVerified.getTime()) / (1000 * 60 * 60))
    : null;

  let info = `${indicator.emoji} ${indicator.label} (${trustScore}/100)`;

  if (sourcesCount > 0) {
    info += ` • ${sourcesCount} source${sourcesCount > 1 ? "s" : ""}`;
  }

  if (hoursAgo !== null) {
    if (hoursAgo === 0) {
      info += " • Just verified";
    } else if (hoursAgo < 24) {
      info += ` • Verified ${hoursAgo}h ago`;
    } else {
      const daysAgo = Math.round(hoursAgo / 24);
      info += ` • Verified ${daysAgo}d ago`;
    }
  }

  return info;
}
