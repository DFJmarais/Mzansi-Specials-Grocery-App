/**
 * Products Seed Data
 * Initial grocery items for South African market
 */

export const PRODUCTS = [
  // Dairy & Milk
  { name: 'Full Cream Milk (1L)', category: 'Dairy', description: 'Fresh full cream milk' },
  { name: 'Low Fat Milk (1L)', category: 'Dairy', description: 'Low fat milk for health conscious' },
  { name: 'Butter (500g)', category: 'Dairy', description: 'Salted butter' },
  { name: 'Cheddar Cheese (200g)', category: 'Dairy', description: 'Hard cheddar cheese' },
  { name: 'Yogurt (500g)', category: 'Dairy', description: 'Plain yogurt' },
  
  // Meat & Protein
  { name: 'Beef Steak (500g)', category: 'Meat', description: 'Premium beef steak' },
  { name: 'Chicken Breast (1kg)', category: 'Meat', description: 'Fresh chicken breast' },
  { name: 'Pork Chops (500g)', category: 'Meat', description: 'Fresh pork chops' },
  { name: 'Ground Beef (500g)', category: 'Meat', description: 'Lean ground beef' },
  { name: 'Boerewors (500g)', category: 'Meat', description: 'Traditional South African sausage' },
  
  // Produce
  { name: 'Tomatoes (1kg)', category: 'Produce', description: 'Fresh red tomatoes' },
  { name: 'Onions (1kg)', category: 'Produce', description: 'Yellow onions' },
  { name: 'Potatoes (2kg)', category: 'Produce', description: 'White potatoes' },
  { name: 'Carrots (1kg)', category: 'Produce', description: 'Fresh carrots' },
  { name: 'Apples (1kg)', category: 'Produce', description: 'Red apples' },
  { name: 'Bananas (1kg)', category: 'Produce', description: 'Yellow bananas' },
  { name: 'Lettuce (1 head)', category: 'Produce', description: 'Fresh green lettuce' },
  { name: 'Broccoli (500g)', category: 'Produce', description: 'Fresh broccoli' },
  
  // Bakery
  { name: 'Bread (White Loaf)', category: 'Bakery', description: 'White bread loaf' },
  { name: 'Bread (Brown Loaf)', category: 'Bakery', description: 'Brown bread loaf' },
  { name: 'Rolls (6 pack)', category: 'Bakery', description: 'Dinner rolls' },
  { name: 'Croissants (4 pack)', category: 'Bakery', description: 'Butter croissants' },
  
  // Pantry
  { name: 'Rice (5kg)', category: 'Pantry', description: 'White rice' },
  { name: 'Pasta (500g)', category: 'Pantry', description: 'Spaghetti pasta' },
  { name: 'Flour (2kg)', category: 'Pantry', description: 'All-purpose flour' },
  { name: 'Sugar (2kg)', category: 'Pantry', description: 'White sugar' },
  { name: 'Oil (1L)', category: 'Pantry', description: 'Vegetable oil' },
  { name: 'Peanut Butter (400g)', category: 'Pantry', description: 'Creamy peanut butter' },
  { name: 'Jam (400g)', category: 'Pantry', description: 'Strawberry jam' },
  { name: 'Beans (400g)', category: 'Pantry', description: 'Canned beans' },
  
  // Beverages
  { name: 'Orange Juice (1L)', category: 'Beverages', description: 'Fresh orange juice' },
  { name: 'Coffee (200g)', category: 'Beverages', description: 'Ground coffee' },
  { name: 'Tea (50 bags)', category: 'Beverages', description: 'Black tea bags' },
  { name: 'Coca Cola (2L)', category: 'Beverages', description: 'Coca Cola bottle' },
  { name: 'Water (6 pack)', category: 'Beverages', description: 'Bottled water' },
  
  // Snacks
  { name: 'Chips (200g)', category: 'Snacks', description: 'Potato chips' },
  { name: 'Biscuits (300g)', category: 'Snacks', description: 'Digestive biscuits' },
  { name: 'Chocolate Bar (50g)', category: 'Snacks', description: 'Milk chocolate bar' },
  { name: 'Nuts (200g)', category: 'Snacks', description: 'Mixed nuts' },
  { name: 'Biltong (100g)', category: 'Snacks', description: 'Dried biltong' },
  
  // Eggs & Breakfast
  { name: 'Eggs (12 pack)', category: 'Eggs', description: 'Fresh chicken eggs' },
  { name: 'Cereal (500g)', category: 'Breakfast', description: 'Corn flakes cereal' },
  { name: 'Oats (500g)', category: 'Breakfast', description: 'Rolled oats' },
  { name: 'Honey (500g)', category: 'Breakfast', description: 'Pure honey' },
  
  // Frozen
  { name: 'Frozen Vegetables (500g)', category: 'Frozen', description: 'Mixed frozen vegetables' },
  { name: 'Ice Cream (1L)', category: 'Frozen', description: 'Vanilla ice cream' },
  { name: 'Frozen Pizza (400g)', category: 'Frozen', description: 'Cheese pizza' },
  
  // Condiments
  { name: 'Tomato Sauce (400g)', category: 'Condiments', description: 'Tomato sauce bottle' },
  { name: 'Mayonnaise (400g)', category: 'Condiments', description: 'Mayonnaise jar' },
  { name: 'Vinegar (750ml)', category: 'Condiments', description: 'White vinegar' },
  { name: 'Salt (1kg)', category: 'Condiments', description: 'Table salt' },
  { name: 'Spice Mix (50g)', category: 'Condiments', description: 'Mixed spices' },
];
