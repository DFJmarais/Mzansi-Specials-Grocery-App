/**
 * Diet Categories Seed Data
 * Comprehensive list of dietary preferences and restrictions
 */

export const DIET_CATEGORIES = [
  {
    name: 'Gluten-Free',
    slug: 'gluten-free',
    description: 'Products free from gluten for celiac disease and gluten sensitivity',
    icon: '🌾',
    color: '#F4A460',
  },
  {
    name: 'Vegan',
    slug: 'vegan',
    description: 'Plant-based products with no animal products or by-products',
    icon: '🌱',
    color: '#2D5016',
  },
  {
    name: 'Vegetarian',
    slug: 'vegetarian',
    description: 'Products with no meat, poultry, or fish but may contain dairy and eggs',
    icon: '🥬',
    color: '#00A896',
  },
  {
    name: 'Keto/Low-Carb',
    slug: 'keto-low-carb',
    description: 'Low carbohydrate products suitable for ketogenic diet',
    icon: '🥩',
    color: '#FF6B35',
  },
  {
    name: 'Dairy-Free',
    slug: 'dairy-free',
    description: 'Products with no milk, cheese, butter, or dairy derivatives',
    icon: '🥛',
    color: '#FFD700',
  },
  {
    name: 'Lactose-Intolerant',
    slug: 'lactose-intolerant',
    description: 'Products low or free in lactose for lactose intolerance',
    icon: '🚫🥛',
    color: '#FF6B9D',
  },
  {
    name: 'Organic',
    slug: 'organic',
    description: 'Certified organic products grown without synthetic pesticides',
    icon: '🌿',
    color: '#228B22',
  },
  {
    name: 'Sugar-Free/Low-Sugar',
    slug: 'sugar-free-low-sugar',
    description: 'Products with minimal or no added sugar',
    icon: '🍬',
    color: '#FF1493',
  },
  {
    name: 'Halal',
    slug: 'halal',
    description: 'Products prepared according to Islamic dietary laws',
    icon: '☪️',
    color: '#006400',
  },
  {
    name: 'Kosher',
    slug: 'kosher',
    description: 'Products prepared according to Jewish dietary laws',
    icon: '✡️',
    color: '#4169E1',
  },
  {
    name: 'Low-Sodium/Heart-Healthy',
    slug: 'low-sodium-heart-healthy',
    description: 'Low sodium products for heart health and blood pressure management',
    icon: '❤️',
    color: '#DC143C',
  },
  {
    name: 'Nut-Free',
    slug: 'nut-free',
    description: 'Products free from tree nuts and peanuts for allergy sufferers',
    icon: '🚫🥜',
    color: '#8B4513',
  },
  {
    name: 'Soy-Free',
    slug: 'soy-free',
    description: 'Products with no soy or soy derivatives',
    icon: '🚫🫘',
    color: '#CD853F',
  },
  {
    name: 'Non-GMO',
    slug: 'non-gmo',
    description: 'Products made without genetically modified organisms',
    icon: '🧬',
    color: '#32CD32',
  },
  {
    name: 'Paleo',
    slug: 'paleo',
    description: 'Products aligned with paleo diet (whole foods, no processed)',
    icon: '🦴',
    color: '#8B7355',
  },
  {
    name: 'High-Protein',
    slug: 'high-protein',
    description: 'Products with high protein content for muscle building',
    icon: '💪',
    color: '#FF4500',
  },
  {
    name: 'Diabetic-Friendly',
    slug: 'diabetic-friendly',
    description: 'Products suitable for diabetic diets with controlled sugar and carbs',
    icon: '🩺',
    color: '#1E90FF',
  },
  {
    name: 'Egg-Free',
    slug: 'egg-free',
    description: 'Products with no eggs or egg derivatives',
    icon: '🚫🥚',
    color: '#FFB6C1',
  },
  {
    name: 'Shellfish-Free',
    slug: 'shellfish-free',
    description: 'Products free from shellfish and crustaceans',
    icon: '🚫🦐',
    color: '#20B2AA',
  },
  {
    name: 'Sesame-Free',
    slug: 'sesame-free',
    description: 'Products with no sesame seeds or sesame oil',
    icon: '🚫🌰',
    color: '#D2691E',
  },
];

/**
 * Product-Diet Mapping
 * Maps common grocery products to their applicable diet categories
 */
export const PRODUCT_DIET_MAPPING: Record<string, string[]> = {
  // Dairy Products
  'Full Cream Milk (1L)': ['lactose-intolerant', 'vegan', 'dairy-free'],
  'Lactose-Free Milk (1L)': ['lactose-intolerant', 'dairy-free'],
  'Almond Milk (1L)': ['vegan', 'dairy-free', 'lactose-intolerant', 'nut-free'],
  'Oat Milk (1L)': ['vegan', 'dairy-free', 'lactose-intolerant', 'gluten-free'],
  'Soy Milk (1L)': ['vegan', 'dairy-free', 'lactose-intolerant', 'soy-free'],
  'Yogurt (500g)': ['lactose-intolerant', 'high-protein'],
  'Greek Yogurt (500g)': ['high-protein', 'lactose-intolerant'],
  'Cheese (200g)': ['lactose-intolerant', 'vegetarian', 'high-protein'],
  'Butter (250g)': ['lactose-intolerant', 'vegetarian', 'dairy-free'],

  // Meat Products
  'Beef Steak (500g)': ['paleo', 'keto-low-carb', 'high-protein', 'halal'],
  'Chicken Breast (1kg)': ['paleo', 'keto-low-carb', 'high-protein', 'halal'],
  'Pork Chops (500g)': ['paleo', 'keto-low-carb', 'high-protein'],
  'Ground Beef (500g)': ['paleo', 'keto-low-carb', 'high-protein', 'halal'],
  'Lamb (500g)': ['paleo', 'keto-low-carb', 'high-protein', 'halal', 'kosher'],
  'Fish Fillet (500g)': ['paleo', 'keto-low-carb', 'high-protein', 'halal', 'kosher'],

  // Bread & Grains
  'Bread (White Loaf)': ['vegan'],
  'Whole Wheat Bread': ['vegetarian', 'vegan'],
  'Gluten-Free Bread': ['gluten-free', 'vegan'],
  'Rice (5kg)': ['vegan', 'gluten-free', 'paleo', 'keto-low-carb'],
  'Oats (500g)': ['vegan', 'vegetarian', 'high-protein'],
  'Pasta (500g)': ['vegan', 'vegetarian'],
  'Gluten-Free Pasta': ['gluten-free', 'vegan', 'vegetarian'],

  // Vegetables
  'Tomatoes (1kg)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],
  'Onions (1kg)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],
  'Potatoes (1kg)': ['vegan', 'vegetarian', 'gluten-free', 'organic'],
  'Carrots (1kg)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],
  'Broccoli (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],
  'Spinach (250g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],

  // Fruits
  'Apples (1kg)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Bananas (1kg)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Oranges (1kg)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Strawberries (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Blueberries (250g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],

  // Pantry Items
  'Olive Oil (1L)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],
  'Peanut Butter (500g)': ['vegan', 'vegetarian', 'gluten-free', 'high-protein', 'nut-free'],
  'Almond Butter (500g)': ['vegan', 'vegetarian', 'gluten-free', 'high-protein'],
  'Honey (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Nuts Mix (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'high-protein', 'nut-free'],
  'Seeds Mix (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'high-protein'],

  // Beverages
  'Coffee (250g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Tea (50 bags)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Orange Juice (1L)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Coconut Water (1L)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb'],

  // Snacks
  'Granola Bar': ['vegan', 'vegetarian', 'high-protein'],
  'Protein Bar': ['high-protein', 'sugar-free-low-sugar'],
  'Dark Chocolate (100g)': ['vegan', 'vegetarian', 'gluten-free', 'sugar-free-low-sugar'],
  'Almonds (200g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'high-protein', 'nut-free'],

  // Condiments & Sauces
  'Tomato Sauce (500ml)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'low-sodium-heart-healthy'],
  'Soy Sauce (500ml)': ['vegan', 'vegetarian', 'soy-free'],
  'Vinegar (500ml)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb'],
  'Mayonnaise (500g)': ['vegetarian', 'gluten-free', 'egg-free'],

  // Frozen Foods
  'Frozen Vegetables (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],
  'Frozen Berries (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'keto-low-carb', 'organic'],
  'Frozen Fish (500g)': ['paleo', 'keto-low-carb', 'high-protein', 'halal', 'kosher'],

  // Special Dietary Products
  'Sugar-Free Jam (300g)': ['vegan', 'vegetarian', 'gluten-free', 'sugar-free-low-sugar', 'diabetic-friendly'],
  'Stevia Sweetener (100g)': ['vegan', 'vegetarian', 'gluten-free', 'sugar-free-low-sugar', 'diabetic-friendly'],
  'Coconut Sugar (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'organic'],
  'Almond Flour (500g)': ['gluten-free', 'vegan', 'vegetarian', 'paleo', 'keto-low-carb', 'nut-free'],
  'Coconut Flour (500g)': ['gluten-free', 'vegan', 'vegetarian', 'paleo', 'keto-low-carb'],
  'Protein Powder (500g)': ['high-protein', 'gluten-free', 'vegan'],
  'Bone Broth (500ml)': ['paleo', 'keto-low-carb', 'high-protein', 'gluten-free'],
  'Chia Seeds (200g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'high-protein', 'organic'],
  'Flax Seeds (200g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'high-protein', 'organic'],
  'Hemp Seeds (200g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'high-protein', 'organic'],
  'Quinoa (500g)': ['vegan', 'vegetarian', 'gluten-free', 'paleo', 'high-protein', 'organic'],
  'Lentils (500g)': ['vegan', 'vegetarian', 'gluten-free', 'high-protein', 'organic'],
  'Chickpeas (500g)': ['vegan', 'vegetarian', 'gluten-free', 'high-protein', 'organic'],
  'Black Beans (500g)': ['vegan', 'vegetarian', 'gluten-free', 'high-protein', 'organic'],
  'Tofu (400g)': ['vegan', 'vegetarian', 'gluten-free', 'high-protein', 'soy-free'],
  'Tempeh (200g)': ['vegan', 'vegetarian', 'gluten-free', 'high-protein', 'soy-free'],

  // Halal & Kosher Specific
  'Halal Chicken (1kg)': ['halal', 'paleo', 'keto-low-carb', 'high-protein'],
  'Halal Beef (1kg)': ['halal', 'paleo', 'keto-low-carb', 'high-protein'],
  'Kosher Chicken (1kg)': ['kosher', 'paleo', 'keto-low-carb', 'high-protein'],
  'Kosher Beef (1kg)': ['kosher', 'paleo', 'keto-low-carb', 'high-protein'],

  // Allergy-Friendly
  'Nut-Free Granola (500g)': ['vegan', 'vegetarian', 'gluten-free', 'nut-free', 'high-protein'],
  'Egg-Free Mayonnaise (500g)': ['vegan', 'vegetarian', 'gluten-free', 'egg-free'],
  'Shellfish-Free Seasoning (100g)': ['vegan', 'vegetarian', 'gluten-free', 'shellfish-free'],

  // Low-Sodium
  'Low-Sodium Bread': ['low-sodium-heart-healthy', 'vegan', 'vegetarian'],
  'Low-Sodium Sauce (500ml)': ['low-sodium-heart-healthy', 'vegan', 'vegetarian', 'gluten-free'],
  'Low-Sodium Broth (500ml)': ['low-sodium-heart-healthy', 'paleo', 'keto-low-carb', 'gluten-free'],

  // Non-GMO
  'Non-GMO Corn (500g)': ['vegan', 'vegetarian', 'gluten-free', 'non-gmo', 'organic'],
  'Non-GMO Soy (500g)': ['vegan', 'vegetarian', 'non-gmo', 'soy-free', 'organic'],
};
