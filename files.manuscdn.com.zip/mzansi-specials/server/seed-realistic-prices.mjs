import mysql from 'mysql2/promise';

// Realistic South African grocery prices (in Rands, not cents)
const REALISTIC_PRICES = {
  'Milk (1L)': { Spar: 18.99, 'Pick n Pay': 19.99, Checkers: 17.99, Woolworths: 20.49, 'OK Foods': 18.49 },
  'Bread (White Loaf)': { Spar: 8.99, 'Pick n Pay': 9.49, Checkers: 8.49, Woolworths: 10.99, 'OK Foods': 8.79 },
  'Eggs (12 pack)': { Spar: 24.99, 'Pick n Pay': 25.99, Checkers: 23.99, Woolworths: 27.99, 'OK Foods': 24.49 },
  'Chicken Breast (1kg)': { Spar: 59.99, 'Pick n Pay': 64.99, Checkers: 61.99, Woolworths: 69.99, 'OK Foods': 55.99 },
  'Beef Steak (500g)': { Spar: 89.99, 'Pick n Pay': 85.99, Checkers: 92.99, Woolworths: 99.99, 'OK Foods': 79.99 },
  'Rice (5kg)': { Spar: 79.99, 'Pick n Pay': 84.99, Checkers: 75.99, Woolworths: 89.99, 'OK Foods': 82.99 },
  'Tomatoes (1kg)': { Spar: 12.99, 'Pick n Pay': 14.99, Checkers: 11.99, Woolworths: 15.99, 'OK Foods': 13.99 },
  'Apples (1kg)': { Spar: 22.99, 'Pick n Pay': 24.99, Checkers: 19.99, Woolworths: 26.99, 'OK Foods': 23.99 },
  'Pork Chops (500g)': { Spar: 69.99, 'Pick n Pay': 74.99, Checkers: 71.99, Woolworths: 79.99, 'OK Foods': 65.99 },
  'Peanut Butter (500g)': { Spar: 34.99, 'Pick n Pay': 36.99, Checkers: 32.99, Woolworths: 39.99, 'OK Foods': 33.99 },
  'Coffee (200g)': { Spar: 44.99, 'Pick n Pay': 46.99, Checkers: 42.99, Woolworths: 49.99, 'OK Foods': 43.99 },
  'Tea (40 bags)': { Spar: 19.99, 'Pick n Pay': 21.99, Checkers: 18.99, Woolworths: 23.99, 'OK Foods': 20.49 },
  'Pasta (500g)': { Spar: 9.99, 'Pick n Pay': 11.99, Checkers: 9.49, Woolworths: 12.99, 'OK Foods': 10.49 },
  'Canned Beans (410g)': { Spar: 6.99, 'Pick n Pay': 7.99, Checkers: 6.49, Woolworths: 8.99, 'OK Foods': 7.49 },
  'Olive Oil (500ml)': { Spar: 59.99, 'Pick n Pay': 64.99, Checkers: 57.99, Woolworths: 69.99, 'OK Foods': 61.99 },
  'Butter (250g)': { Spar: 29.99, 'Pick n Pay': 31.99, Checkers: 28.99, Woolworths: 34.99, 'OK Foods': 30.49 },
  'Cheese (500g)': { Spar: 49.99, 'Pick n Pay': 52.99, Checkers: 47.99, Woolworths: 56.99, 'OK Foods': 51.99 },
  'Yogurt (500g)': { Spar: 14.99, 'Pick n Pay': 16.99, Checkers: 13.99, Woolworths: 18.99, 'OK Foods': 15.49 },
  'Orange Juice (1L)': { Spar: 16.99, 'Pick n Pay': 18.99, Checkers: 15.99, Woolworths: 20.99, 'OK Foods': 17.49 },
  'Coca Cola (2L)': { Spar: 24.99, 'Pick n Pay': 26.99, Checkers: 23.99, Woolworths: 28.99, 'OK Foods': 25.49 },
  'Sprite (2L)': { Spar: 24.99, 'Pick n Pay': 26.99, Checkers: 23.99, Woolworths: 28.99, 'OK Foods': 25.49 },
  'Beer (6 pack)': { Spar: 79.99, 'Pick n Pay': 84.99, Checkers: 77.99, Woolworths: 89.99, 'OK Foods': 81.99 },
  'Wine (750ml)': { Spar: 89.99, 'Pick n Pay': 94.99, Checkers: 87.99, Woolworths: 99.99, 'OK Foods': 91.99 },
  'Biscuits (200g)': { Spar: 12.99, 'Pick n Pay': 14.99, Checkers: 11.99, Woolworths: 16.99, 'OK Foods': 13.49 },
  'Chocolate (100g)': { Spar: 9.99, 'Pick n Pay': 11.99, Checkers: 9.49, Woolworths: 12.99, 'OK Foods': 10.49 },
  'Ice Cream (1L)': { Spar: 34.99, 'Pick n Pay': 36.99, Checkers: 32.99, Woolworths: 39.99, 'OK Foods': 35.99 },
  'Cereal (500g)': { Spar: 24.99, 'Pick n Pay': 26.99, Checkers: 23.99, Woolworths: 29.99, 'OK Foods': 25.49 },
  'Honey (500g)': { Spar: 39.99, 'Pick n Pay': 42.99, Checkers: 37.99, Woolworths: 45.99, 'OK Foods': 41.99 },
  'Jam (400g)': { Spar: 19.99, 'Pick n Pay': 21.99, Checkers: 18.99, Woolworths: 23.99, 'OK Foods': 20.49 },
  'Peanuts (200g)': { Spar: 14.99, 'Pick n Pay': 16.99, Checkers: 13.99, Woolworths: 18.99, 'OK Foods': 15.49 },
  'Chips (150g)': { Spar: 11.99, 'Pick n Pay': 13.99, Checkers: 10.99, Woolworths: 15.99, 'OK Foods': 12.49 },
  'Soap (100g)': { Spar: 6.99, 'Pick n Pay': 7.99, Checkers: 6.49, Woolworths: 8.99, 'OK Foods': 7.49 },
  'Shampoo (400ml)': { Spar: 24.99, 'Pick n Pay': 26.99, Checkers: 23.99, Woolworths: 29.99, 'OK Foods': 25.49 },
  'Toothpaste (100ml)': { Spar: 14.99, 'Pick n Pay': 16.99, Checkers: 13.99, Woolworths: 18.99, 'OK Foods': 15.49 },
  'Deodorant (150ml)': { Spar: 19.99, 'Pick n Pay': 21.99, Checkers: 18.99, Woolworths: 23.99, 'OK Foods': 20.49 },
  'Toilet Paper (12 roll)': { Spar: 34.99, 'Pick n Pay': 36.99, Checkers: 32.99, Woolworths: 39.99, 'OK Foods': 35.99 },
  'Dish Soap (500ml)': { Spar: 12.99, 'Pick n Pay': 14.99, Checkers: 11.99, Woolworths: 16.99, 'OK Foods': 13.49 },
  'Laundry Detergent (1L)': { Spar: 29.99, 'Pick n Pay': 31.99, Checkers: 28.99, Woolworths: 34.99, 'OK Foods': 30.49 },
};

async function seedPrices() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'mzansi_specials',
  });

  try {
    console.log('🌱 Starting to seed realistic prices...');

    for (const [productName, storePrices] of Object.entries(REALISTIC_PRICES)) {
      // Find product ID
      const [products] = await connection.execute(
        'SELECT id FROM products WHERE name = ?',
        [productName]
      );

      if (products.length === 0) {
        console.log(`⚠️  Product not found: ${productName}`);
        continue;
      }

      const productId = products[0].id;

      // Delete existing prices for this product
      await connection.execute(
        'DELETE FROM prices WHERE productId = ?',
        [productId]
      );

      // Insert new prices for each store
      for (const [storeName, price] of Object.entries(storePrices)) {
        const originalPrice = Math.round(price * 1.15); // 15% markup as original price
        const discount = Math.round(((originalPrice - price) / originalPrice) * 100);

        await connection.execute(
          'INSERT INTO prices (productId, storeName, price, originalPrice, discount, url, lastUpdated, createdAt) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())',
          [
            productId,
            storeName,
            Math.round(price * 100), // Store as cents
            Math.round(originalPrice * 100),
            discount,
            `https://${storeName.toLowerCase().replace(/\s+/g, '')}.co.za/search?q=${encodeURIComponent(productName)}`,
          ]
        );
      }

      console.log(`✅ Seeded prices for: ${productName}`);
    }

    console.log('🎉 All prices seeded successfully!');
  } catch (error) {
    console.error('❌ Error seeding prices:', error);
  } finally {
    await connection.end();
  }
}

seedPrices();
