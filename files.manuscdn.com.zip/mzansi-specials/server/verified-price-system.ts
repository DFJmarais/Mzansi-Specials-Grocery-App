import { getDb } from "./db";
import { products, prices } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { scrapeAllRetailersForProduct, closeBrowser } from "./scrapers/verified-scraper";

/**
 * Update prices for a product from live retailer websites
 * Only saves verified prices that pass validation
 */
export async function updateVerifiedPricesForProduct(productName: string) {
  try {
    console.log(`[Verified Price System] Updating prices for "${productName}"`);

    // Get product from database
    const db = await getDb();
    if (!db) {
      console.error("[Verified Price System] Database not available");
      return;
    }

    const product = await db
      .select()
      .from(products)
      .where(eq(products.name, productName))
      .limit(1);

    if (product.length === 0) {
      console.log(`[Verified Price System] Product not found: "${productName}"`);
      return;
    }

    const productId = product[0].id;

    // Scrape prices from all retailers
    const verifiedPrices = await scrapeAllRetailersForProduct(productName);

    if (verifiedPrices.length === 0) {
      console.log(`[Verified Price System] No verified prices found for "${productName}"`);
      return;
    }

    // Save each verified price to database
    for (const vp of verifiedPrices) {
      try {
        // Delete old prices for this product/store combo
        await db
          .delete(prices)
          .where(
            eq(prices.productId, productId)
          );

        // Insert new verified price
        await db.insert(prices).values({
          productId,
          storeName: vp.storeName,
          price: vp.price,
          originalPrice: vp.price, // No discount for verified prices
          discount: 0,
          url: vp.url,
          trustScore: vp.confidence,
          trustLevel: vp.confidence >= 90 ? "HIGH" : "MEDIUM",
          verificationStatus: "VERIFIED",
          sourcesCount: 1,
          lastUpdated: new Date(),
          lastVerified: new Date(),
        });

        console.log(
          `[Verified Price System] ✓ Saved ${vp.storeName}: R${(vp.price / 100).toFixed(2)} for "${productName}"`
        );
      } catch (error) {
        console.error(
          `[Verified Price System] Error saving price for ${vp.storeName}:`,
          error
        );
      }
    }

    console.log(
      `[Verified Price System] ✓ Updated ${verifiedPrices.length} verified prices for "${productName}"`
    );
  } catch (error) {
    console.error("[Verified Price System] Error:", error);
  }
}

/**
 * Update verified prices for all products in database
 * Runs in batches to avoid overwhelming the system
 */
export async function updateAllVerifiedPrices() {
  try {
    console.log("[Verified Price System] Starting full price verification update");

    const db = await getDb();
    if (!db) {
      console.error("[Verified Price System] Database not available");
      return;
    }

    // Get all products
    const allProducts = await db.select({ name: products.name }).from(products);

    console.log(
      `[Verified Price System] Updating ${allProducts.length} products...`
    );

    // Update in batches of 5 to avoid overwhelming retailers
    const batchSize = 5;
    for (let i = 0; i < allProducts.length; i += batchSize) {
      const batch = allProducts.slice(i, i + batchSize);

      // Process batch in parallel
      await Promise.all(
        batch.map((p) => updateVerifiedPricesForProduct(p.name))
      );

      console.log(
        `[Verified Price System] Processed ${Math.min(i + batchSize, allProducts.length)}/${allProducts.length} products`
      );

      // Wait 2 seconds between batches to be respectful to retailers
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }

    console.log("[Verified Price System] ✓ Full price verification complete");
  } catch (error) {
    console.error("[Verified Price System] Error:", error);
  } finally {
    // Close browser to free resources
    await closeBrowser();
  }
}

/**
 * Get the best verified price for a product
 */
export async function getBestVerifiedPrice(productName: string) {
  try {
    const db = await getDb();
    if (!db) return null;

    const product = await db
      .select()
      .from(products)
      .where(eq(products.name, productName))
      .limit(1);

    if (product.length === 0) return null;

    const productId = product[0].id;

    // Get lowest verified price
    const result = await db
      .select()
      .from(prices)
      .where(
        eq(prices.productId, productId)
      )
      .orderBy(prices.price);

    if (result.length === 0) return null;

    return result[0];
  } catch (error) {
    console.error("[Verified Price System] Error getting best price:", error);
    return null;
  }
}

/**
 * Get all verified prices for a product
 */
export async function getAllVerifiedPrices(productName: string) {
  try {
    const db = await getDb();
    if (!db) return [];

    const product = await db
      .select()
      .from(products)
      .where(eq(products.name, productName))
      .limit(1);

    if (product.length === 0) return [];

    const productId = product[0].id;

    return await db
      .select()
      .from(prices)
      .where(
        eq(prices.productId, productId)
      )
      .orderBy(prices.price);
  } catch (error) {
    console.error("[Verified Price System] Error getting all prices:", error);
    return [];
  }
}
