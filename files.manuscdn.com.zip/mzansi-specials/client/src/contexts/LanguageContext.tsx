import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { Language, LANGUAGES, t as translate } from '@/i18n/translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  languages: Record<Language, string>;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    // Get language from localStorage or default to English
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('mzansi-language');
      return (saved as Language) || 'en';
    }
    return 'en';
  });

  const setLanguage = useCallback((lang: Language) => {
    console.log('[LanguageContext] Setting language to:', lang);
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('mzansi-language', lang);
      document.documentElement.lang = lang;
    }
  }, []);

  const t = useCallback((key: string) => {
    const translation = translate(key, language);
    return translation;
  }, [language]);

  const value: LanguageContextType = {
    language,
    setLanguage,
    t,
    languages: LANGUAGES,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}
