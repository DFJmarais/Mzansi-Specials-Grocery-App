import React, { createContext, useContext, useState, useEffect } from 'react';

export interface PriceRecord {
  productId: string;
  productName: string;
  store: string;
  price: number;
  timestamp: number;
}

interface ComparisonHistoryContextType {
  history: PriceRecord[];
  addRecord: (record: Omit<PriceRecord, 'timestamp'>) => void;
  getProductHistory: (productId: string) => PriceRecord[];
  getPriceChange: (productId: string, store: string) => { change: number; percent: number } | null;
  clearHistory: () => void;
}

const ComparisonHistoryContext = createContext<ComparisonHistoryContextType | undefined>(undefined);

export function ComparisonHistoryProvider({ children }: { children: React.ReactNode }) {
  const [history, setHistory] = useState<PriceRecord[]>(() => {
    const saved = localStorage.getItem('mzansi-price-history');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('mzansi-price-history', JSON.stringify(history));
  }, [history]);

  const addRecord = (record: Omit<PriceRecord, 'timestamp'>) => {
    setHistory(prev => [
      ...prev,
      { ...record, timestamp: Date.now() }
    ].slice(-1000)); // Keep last 1000 records
  };

  const getProductHistory = (productId: string) => {
    return history.filter(r => r.productId === productId);
  };

  const getPriceChange = (productId: string, store: string) => {
    const records = history
      .filter(r => r.productId === productId && r.store === store)
      .sort((a, b) => a.timestamp - b.timestamp);

    if (records.length < 2) return null;

    const oldPrice = records[0].price;
    const newPrice = records[records.length - 1].price;
    const change = newPrice - oldPrice;
    const percent = (change / oldPrice) * 100;

    return { change, percent };
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return (
    <ComparisonHistoryContext.Provider
      value={{
        history,
        addRecord,
        getProductHistory,
        getPriceChange,
        clearHistory,
      }}
    >
      {children}
    </ComparisonHistoryContext.Provider>
  );
}

export function useComparisonHistory() {
  const context = useContext(ComparisonHistoryContext);
  if (!context) {
    throw new Error('useComparisonHistory must be used within ComparisonHistoryProvider');
  }
  return context;
}
