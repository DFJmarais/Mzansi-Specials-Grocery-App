import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations, Translations } from './translations';

// All 11 official languages of South Africa
type Language = 'en' | 'zu' | 'xh' | 'st' | 'af' | 'nr' | 'ss' | 'tn' | 'ts' | 've' | 'nd';

interface TranslationsInterface extends Translations {}


interface MultiLanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  availableLanguages: Array<{ code: Language; name: string; nativeName: string }>;
}

const MultiLanguageContext = createContext<MultiLanguageContextType | undefined>(undefined);

const AVAILABLE_LANGUAGES: Array<{ code: Language; name: string; nativeName: string }> = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'zu', name: 'Zulu', nativeName: 'isiZulu' },
  { code: 'xh', name: 'Xhosa', nativeName: 'isiXhosa' },
  { code: 'st', name: 'Sotho', nativeName: 'Sesotho' },
  { code: 'af', name: 'Afrikaans', nativeName: 'Afrikaans' },
  { code: 'nr', name: 'Ndebele', nativeName: 'isiNdebele' },
  { code: 'ss', name: 'Swati', nativeName: 'SiSwati' },
  { code: 'tn', name: 'Tswana', nativeName: 'Setswana' },
  { code: 'ts', name: 'Tsonga', nativeName: 'Xitsonga' },
  { code: 've', name: 'Venda', nativeName: 'Tshivenda' },
  { code: 'nd', name: 'North Ndebele', nativeName: 'isiNdebele' },
];

export function MultiLanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('mzansi-language') as Language | null;
    return saved || 'en';
  });

  useEffect(() => {
    localStorage.setItem('mzansi-language', language);
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return (
    <MultiLanguageContext.Provider value={{ language, setLanguage, t, availableLanguages: AVAILABLE_LANGUAGES }}>
      {children}
    </MultiLanguageContext.Provider>
  );
}

export function useMultiLanguage() {
  const context = useContext(MultiLanguageContext);
  if (!context) {
    throw new Error('useMultiLanguage must be used within MultiLanguageProvider');
  }
  return context;
}
