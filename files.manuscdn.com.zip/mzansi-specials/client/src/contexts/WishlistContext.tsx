import React, { createContext, useContext, useState, useEffect } from 'react';

export interface WishlistItem {
  id: string;
  name: string;
  category: string;
  prices: Array<{ store: string; price: number }>;
  addedAt: number;
}

interface WishlistContextType {
  wishlist: WishlistItem[];
  addToWishlist: (item: WishlistItem) => void;
  removeFromWishlist: (itemId: string) => void;
  isInWishlist: (itemId: string) => boolean;
  clearWishlist: () => void;
  exportWishlist: () => string;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [wishlist, setWishlist] = useState<WishlistItem[]>(() => {
    const saved = localStorage.getItem('mzansi-wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('mzansi-wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  const addToWishlist = (item: WishlistItem) => {
    setWishlist(prev => {
      const exists = prev.some(w => w.id === item.id);
      if (exists) return prev;
      return [...prev, { ...item, addedAt: Date.now() }];
    });
  };

  const removeFromWishlist = (itemId: string) => {
    setWishlist(prev => prev.filter(w => w.id !== itemId));
  };

  const isInWishlist = (itemId: string) => {
    return wishlist.some(w => w.id === itemId);
  };

  const clearWishlist = () => {
    setWishlist([]);
  };

  const exportWishlist = () => {
    const csv = [
      ['Product', 'Category', 'Best Price', 'Store', 'Added Date'].join(','),
      ...wishlist.map(item => {
        const bestPrice = item.prices.reduce((min, p) => p.price < min.price ? p : min);
        return [
          `"${item.name}"`,
          item.category,
          bestPrice.price,
          bestPrice.store,
          new Date(item.addedAt).toLocaleDateString()
        ].join(',');
      })
    ].join('\n');
    return csv;
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlist,
        addToWishlist,
        removeFromWishlist,
        isInWishlist,
        clearWishlist,
        exportWishlist,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlist must be used within WishlistProvider');
  }
  return context;
}
