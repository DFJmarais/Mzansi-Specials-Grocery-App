import React, { createContext, useContext, useState, useEffect } from 'react';

interface AccessibilitySettings {
  darkMode: boolean;
  fontSize: 'small' | 'normal' | 'large' | 'extra-large';
  highContrast: boolean;
  textToSpeech: boolean;
  keyboardNavigation: boolean;
}

interface AccessibilityContextType {
  settings: AccessibilitySettings;
  updateSettings: (settings: Partial<AccessibilitySettings>) => void;
  toggleDarkMode: () => void;
  increaseFontSize: () => void;
  decreaseFontSize: () => void;
  toggleHighContrast: () => void;
  toggleTextToSpeech: () => void;
  toggleKeyboardNavigation: () => void;
  speak: (text: string) => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

const FONT_SIZE_MAP = {
  'small': 0.85,
  'normal': 1,
  'large': 1.2,
  'extra-large': 1.4,
};

const FONT_SIZE_ORDER: Array<'small' | 'normal' | 'large' | 'extra-large'> = ['small', 'normal', 'large', 'extra-large'];

export function AccessibilityProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<AccessibilitySettings>(() => {
    // Load from localStorage
    const saved = localStorage.getItem('accessibilitySettings');
    if (saved) {
      return JSON.parse(saved);
    }
    return {
      darkMode: false,
      fontSize: 'normal',
      highContrast: false,
      textToSpeech: false,
      keyboardNavigation: false,
    };
  });

  // Save to localStorage whenever settings change
  useEffect(() => {
    localStorage.setItem('accessibilitySettings', JSON.stringify(settings));
    
    // Apply dark mode
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // Apply font size
    const scale = FONT_SIZE_MAP[settings.fontSize];
    document.documentElement.style.fontSize = `${16 * scale}px`;

    // Apply high contrast
    if (settings.highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }

    // Apply keyboard navigation
    if (settings.keyboardNavigation) {
      document.documentElement.classList.add('keyboard-nav');
    } else {
      document.documentElement.classList.remove('keyboard-nav');
    }
  }, [settings]);

  const updateSettings = (newSettings: Partial<AccessibilitySettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const toggleDarkMode = () => {
    updateSettings({ darkMode: !settings.darkMode });
  };

  const increaseFontSize = () => {
    const currentIndex = FONT_SIZE_ORDER.indexOf(settings.fontSize);
    if (currentIndex < FONT_SIZE_ORDER.length - 1) {
      updateSettings({ fontSize: FONT_SIZE_ORDER[currentIndex + 1] });
    }
  };

  const decreaseFontSize = () => {
    const currentIndex = FONT_SIZE_ORDER.indexOf(settings.fontSize);
    if (currentIndex > 0) {
      updateSettings({ fontSize: FONT_SIZE_ORDER[currentIndex - 1] });
    }
  };

  const toggleHighContrast = () => {
    updateSettings({ highContrast: !settings.highContrast });
  };

  const toggleTextToSpeech = () => {
    updateSettings({ textToSpeech: !settings.textToSpeech });
  };

  const toggleKeyboardNavigation = () => {
    updateSettings({ keyboardNavigation: !settings.keyboardNavigation });
  };

  const speak = (text: string) => {
    if (!settings.textToSpeech || !('speechSynthesis' in window)) {
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;

    window.speechSynthesis.speak(utterance);
  };

  return (
    <AccessibilityContext.Provider
      value={{
        settings,
        updateSettings,
        toggleDarkMode,
        increaseFontSize,
        decreaseFontSize,
        toggleHighContrast,
        toggleTextToSpeech,
        toggleKeyboardNavigation,
        speak,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error('useAccessibility must be used within AccessibilityProvider');
  }
  return context;
}
