import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface OfflineModeContextType {
  isOnline: boolean;
  isOfflineMode: boolean;
  toggleOfflineMode: () => void;
}

const OfflineModeContext = createContext<OfflineModeContextType | undefined>(undefined);

export function OfflineModeProvider({ children }: { children: React.ReactNode }) {
  const [isOnline, setIsOnline] = useState(true);
  const [isOfflineMode, setIsOfflineMode] = useState(() => {
    const saved = localStorage.getItem('mzansi-offline-mode');
    return saved ? JSON.parse(saved) : false;
  });

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Check initial status
    setIsOnline(navigator.onLine);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('mzansi-offline-mode', JSON.stringify(isOfflineMode));
  }, [isOfflineMode]);

  const toggleOfflineMode = () => {
    setIsOfflineMode((prev: boolean) => !prev);
  };

  return (
    <OfflineModeContext.Provider
      value={{
        isOnline,
        isOfflineMode,
        toggleOfflineMode,
      }}
    >
      {children}
    </OfflineModeContext.Provider>
  );
}

export function useOfflineMode() {
  const context = useContext(OfflineModeContext);
  if (!context) {
    throw new Error('useOfflineMode must be used within OfflineModeProvider');
  }
  return context;
}
