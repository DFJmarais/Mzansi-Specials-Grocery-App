import React, { createContext, useContext, useState, useEffect } from 'react';

export type SubscriptionTier = 'free' | 'plus' | 'pro';

export interface SubscriptionContextType {
  tier: SubscriptionTier;
  setTier: (tier: SubscriptionTier) => void;
  features: {
    products: number;
    search: boolean;
    priceAlerts: boolean;
    shoppingLists: boolean;
    barcodeScanning: boolean;
    receiptOCR: boolean;
    analytics: boolean;
    prioritySupport: boolean;
  };
  hasFeature: (feature: keyof SubscriptionContextType['features']) => boolean;
  isSubscribed: boolean;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tier, setTier] = useState<SubscriptionTier>('free');

  const features = {
    free: {
      products: 50,
      search: true,
      priceAlerts: false,
      shoppingLists: false,
      barcodeScanning: false,
      receiptOCR: false,
      analytics: false,
      prioritySupport: false,
    },
    plus: {
      products: 1500,
      search: true,
      priceAlerts: true,
      shoppingLists: true,
      barcodeScanning: true,
      receiptOCR: false,
      analytics: false,
      prioritySupport: false,
    },
    pro: {
      products: 1500,
      search: true,
      priceAlerts: true,
      shoppingLists: true,
      barcodeScanning: true,
      receiptOCR: true,
      analytics: true,
      prioritySupport: true,
    },
  };

  const currentFeatures = features[tier];
  const isSubscribed = tier !== 'free';

  const hasFeature = (feature: keyof typeof currentFeatures): boolean => {
    return currentFeatures[feature] as boolean;
  };

  useEffect(() => {
    // Load subscription tier from localStorage
    const savedTier = localStorage.getItem('subscriptionTier') as SubscriptionTier;
    if (savedTier) {
      setTier(savedTier);
    }
  }, []);

  useEffect(() => {
    // Save subscription tier to localStorage
    localStorage.setItem('subscriptionTier', tier);
  }, [tier]);

  return (
    <SubscriptionContext.Provider
      value={{
        tier,
        setTier,
        features: currentFeatures,
        hasFeature,
        isSubscribed,
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
};

export const useSubscription = () => {
  const context = useContext(SubscriptionContext);
  if (!context) {
    throw new Error('useSubscription must be used within SubscriptionProvider');
  }
  return context;
};
