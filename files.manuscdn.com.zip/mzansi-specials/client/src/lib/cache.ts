/**
 * Offline Cache Service
 * Persists prices and product data locally for offline support
 */

export interface CachedPrice {
  productId: string;
  retailer: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  lastUpdated: number; // timestamp
}

export interface CacheMetadata {
  lastSyncTime: number;
  version: string;
  itemCount: number;
}

const CACHE_KEYS = {
  PRICES: 'mzansi_prices_cache',
  PRODUCTS: 'mzansi_products_cache',
  METADATA: 'mzansi_cache_metadata',
};

const CACHE_DURATION_MS = 60 * 60 * 1000; // 1 hour

export class OfflineCache {
  /**
   * Save prices to local cache
   */
  static savePrices(prices: CachedPrice[]): boolean {
    try {
      const now = Date.now();
      const data = {
        prices,
        timestamp: now,
      };

      localStorage.setItem(CACHE_KEYS.PRICES, JSON.stringify(data));

      // Update metadata
      this.updateMetadata({
        lastSyncTime: now,
        version: '1.0',
        itemCount: prices.length,
      });

      console.log(`[Cache] ✓ Saved ${prices.length} prices to local cache`);
      return true;
    } catch (error) {
      console.error('[Cache] Failed to save prices:', error);
      return false;
    }
  }

  /**
   * Load prices from local cache
   */
  static loadPrices(): CachedPrice[] {
    try {
      const data = localStorage.getItem(CACHE_KEYS.PRICES);
      if (!data) return [];

      const parsed = JSON.parse(data);
      const prices = parsed.prices || [];

      console.log(`[Cache] ✓ Loaded ${prices.length} prices from local cache`);
      return prices;
    } catch (error) {
      console.error('[Cache] Failed to load prices:', error);
      return [];
    }
  }

  /**
   * Get cache age in hours
   */
  static getCacheAge(): number {
    try {
      const data = localStorage.getItem(CACHE_KEYS.PRICES);
      if (!data) return Infinity;

      const parsed = JSON.parse(data);
      const timestamp = parsed.timestamp || 0;
      const ageMs = Date.now() - timestamp;
      const ageHours = Math.round(ageMs / (60 * 60 * 1000) * 10) / 10;

      return ageHours;
    } catch (error) {
      return Infinity;
    }
  }

  /**
   * Check if cache is still valid
   */
  static isCacheValid(): boolean {
    const age = this.getCacheAge();
    return age < 1; // Cache valid for 1 hour
  }

  /**
   * Get cache status badge text
   */
  static getCacheStatusText(): string {
    const age = this.getCacheAge();

    if (age === Infinity) {
      return 'No cached data';
    }

    if (age < 0.1) {
      return 'Updated just now';
    }

    if (age < 1) {
      const minutes = Math.round(age * 60);
      return `Updated ${minutes}m ago`;
    }

    if (age < 24) {
      const hours = Math.round(age);
      return `Updated ${hours}h ago`;
    }

    const days = Math.round(age / 24);
    return `Updated ${days}d ago`;
  }

  /**
   * Clear all cache
   */
  static clearCache(): boolean {
    try {
      localStorage.removeItem(CACHE_KEYS.PRICES);
      localStorage.removeItem(CACHE_KEYS.PRODUCTS);
      localStorage.removeItem(CACHE_KEYS.METADATA);
      console.log('[Cache] ✓ Cache cleared');
      return true;
    } catch (error) {
      console.error('[Cache] Failed to clear cache:', error);
      return false;
    }
  }

  /**
   * Get cache metadata
   */
  static getMetadata(): CacheMetadata | null {
    try {
      const data = localStorage.getItem(CACHE_KEYS.METADATA);
      if (!data) return null;
      return JSON.parse(data);
    } catch (error) {
      return null;
    }
  }

  /**
   * Update cache metadata
   */
  private static updateMetadata(metadata: CacheMetadata): void {
    try {
      localStorage.setItem(CACHE_KEYS.METADATA, JSON.stringify(metadata));
    } catch (error) {
      console.error('[Cache] Failed to update metadata:', error);
    }
  }

  /**
   * Get best price from cache for a product
   */
  static getBestPrice(productId: string): CachedPrice | null {
    const prices = this.loadPrices();
    const productPrices = prices.filter(p => p.productId === productId);

    if (productPrices.length === 0) return null;

    return productPrices.reduce((min, p) => (p.price < min.price ? p : min));
  }

  /**
   * Get all prices from cache for a product
   */
  static getPricesForProduct(productId: string): CachedPrice[] {
    const prices = this.loadPrices();
    return prices.filter(p => p.productId === productId);
  }

  /**
   * Sync prices with backend
   */
  static async syncPrices(fetchFn: () => Promise<CachedPrice[]>): Promise<boolean> {
    try {
      console.log('[Cache] Starting price sync...');
      const prices = await fetchFn();
      return this.savePrices(prices);
    } catch (error) {
      console.error('[Cache] Sync failed:', error);
      return false;
    }
  }
}

/**
 * Hook for using offline cache in React components
 */
export function useOfflineCache() {
  const [cacheAge, setCacheAge] = React.useState<number>(OfflineCache.getCacheAge());
  const [isValid, setIsValid] = React.useState<boolean>(OfflineCache.isCacheValid());

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCacheAge(OfflineCache.getCacheAge());
      setIsValid(OfflineCache.isCacheValid());
    }, 60000); // Update every minute

    return () => clearInterval(interval);
  }, []);

  return {
    cacheAge,
    isValid,
    statusText: OfflineCache.getCacheStatusText(),
    loadPrices: OfflineCache.loadPrices,
    savePrices: OfflineCache.savePrices,
    clearCache: OfflineCache.clearCache,
  };
}

// Add React import
import React from 'react';
