import { useState, useCallback, useMemo } from 'react';

export interface FilterState {
  searchQuery: string;
  selectedCategory: string;
  priceRange: [number, number];
}

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  discount: number;
  store: string;
  category: string;
  isVerified: boolean;
}

const DEBOUNCE_DELAY = 300;

export function useProductFilter(products: Product[]) {
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    selectedCategory: 'all',
    priceRange: [0, 500],
  });

  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState('');

  // Debounced search input
  const handleSearchChange = useCallback((query: string) => {
    setFilters((prev) => ({ ...prev, searchQuery: query }));

    // Clear previous timeout
    const timeoutId = setTimeout(() => {
      setDebouncedSearchQuery(query);
    }, DEBOUNCE_DELAY);

    return () => clearTimeout(timeoutId);
  }, []);

  const handleCategoryChange = useCallback((category: string) => {
    setFilters((prev) => ({ ...prev, selectedCategory: category }));
  }, []);

  const handlePriceRangeChange = useCallback((range: [number, number]) => {
    setFilters((prev) => ({ ...prev, priceRange: range }));
  }, []);

  const handleClearFilters = useCallback(() => {
    setFilters({
      searchQuery: '',
      selectedCategory: 'all',
      priceRange: [0, 500],
    });
    setDebouncedSearchQuery('');
  }, []);

  // Filter products based on current filters
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Search filter
      const matchesSearch =
        debouncedSearchQuery === '' ||
        product.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
        product.store.toLowerCase().includes(debouncedSearchQuery.toLowerCase());

      // Category filter
      const matchesCategory =
        filters.selectedCategory === 'all' ||
        product.category.toLowerCase() === filters.selectedCategory.toLowerCase();

      // Price filter
      const matchesPrice =
        product.price >= filters.priceRange[0] && product.price <= filters.priceRange[1];

      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [products, debouncedSearchQuery, filters.selectedCategory, filters.priceRange]);

  // Check if any filters are active
  const hasActiveFilters = useMemo(() => {
    return (
      debouncedSearchQuery !== '' ||
      filters.selectedCategory !== 'all' ||
      filters.priceRange[0] !== 0 ||
      filters.priceRange[1] !== 500
    );
  }, [debouncedSearchQuery, filters.selectedCategory, filters.priceRange]);

  // Get unique categories from products
  const categories = useMemo(() => {
    const uniqueCategories = new Set(products.map((p) => p.category));
    return Array.from(uniqueCategories).sort();
  }, [products]);

  // Get price range from products
  const priceStats = useMemo(() => {
    if (products.length === 0) return { min: 0, max: 500 };
    const prices = products.map((p) => p.price);
    return {
      min: Math.floor(Math.min(...prices)),
      max: Math.ceil(Math.max(...prices)),
    };
  }, [products]);

  return {
    filters,
    filteredProducts,
    hasActiveFilters,
    categories,
    priceStats,
    handleSearchChange,
    handleCategoryChange,
    handlePriceRangeChange,
    handleClearFilters,
    searchQuery: filters.searchQuery,
    debouncedSearchQuery,
  };
}
