import React from 'react';
import { useWishlist, WishlistItem } from '@/contexts/WishlistContext';
import { Button } from '@/components/ui/button';
import { Heart } from 'lucide-react';

interface WishlistButtonProps {
  item: WishlistItem;
}

export function WishlistButton({ item }: WishlistButtonProps) {
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const inWishlist = isInWishlist(item.id);

  const handleToggle = () => {
    if (inWishlist) {
      removeFromWishlist(item.id);
    } else {
      addToWishlist(item);
    }
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={handleToggle}
      className={`${inWishlist ? 'text-red-500' : 'text-muted-foreground'}`}
      title={inWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
    >
      <Heart className={`w-5 h-5 ${inWishlist ? 'fill-current' : ''}`} />
    </Button>
  );
}
