import React, { useState, useEffect } from 'react';
import { useMultiLanguage } from '@/contexts/MultiLanguageContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Heart, Bell, Trash2, DollarSign, TrendingDown } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { trpc } from '@/lib/trpc';

interface Favorite {
  productId: number;
  productName: string;
  category: string;
  targetPrice: number;
  currentPrice: number;
  bestStore: string;
  savings: number;
  discount: number;
  alertEnabled: boolean;
  imageUrl?: string;
}

export function UserFavorites() {
  const { t } = useMultiLanguage();
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editPrice, setEditPrice] = useState<string>('');

  // Fetch live products with prices
  const { data: productsData } = trpc.products.getAllWithPrices.useQuery();

  // Process live data into favorites
  useEffect(() => {
    if (!productsData || productsData.length === 0) {
      setLoading(false);
      return;
    }

    // Get favorites from localStorage or demo data
    const savedFavorites = localStorage.getItem('mzansi-favorites');
    let favoriteIds: number[] = [];

    if (savedFavorites) {
      try {
        favoriteIds = JSON.parse(savedFavorites);
      } catch {
        // Use demo favorites if parsing fails
        favoriteIds = productsData.slice(0, 5).map(p => p.id);
      }
    } else {
      // Demo: Use first 5 products as favorites
      favoriteIds = productsData.slice(0, 5).map(p => p.id);
    }

    // Build favorites with live prices
    const favoritesList: Favorite[] = [];

    favoriteIds.forEach((productId) => {
      const product = productsData.find(p => p.id === productId);
      if (product && product.prices && product.prices.length > 0) {
        // Find best price
        const bestPrice = product.prices.reduce((min, p) => 
          p.price < min.price ? p : min
        );

        // Calculate savings if target price is set
        const targetPrice = parseFloat(localStorage.getItem(`target-price-${productId}`) || '0') || bestPrice.price * 1.2;
        const savings = Math.max(0, targetPrice - bestPrice.price);
        const discount = bestPrice.originalPrice 
          ? Math.round(((bestPrice.originalPrice - bestPrice.price) / bestPrice.originalPrice) * 100)
          : 0;

        favoritesList.push({
          productId: product.id,
          productName: product.name,
          category: product.category,
          targetPrice: targetPrice,
          currentPrice: bestPrice.price,
          bestStore: bestPrice.storeName,
          savings: savings,
          discount: discount,
          alertEnabled: localStorage.getItem(`alert-${productId}`) === 'true',
          imageUrl: product.imageUrl || undefined,
        });
      }
    });

    setFavorites(favoritesList);
    setLoading(false);
  }, [productsData]);

  const handleRemoveFavorite = (productId: number) => {
    setFavorites(favorites.filter(f => f.productId !== productId));
    const saved = localStorage.getItem('mzansi-favorites');
    if (saved) {
      const ids = JSON.parse(saved).filter((id: number) => id !== productId);
      localStorage.setItem('mzansi-favorites', JSON.stringify(ids));
    }
  };

  const handleToggleAlert = (productId: number) => {
    setFavorites(favorites.map(f => 
      f.productId === productId 
        ? { ...f, alertEnabled: !f.alertEnabled }
        : f
    ));
    const current = localStorage.getItem(`alert-${productId}`) === 'true';
    localStorage.setItem(`alert-${productId}`, (!current).toString());
  };

  const handleUpdateTargetPrice = (productId: number, newPrice: string) => {
    const price = parseFloat(newPrice);
    if (!isNaN(price) && price > 0) {
      localStorage.setItem(`target-price-${productId}`, price.toString());
      setFavorites(favorites.map(f => 
        f.productId === productId 
          ? { ...f, targetPrice: price, savings: Math.max(0, price - f.currentPrice) }
          : f
      ));
      setEditingId(null);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-8 bg-gray-200 rounded animate-pulse w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-48 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Heart className="w-6 h-6 text-red-500 fill-red-500" />
            {t('my_favorites') || 'My Favorites'}
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            {favorites.length} items saved with price tracking
          </p>
        </div>
      </div>

      {/* Favorites Grid */}
      {favorites.length === 0 ? (
        <Card className="p-12 text-center">
          <Heart className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
          <p className="text-lg text-muted-foreground mb-4">No favorites yet</p>
          <p className="text-sm text-muted-foreground">
            Add products to your favorites to track prices and get alerts
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {favorites.map((favorite) => (
            <Card
              key={favorite.productId}
              className="overflow-hidden hover:shadow-lg transition-all duration-300 border-l-4 border-l-red-500"
            >
              {/* Header */}
              <div className="bg-gradient-to-r from-red-50 to-pink-50 p-4 border-b border-red-200">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-foreground text-lg line-clamp-2">
                      {favorite.productName}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1">{favorite.category}</p>
                  </div>
                  {favorite.discount > 0 && (
                    <Badge className="bg-red-500 text-white whitespace-nowrap">
                      {favorite.discount}% OFF
                    </Badge>
                  )}
                </div>
              </div>

              {/* Price Section */}
              <div className="p-4 space-y-3">
                {/* Current Price */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-3 border border-green-200">
                  <p className="text-xs text-muted-foreground mb-1">Current Best Price</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-green-600">
                      R{(favorite.currentPrice / 100).toFixed(2)}
                    </span>
                    <span className="text-xs text-muted-foreground">at {favorite.bestStore}</span>
                  </div>
                </div>

                {/* Target Price */}
                <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg p-3 border border-blue-200">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs text-muted-foreground">Target Price</p>
                    {editingId === favorite.productId ? (
                      <button
                        onClick={() => setEditingId(null)}
                        className="text-xs text-blue-600 hover:text-blue-700 font-semibold"
                      >
                        Cancel
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          setEditingId(favorite.productId);
                          setEditPrice(favorite.targetPrice.toString());
                        }}
                        className="text-xs text-blue-600 hover:text-blue-700 font-semibold"
                      >
                        Edit
                      </button>
                    )}
                  </div>

                  {editingId === favorite.productId ? (
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        value={editPrice}
                        onChange={(e) => setEditPrice(e.target.value)}
                        placeholder="Enter target price"
                        className="flex-1 h-8 text-sm"
                      />
                      <Button
                        size="sm"
                        onClick={() => handleUpdateTargetPrice(favorite.productId, editPrice)}
                        className="h-8 px-3 text-xs"
                      >
                        Save
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold text-blue-600">
                        R{(favorite.targetPrice / 100).toFixed(2)}
                      </span>
                    </div>
                  )}
                </div>

                {/* Savings */}
                {favorite.savings > 0 && (
                  <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg p-3 border border-yellow-200 flex items-center gap-2">
                    <TrendingDown className="w-4 h-4 text-orange-600" />
                    <div>
                      <p className="text-xs text-muted-foreground">Potential Savings</p>
                      <p className="font-bold text-orange-600">R{(favorite.savings / 100).toFixed(2)}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="p-4 border-t border-border space-y-2">
                <Button
                  variant={favorite.alertEnabled ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleToggleAlert(favorite.productId)}
                  className="w-full flex items-center gap-2"
                >
                  <Bell className="w-4 h-4" />
                  {favorite.alertEnabled ? 'Alert Enabled' : 'Enable Alert'}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleRemoveFavorite(favorite.productId)}
                  className="w-full flex items-center gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                  Remove
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Info Card */}
      {favorites.length > 0 && (
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200 p-4">
          <h4 className="font-bold text-foreground mb-2 flex items-center gap-2">
            💡 Price Tracking Tips
          </h4>
          <ul className="space-y-1 text-sm text-foreground/80">
            <li>• Set your target price to get alerts when items drop below that price</li>
            <li>• We check prices every 6 hours across all retailers</li>
            <li>• Savings show how much you'll save if you buy at the current best price</li>
            <li>• Alerts are sent when your target price is reached</li>
          </ul>
        </Card>
      )}
    </div>
  );
}
