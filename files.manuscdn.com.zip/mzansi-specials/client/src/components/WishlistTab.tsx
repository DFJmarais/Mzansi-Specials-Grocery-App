import React from 'react';
import { useWishlist } from '@/contexts/WishlistContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Heart, Trash2, Share2 } from 'lucide-react';

export function WishlistTab() {
  const { wishlist, removeFromWishlist, clearWishlist, exportWishlist } = useWishlist();

  const handleExport = () => {
    const csv = exportWishlist();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mzansi-wishlist-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handleShare = async () => {
    if (!navigator.share) {
      alert('Sharing not supported on this device');
      return;
    }

    try {
      const text = wishlist
        .map(item => `${item.name} - Best price: R${Math.min(...item.prices.map(p => p.price)).toFixed(2)}`)
        .join('\n');

      await navigator.share({
        title: 'My Mzansi Specials Wishlist',
        text: text,
      });
    } catch (err) {
      console.error('Error sharing:', err);
    }
  };

  if (wishlist.length === 0) {
    return (
      <div className="min-h-screen bg-background py-12">
        <div className="container">
          <div className="text-center py-12">
            <Heart className="w-16 h-16 mx-auto text-muted-foreground mb-4 opacity-50" />
            <h2 className="text-2xl font-bold text-foreground mb-2">Your Wishlist is Empty</h2>
            <p className="text-muted-foreground">
              Add items to your wishlist by clicking the heart icon on products
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-bold text-primary">My Wishlist</h2>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleShare} className="gap-2">
              <Share2 className="w-4 h-4" />
              Share
            </Button>
            <Button variant="outline" onClick={handleExport} className="gap-2">
              Download
            </Button>
            <Button
              variant="destructive"
              onClick={clearWishlist}
              className="gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Clear All
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {wishlist.map(item => {
            const bestPrice = item.prices.reduce((min, p) => p.price < min.price ? p : min);
            const allPrices = item.prices;

            return (
              <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all border-2 border-primary/20">
                <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-4 border-b-2 border-primary/20">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-bold text-foreground text-lg">{item.name}</h3>
                      <p className="text-sm text-muted-foreground">{item.category}</p>
                    </div>
                    <button
                      onClick={() => removeFromWishlist(item.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Heart className="w-5 h-5 fill-current" />
                    </button>
                  </div>
                </div>

                <div className="p-4 bg-secondary/5 border-b-2 border-secondary/20">
                  <p className="text-xs text-muted-foreground mb-1">Best Price</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-secondary">R{bestPrice.price.toFixed(2)}</span>
                    <span className="text-sm text-muted-foreground">{bestPrice.store}</span>
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  <p className="text-xs font-semibold text-foreground/70 uppercase">All Prices</p>
                  {allPrices.map(priceInfo => (
                    <div
                      key={priceInfo.store}
                      className="flex items-center justify-between p-2 rounded-lg bg-muted/50"
                    >
                      <span className="text-sm font-medium">{priceInfo.store}</span>
                      <span className="text-sm font-bold">R{priceInfo.price.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>

        <div className="mt-8 p-4 bg-primary/10 rounded-lg border-2 border-primary/20">
          <p className="text-sm text-foreground">
            <strong>Total Items:</strong> {wishlist.length} | 
            <strong className="ml-4">Average Best Price:</strong> R{
              (wishlist.reduce((sum, item) => {
                const best = item.prices.reduce((min, p) => p.price < min.price ? p : min);
                return sum + best.price;
              }, 0) / wishlist.length).toFixed(2)
            }
          </p>
        </div>
      </div>
    </div>
  );
}
