import { useState } from 'react';
import { Heart, Share2, MessageCircle, TrendingUp, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { getLoginUrl } from '@/const';

/**
 * Community Feed - Users share their grocery savings and deals
 */
export default function CommunityFeed() {
  const { user, isAuthenticated } = useAuth();
  const [showPostForm, setShowPostForm] = useState(false);
  const [title, setTitle] = useState('');
  const [amountSaved, setAmountSaved] = useState('');
  const [store, setStore] = useState('');
  const [description, setDescription] = useState('');

  // Fetch community posts
  const { data: posts, isLoading } = trpc.community.getPosts.useQuery({ limit: 50 });
  
  // Create post mutation
  const createPostMutation = trpc.community.createPost.useMutation({
    onSuccess: () => {
      // Reset form
      setTitle('');
      setAmountSaved('');
      setStore('');
      setDescription('');
      setShowPostForm(false);
      // Refetch posts
      trpc.useUtils().community.getPosts.invalidate();
    },
  });

  const handleCreatePost = async () => {
    if (!title || !amountSaved) {
      alert('Please fill in title and amount saved');
      return;
    }

    await createPostMutation.mutateAsync({
      title,
      amountSaved: Math.round(parseFloat(amountSaved) * 100), // Convert to cents
      store: store || undefined,
      productCategory: undefined,
      description: description || undefined,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b-2 border-primary/20">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-primary">Community Savings</h1>
                <p className="text-xs text-muted-foreground">Share your deals and inspire others</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Feed */}
          <div className="lg:col-span-2">
            {/* Create Post Card */}
            {isAuthenticated && user ? (
              <Card className="mb-6 p-6 border-2 border-primary/20">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{user.name?.charAt(0) || 'U'}</span>
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{user.name || 'User'}</p>
                    <p className="text-xs text-muted-foreground">Share your savings</p>
                  </div>
                </div>

                {!showPostForm ? (
                  <Button
                    onClick={() => setShowPostForm(true)}
                    className="w-full bg-primary hover:bg-primary/90"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    Share a Saving
                  </Button>
                ) : (
                  <div className="space-y-4">
                    <Input
                      placeholder="What did you save on? (e.g., 'Found milk on special at Spar')"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="border-2 border-primary/30"
                    />
                    <Input
                      placeholder="Amount saved (R)"
                      type="number"
                      step="0.01"
                      value={amountSaved}
                      onChange={(e) => setAmountSaved(e.target.value)}
                      className="border-2 border-primary/30"
                    />
                    <Input
                      placeholder="Store (optional)"
                      value={store}
                      onChange={(e) => setStore(e.target.value)}
                      className="border-2 border-primary/30"
                    />
                    <textarea
                      placeholder="Tell us more about this deal... (optional)"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full p-3 border-2 border-primary/30 rounded-lg focus:border-primary outline-none"
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <Button
                        onClick={handleCreatePost}
                        disabled={createPostMutation.isPending}
                        className="flex-1 bg-primary hover:bg-primary/90"
                      >
                        {createPostMutation.isPending ? 'Posting...' : 'Post'}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setShowPostForm(false)}
                        className="flex-1"
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            ) : (
              <Card className="mb-6 p-6 border-2 border-primary/20 text-center">
                <p className="text-foreground mb-4">Sign in to share your savings with the community!</p>
                <Button
                  onClick={() => (window.location.href = getLoginUrl())}
                  className="bg-primary hover:bg-primary/90"
                >
                  Sign In
                </Button>
              </Card>
            )}

            {/* Posts Feed */}
            <div className="space-y-4">
              {isLoading ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Loading community posts...</p>
                </div>
              ) : posts && posts.length > 0 ? (
                posts.map((post) => (
                  <Card
                    key={post.id}
                    className="overflow-hidden hover:shadow-lg transition-all border-2 border-primary/20"
                  >
                    <div className="p-6">
                      {/* Post Header */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center">
                            <Zap className="w-5 h-5 text-accent" />
                          </div>
                          <div>
                            <p className="font-semibold text-foreground">Community Member</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(post.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        {post.store && (
                          <Badge className="bg-primary/20 text-primary">{post.store}</Badge>
                        )}
                      </div>

                      {/* Post Content */}
                      <h3 className="text-lg font-bold text-foreground mb-2">{post.title}</h3>
                      {post.description && (
                        <p className="text-foreground/80 mb-4">{post.description}</p>
                      )}

                      {/* Savings Highlight */}
                      <div className="bg-secondary/10 border-l-4 border-secondary p-4 mb-4 rounded">
                        <p className="text-xs text-muted-foreground mb-1">Amount Saved</p>
                        <p className="text-2xl font-bold text-secondary">
                          R{(post.amountSaved / 100).toFixed(2)}
                        </p>
                      </div>

                      {/* Post Actions */}
                      <div className="flex gap-4 pt-4 border-t border-border">
                        <button className="flex items-center gap-2 text-muted-foreground hover:text-accent transition">
                          <Heart className="w-5 h-5" />
                          <span className="text-sm">{post.likes}</span>
                        </button>
                        <button className="flex items-center gap-2 text-muted-foreground hover:text-primary transition">
                          <MessageCircle className="w-5 h-5" />
                          <span className="text-sm">Comment</span>
                        </button>
                        <button className="flex items-center gap-2 text-muted-foreground hover:text-primary transition ml-auto">
                          <Share2 className="w-5 h-5" />
                          <span className="text-sm">Share</span>
                        </button>
                      </div>
                    </div>
                  </Card>
                ))
              ) : (
                <Card className="p-12 text-center border-2 border-primary/20">
                  <p className="text-muted-foreground mb-4">No savings shared yet. Be the first!</p>
                  {isAuthenticated && user && (
                    <Button
                      onClick={() => setShowPostForm(true)}
                      className="bg-primary hover:bg-primary/90"
                    >
                      Share Your First Saving
                    </Button>
                  )}
                </Card>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Stats Card */}
            <Card className="p-6 mb-6 border-2 border-primary/20">
              <h3 className="font-bold text-foreground mb-4">Community Stats</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Total Savings Shared</p>
                  <p className="text-2xl font-bold text-secondary">
                    R{posts ? (posts.reduce((sum, p) => sum + p.amountSaved, 0) / 100).toFixed(2) : '0.00'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Active Members</p>
                  <p className="text-2xl font-bold text-primary">
                    {posts ? new Set(posts.map(p => p.userId)).size : 0}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Posts This Week</p>
                  <p className="text-2xl font-bold text-accent">{posts?.length || 0}</p>
                </div>
              </div>
            </Card>

            {/* Tips Card */}
            <Card className="p-6 border-2 border-primary/20">
              <h3 className="font-bold text-foreground mb-4">💡 Money-Saving Tips</h3>
              <ul className="space-y-3 text-sm">
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span className="text-foreground/80">Compare prices across stores before shopping</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span className="text-foreground/80">Look for weekly specials and promotions</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span className="text-foreground/80">Buy bulk items when on special</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span className="text-foreground/80">Use loyalty programs for extra savings</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
