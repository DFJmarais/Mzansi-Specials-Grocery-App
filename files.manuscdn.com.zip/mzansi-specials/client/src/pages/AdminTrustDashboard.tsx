/**
 * Admin Trust Dashboard
 * Monitor price verification, trust scores, and flagged items
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle2, AlertTriangle, Clock } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function AdminTrustDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"stats" | "flagged" | "low-confidence" | "stale">(
    "stats"
  );

  // Queries
  const statsQuery = trpc.trust.stats.useQuery(undefined, {
    enabled: user?.role === "admin",
    refetchInterval: 5 * 60 * 1000,
  });

  const flaggedQuery = trpc.trust.flaggedPrices.useQuery(
    { limit: 50 },
    {
      enabled: user?.role === "admin" && activeTab === "flagged",
    }
  );

  const lowConfidenceQuery = trpc.trust.lowConfidencePrices.useQuery(
    { limit: 50 },
    {
      enabled: user?.role === "admin" && activeTab === "low-confidence",
    }
  );

  const staleQuery = trpc.trust.stalePrices.useQuery(
    { limit: 50 },
    {
      enabled: user?.role === "admin" && activeTab === "stale",
    }
  );

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-muted-foreground">
            Only administrators can access the trust dashboard.
          </p>
        </Card>
      </div>
    );
  }

  const stats = statsQuery.data;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Trust Score Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor price verification and data quality across all products
          </p>
        </div>

        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Prices</p>
                  <p className="text-3xl font-bold">{stats.total}</p>
                </div>
                <CheckCircle2 className="w-8 h-8 text-blue-500" />
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">High Trust</p>
                  <p className="text-3xl font-bold">{stats.highTrust}</p>
                  <p className="text-xs text-green-600 mt-1">
                    {((stats.highTrust / stats.total) * 100).toFixed(1)}%
                  </p>
                </div>
                <div className="w-8 h-8 rounded-full bg-green-500" />
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Medium Trust</p>
                  <p className="text-3xl font-bold">{stats.mediumTrust}</p>
                  <p className="text-xs text-yellow-600 mt-1">
                    {((stats.mediumTrust / stats.total) * 100).toFixed(1)}%
                  </p>
                </div>
                <div className="w-8 h-8 rounded-full bg-yellow-500" />
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Low Trust</p>
                  <p className="text-3xl font-bold">{stats.lowTrust}</p>
                  <p className="text-xs text-red-600 mt-1">
                    {((stats.lowTrust / stats.total) * 100).toFixed(1)}%
                  </p>
                </div>
                <div className="w-8 h-8 rounded-full bg-red-500" />
              </div>
            </Card>
          </div>
        )}

        {stats && (
          <Card className="p-6 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Average Trust Score</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-bold">{stats.averageTrustScore}</span>
                  <span className="text-lg text-muted-foreground">/100</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground mb-2">Verification Status</p>
                <div className="space-y-1">
                  <p className="text-sm">
                    <Badge variant="outline" className="bg-green-50">
                      Verified: {stats.verified}
                    </Badge>
                  </p>
                  <p className="text-sm">
                    <Badge variant="outline" className="bg-yellow-50">
                      Unverified: {stats.unverified}
                    </Badge>
                  </p>
                  <p className="text-sm">
                    <Badge variant="outline" className="bg-red-50">
                      Flagged: {stats.flagged}
                    </Badge>
                  </p>
                </div>
              </div>
            </div>
          </Card>
        )}

        <div className="flex gap-2 mb-6 border-b">
          <button
            onClick={() => setActiveTab("stats")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "stats"
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            📊 Overview
          </button>
          <button
            onClick={() => setActiveTab("flagged")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "flagged"
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            🚨 Flagged Items
            {stats?.flagged ? <Badge className="ml-2 bg-red-500">{stats.flagged}</Badge> : null}
          </button>
          <button
            onClick={() => setActiveTab("low-confidence")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "low-confidence"
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            ⚠️ Low Confidence
            {stats?.lowTrust ? <Badge className="ml-2 bg-red-500">{stats.lowTrust}</Badge> : null}
          </button>
          <button
            onClick={() => setActiveTab("stale")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "stale"
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            ⏱️ Stale Data
          </button>
        </div>

        <div>
          {activeTab === "flagged" && (
            <FlaggedPricesTab data={flaggedQuery.data} isLoading={flaggedQuery.isLoading} />
          )}
          {activeTab === "low-confidence" && (
            <LowConfidenceTab data={lowConfidenceQuery.data} isLoading={lowConfidenceQuery.isLoading} />
          )}
          {activeTab === "stale" && (
            <StalePricesTab data={staleQuery.data} isLoading={staleQuery.isLoading} />
          )}
        </div>
      </div>
    </div>
  );
}

function FlaggedPricesTab({ data, isLoading }: any) {
  if (isLoading) {
    return <Card className="p-8 text-center text-muted-foreground">Loading flagged prices...</Card>;
  }

  if (!data || data.length === 0) {
    return (
      <Card className="p-8 text-center">
        <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
        <p className="text-lg font-semibold">All prices look good!</p>
        <p className="text-muted-foreground">No flagged items to review.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {data.map((price: any) => (
        <Card key={price.id} className="p-4 border-red-200 bg-red-50">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                <h3 className="font-semibold">{price.storeName}</h3>
                <Badge className="bg-red-500">Trust: {price.trustScore}/100</Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">Price: R{(price.price / 100).toFixed(2)}</p>
              {price.flags && price.flags.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {price.flags.map((flag: string) => (
                    <Badge key={flag} variant="outline" className="bg-white">
                      {flag}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

function LowConfidenceTab({ data, isLoading }: any) {
  if (isLoading) {
    return (
      <Card className="p-8 text-center text-muted-foreground">Loading low confidence prices...</Card>
    );
  }

  if (!data || data.length === 0) {
    return (
      <Card className="p-8 text-center">
        <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
        <p className="text-lg font-semibold">All prices meet confidence threshold!</p>
        <p className="text-muted-foreground">No low confidence items.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {data.map((price: any) => (
        <Card key={price.id} className="p-4 border-yellow-200 bg-yellow-50">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-5 h-5 text-yellow-600" />
                <h3 className="font-semibold">{price.storeName}</h3>
                <Badge className="bg-yellow-600">Trust: {price.trustScore}/100</Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">Price: R{(price.price / 100).toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">
                Last verified: {price.lastVerified ? new Date(price.lastVerified).toLocaleString() : "Never"}
              </p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

function StalePricesTab({ data, isLoading }: any) {
  if (isLoading) {
    return <Card className="p-8 text-center text-muted-foreground">Loading stale prices...</Card>;
  }

  if (!data || data.length === 0) {
    return (
      <Card className="p-8 text-center">
        <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
        <p className="text-lg font-semibold">All prices are fresh!</p>
        <p className="text-muted-foreground">No stale data detected.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {data.map((price: any) => (
        <Card key={price.id} className="p-4 border-gray-200">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-5 h-5 text-gray-500" />
                <h3 className="font-semibold">{price.storeName}</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-2">Price: R{(price.price / 100).toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">
                Last updated: {new Date(price.lastUpdated).toLocaleString()}
              </p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
