import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { Plus, Trash2, Share2, Download, TrendingDown, AlertCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { FC } from 'react';

/**
 * SHOPPING LIST PAGE - Cost Optimization & Cheapest Basket
 * 
 * Purpose: Help users find the cheapest basket across retailers
 * Design: Item list, multi-retailer comparison, savings highlights
 */

interface ShoppingListItem {
  id: number;
  name: string;
  quantity: number;
  category: string;
}

const ShoppingList: FC = () => {
  const [, setLocation] = useLocation();
  const { t } = useTranslation();
  const [items, setItems] = useState<ShoppingListItem[]>([
    { id: 1, name: 'Full Cream Milk 1L', quantity: 2, category: 'Dairy' },
    { id: 2, name: 'Bread White Loaf', quantity: 1, category: 'Bakery' },
    { id: 3, name: 'Chicken Breast 1kg', quantity: 1, category: 'Meat' },
    { id: 4, name: 'Tomatoes 1kg', quantity: 2, category: 'Produce' },
    { id: 5, name: 'Rice 5kg', quantity: 1, category: 'Pantry' },
  ]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemQuantity, setNewItemQuantity] = useState(1);
  const [listName, setListName] = useState('Weekly Shopping');

  // Mock retailer prices
  const mockPrices: Record<string, Record<string, number>> = {
    'Full Cream Milk 1L': { 'Checkers': 17.99, 'Pick n Pay': 19.99, 'SPAR': 18.99, 'Woolworths': 20.99, 'OK Foods': 16.99 },
    'Bread White Loaf': { 'Checkers': 8.49, 'Pick n Pay': 7.99, 'SPAR': 8.99, 'Woolworths': 9.49, 'OK Foods': 7.49 },
    'Chicken Breast 1kg': { 'Checkers': 54.99, 'Pick n Pay': 64.99, 'SPAR': 59.99, 'Woolworths': 65.99, 'OK Foods': 55.99 },
    'Tomatoes 1kg': { 'Checkers': 11.99, 'Pick n Pay': 12.99, 'SPAR': 12.99, 'Woolworths': 9.99, 'OK Foods': 13.99 },
    'Rice 5kg': { 'Checkers': 75.99, 'Pick n Pay': 82.99, 'SPAR': 79.99, 'Woolworths': 84.99, 'OK Foods': 78.99 },
  };

  const retailers = ['Checkers', 'Pick n Pay', 'SPAR', 'Woolworths', 'OK Foods'];

  // Calculate totals for each retailer
  const retailerTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    retailers.forEach(retailer => {
      totals[retailer] = 0;
      items.forEach(item => {
        const itemPrices = mockPrices[item.name];
        if (itemPrices && itemPrices[retailer]) {
          totals[retailer] += itemPrices[retailer] * item.quantity;
        }
      });
    });
    return totals;
  }, [items]);

  // Find cheapest and most expensive
  const cheapestRetailer = useMemo(() => {
    const retailer = Object.entries(retailerTotals).reduce((a, b) => a[1] < b[1] ? a : b);
    return { name: retailer[0], total: retailer[1] };
  }, [retailerTotals]);

  const mostExpensiveRetailer = useMemo(() => {
    const retailer = Object.entries(retailerTotals).reduce((a, b) => a[1] > b[1] ? a : b);
    return { name: retailer[0], total: retailer[1] };
  }, [retailerTotals]);

  const totalSavings = mostExpensiveRetailer.total - cheapestRetailer.total;
  const savingsPercent = Math.round((totalSavings / mostExpensiveRetailer.total) * 100);

  const addItem = () => {
    if (newItemName.trim()) {
      setItems([...items, {
        id: Math.max(...items.map(i => i.id), 0) + 1,
        name: newItemName,
        quantity: newItemQuantity,
        category: 'Other',
      }]);
      setNewItemName('');
      setNewItemQuantity(1);
    }
  };

  const removeItem = (id: number) => {
    setItems(items.filter(i => i.id !== id));
  };

  const updateQuantity = (id: number, quantity: number) => {
    setItems(items.map(i => i.id === id ? { ...i, quantity: Math.max(1, quantity) } : i));
  };

  return (
    <div className="main-content" style={{ background: '#FFFFFF' }}>
      {/* HEADER */}
      <div style={{
        background: 'linear-gradient(135deg, #FF6600 0%, #E55A00 100%)',
        color: 'white',
        padding: '1.5rem 1rem',
        marginBottom: '2rem',
      }}>
        <div className="container" style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <h1 style={{ fontSize: '2rem', fontWeight: 800, margin: 0, marginBottom: '0.5rem' }}>
            🛒 {listName}
          </h1>
          <p style={{ fontSize: '1rem', opacity: 0.9, margin: 0 }}>
            {t('list.compareAndSave', 'Compare prices and find the cheapest basket')}
          </p>
        </div>
      </div>

      <div className="container" style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 1rem 2rem' }}>
        {/* SAVINGS HIGHLIGHT */}
        <div style={{
          background: 'linear-gradient(135deg, rgba(0, 166, 81, 0.1), rgba(0, 166, 81, 0.05))',
          border: '2px solid #00A651',
          borderRadius: '1rem',
          padding: '1.5rem',
          marginBottom: '2rem',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '1.5rem',
        }}>
          <div>
            <div style={{ fontSize: '0.85rem', color: '#666', fontWeight: 600, marginBottom: '0.5rem' }}>
              {t('list.cheapestBasket', 'Cheapest Basket')}
            </div>
            <div style={{ fontSize: '2rem', fontWeight: 800, color: '#00A651', marginBottom: '0.25rem' }}>
              R{cheapestRetailer.total.toFixed(2)}
            </div>
            <div style={{ fontSize: '0.95rem', fontWeight: 600, color: '#1A1A1A' }}>
              {t('list.at', 'at')} <strong>{cheapestRetailer.name}</strong>
            </div>
          </div>

          <div>
            <div style={{ fontSize: '0.85rem', color: '#666', fontWeight: 600, marginBottom: '0.5rem' }}>
              {t('list.mostExpensive', 'Most Expensive')}
            </div>
            <div style={{ fontSize: '2rem', fontWeight: 800, color: '#E31B23', marginBottom: '0.25rem' }}>
              R{mostExpensiveRetailer.total.toFixed(2)}
            </div>
            <div style={{ fontSize: '0.95rem', fontWeight: 600, color: '#1A1A1A' }}>
              {t('list.at', 'at')} <strong>{mostExpensiveRetailer.name}</strong>
            </div>
          </div>

          <div style={{
            background: 'linear-gradient(135deg, #00A651, #008040)',
            color: 'white',
            borderRadius: '0.75rem',
            padding: '1rem',
            textAlign: 'center',
          }}>
            <div style={{ fontSize: '0.85rem', opacity: 0.9, marginBottom: '0.5rem' }}>
              {t('list.totalSavings', 'Total Savings')}
            </div>
            <div style={{ fontSize: '2rem', fontWeight: 800, marginBottom: '0.25rem' }}>
              R{totalSavings.toFixed(2)}
            </div>
            <div style={{ fontSize: '0.95rem', fontWeight: 600 }}>
              {savingsPercent}% {t('list.cheaper', 'cheaper')}
            </div>
          </div>
        </div>

        {/* ITEMS SECTION */}
        <div style={{ marginBottom: '2rem' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: '1rem', color: '#1A1A1A' }}>
            {t('list.items', 'Items')} ({items.length})
          </h2>

          {/* Add Item Form */}
          <div style={{
            background: '#F5F5F5',
            borderRadius: '1rem',
            padding: '1.5rem',
            marginBottom: '1.5rem',
            display: 'flex',
            gap: '0.75rem',
            flexWrap: 'wrap',
            alignItems: 'flex-end',
          }}>
            <div style={{ flex: 1, minWidth: '200px' }}>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.5rem', color: '#666' }}>
                {t('list.productName', 'Product Name')}
              </label>
              <input
                type="text"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addItem()}
                placeholder={t('list.searchProducts', 'Search products...')}
                style={{
                  width: '100%',
                  border: '1px solid #E0E0E0',
                  padding: '0.75rem',
                  borderRadius: '0.5rem',
                  fontFamily: 'Inter, sans-serif',
                }}
              />
            </div>

            <div style={{ minWidth: '100px' }}>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.5rem', color: '#666' }}>
                {t('list.quantity', 'Quantity')}
              </label>
              <input
                type="number"
                value={newItemQuantity}
                onChange={(e) => setNewItemQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                min="1"
                style={{
                  width: '100%',
                  border: '1px solid #E0E0E0',
                  padding: '0.75rem',
                  borderRadius: '0.5rem',
                  textAlign: 'center',
                }}
              />
            </div>

            <button
              onClick={addItem}
              style={{
                background: 'linear-gradient(135deg, #00A651, #008040)',
                color: 'white',
                border: 'none',
                padding: '0.75rem 1.5rem',
                borderRadius: '0.5rem',
                fontWeight: 700,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
              }}
            >
              <Plus style={{ width: '18px', height: '18px' }} />
              {t('list.add', 'Add')}
            </button>
          </div>

          {/* Items List */}
          <div style={{
            background: 'white',
            border: '2px solid #E0E0E0',
            borderRadius: '1rem',
            overflow: 'hidden',
          }}>
            {items.map((item, index) => (
              <div
                key={item.id}
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr auto auto auto',
                  gap: '1rem',
                  alignItems: 'center',
                  padding: '1rem',
                  borderBottom: index < items.length - 1 ? '1px solid #E0E0E0' : 'none',
                }}
              >
                <div>
                  <div style={{ fontWeight: 600, color: '#1A1A1A', marginBottom: '0.25rem' }}>
                    {item.name}
                  </div>
                  <div style={{ fontSize: '0.85rem', color: '#999' }}>
                    {item.category}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    style={{
                      background: '#F0F0F0',
                      border: '1px solid #E0E0E0',
                      padding: '0.25rem 0.5rem',
                      borderRadius: '0.25rem',
                      cursor: 'pointer',
                      fontWeight: 600,
                    }}
                  >
                    −
                  </button>
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                    style={{
                      width: '50px',
                      border: '1px solid #E0E0E0',
                      padding: '0.25rem',
                      borderRadius: '0.25rem',
                      textAlign: 'center',
                      fontWeight: 600,
                    }}
                  />
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    style={{
                      background: '#F0F0F0',
                      border: '1px solid #E0E0E0',
                      padding: '0.25rem 0.5rem',
                      borderRadius: '0.25rem',
                      cursor: 'pointer',
                      fontWeight: 600,
                    }}
                  >
                    +
                  </button>
                </div>

                <div style={{ textAlign: 'right', minWidth: '100px' }}>
                  <div style={{ fontWeight: 700, color: '#1A1A1A' }}>
                    R{(mockPrices[item.name]?.[cheapestRetailer.name] || 0) * item.quantity}
                  </div>
                  <div style={{ fontSize: '0.8rem', color: '#999' }}>
                    @ {cheapestRetailer.name}
                  </div>
                </div>

                <button
                  onClick={() => removeItem(item.id)}
                  style={{
                    background: '#FFE5E5',
                    border: 'none',
                    color: '#E31B23',
                    padding: '0.5rem',
                    borderRadius: '0.5rem',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Trash2 style={{ width: '18px', height: '18px' }} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* STORE COMPARISON */}
        <div style={{ marginBottom: '2rem' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: '1rem', color: '#1A1A1A' }}>
            {t('list.storeComparison', 'Store Comparison')}
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '1rem',
          }}>
            {retailers.map((retailer) => {
              const total = retailerTotals[retailer];
              const isCheapest = total === cheapestRetailer.total;
              const savings = mostExpensiveRetailer.total - total;

              return (
                <div
                  key={retailer}
                  style={{
                    background: isCheapest ? 'linear-gradient(135deg, rgba(0, 166, 81, 0.1), rgba(0, 166, 81, 0.05))' : 'white',
                    border: isCheapest ? '2px solid #00A651' : '2px solid #E0E0E0',
                    borderRadius: '1rem',
                    padding: '1.5rem',
                    textAlign: 'center',
                    position: 'relative',
                  }}
                >
                  {isCheapest && (
                    <div style={{
                      position: 'absolute',
                      top: '-12px',
                      left: '50%',
                      transform: 'translateX(-50%)',
                      background: '#00A651',
                      color: 'white',
                      padding: '0.25rem 0.75rem',
                      borderRadius: '0.5rem',
                      fontSize: '0.75rem',
                      fontWeight: 700,
                    }}>
                      {t('list.cheapest', 'CHEAPEST')}
                    </div>
                  )}

                  <div style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '1rem', color: '#1A1A1A' }}>
                    {retailer}
                  </div>

                  <div style={{ fontSize: '2rem', fontWeight: 800, marginBottom: '0.5rem', color: isCheapest ? '#00A651' : '#1A1A1A' }}>
                    R{total.toFixed(2)}
                  </div>

                  {savings > 0 && (
                    <div style={{
                      background: 'linear-gradient(135deg, rgba(0, 166, 81, 0.2), rgba(0, 166, 81, 0.1))',
                      color: '#00A651',
                      padding: '0.5rem',
                      borderRadius: '0.5rem',
                      fontSize: '0.85rem',
                      fontWeight: 600,
                      marginBottom: '1rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.5rem',
                    }}>
                      <TrendingDown style={{ width: '16px', height: '16px' }} />
                      {t('list.save', 'Save')} R{savings.toFixed(2)}
                    </div>
                  )}

                  <button
                    style={{
                      width: '100%',
                      background: isCheapest ? 'linear-gradient(135deg, #00A651, #008040)' : '#F0F0F0',
                      color: isCheapest ? 'white' : '#1A1A1A',
                      border: 'none',
                      padding: '0.75rem',
                      borderRadius: '0.5rem',
                      fontWeight: 700,
                      cursor: 'pointer',
                    }}
                  >
                    {t('list.shop', 'Shop Here')}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* ACTION BUTTONS */}
        <div style={{
          display: 'flex',
          gap: '1rem',
          flexWrap: 'wrap',
          marginBottom: '2rem',
        }}>
          <button
            style={{
              flex: 1,
              minWidth: '200px',
              background: 'linear-gradient(135deg, #00A651, #008040)',
              color: 'white',
              border: 'none',
              padding: '1rem',
              borderRadius: '0.75rem',
              fontWeight: 700,
              fontSize: '1rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem',
            }}
          >
            <Share2 style={{ width: '20px', height: '20px' }} />
            {t('list.share', 'Share List')}
          </button>

          <button
            style={{
              flex: 1,
              minWidth: '200px',
              background: '#F0F0F0',
              color: '#1A1A1A',
              border: '1px solid #E0E0E0',
              padding: '1rem',
              borderRadius: '0.75rem',
              fontWeight: 700,
              fontSize: '1rem',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem',
            }}
          >
            <Download style={{ width: '20px', height: '20px' }} />
            {t('list.export', 'Export as PDF')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShoppingList;
