import { useState } from 'react';
import { Plus, Trash2, Check, ListTodo } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { getLoginUrl } from '@/const';

/**
 * Shopping Lists - Users create and manage personalized shopping lists
 */
export default function ShoppingLists() {
  const { user, isAuthenticated } = useAuth();
  const [showNewListForm, setShowNewListForm] = useState(false);
  const [newListName, setNewListName] = useState('');
  const [selectedListId, setSelectedListId] = useState<number | null>(null);
  const [newItemName, setNewItemName] = useState('');
  const [newItemQuantity, setNewItemQuantity] = useState('1');

  // Fetch user's shopping lists
  const { data: lists, isLoading } = trpc.shoppingLists.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Create list mutation
  const createListMutation = trpc.shoppingLists.create.useMutation({
    onSuccess: () => {
      setNewListName('');
      setShowNewListForm(false);
      trpc.useUtils().shoppingLists.list.invalidate();
    },
  });

  // Add item mutation
  const addItemMutation = trpc.shoppingLists.addItem.useMutation({
    onSuccess: () => {
      setNewItemName('');
      setNewItemQuantity('1');
      trpc.useUtils().shoppingLists.list.invalidate();
    },
  });

  const handleCreateList = async () => {
    if (!newListName.trim()) {
      alert('Please enter a list name');
      return;
    }

    await createListMutation.mutateAsync({
      name: newListName,
      description: undefined,
    });
  };

  const handleAddItem = async () => {
    if (!selectedListId || !newItemName.trim()) {
      alert('Please select a list and enter an item name');
      return;
    }

    await addItemMutation.mutateAsync({
      listId: selectedListId,
      productName: newItemName,
      category: undefined,
      quantity: parseInt(newItemQuantity) || 1,
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <header className="sticky top-0 z-50 bg-white shadow-sm border-b-2 border-primary/20">
          <div className="container py-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <ListTodo className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-primary">Shopping Lists</h1>
                <p className="text-xs text-muted-foreground">Organize your grocery shopping</p>
              </div>
            </div>
          </div>
        </header>

        <div className="container py-12">
          <Card className="p-12 text-center border-2 border-primary/20">
            <p className="text-lg text-foreground mb-6">Sign in to create and manage your shopping lists</p>
            <Button
              onClick={() => (window.location.href = getLoginUrl())}
              className="bg-primary hover:bg-primary/90"
            >
              Sign In
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b-2 border-primary/20">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <ListTodo className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-primary">Shopping Lists</h1>
                <p className="text-xs text-muted-foreground">Organize your grocery shopping</p>
              </div>
            </div>
            <Button
              onClick={() => setShowNewListForm(true)}
              className="bg-primary hover:bg-primary/90 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              New List
            </Button>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Lists Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 border-2 border-primary/20">
              <h3 className="font-bold text-foreground mb-4">Your Lists</h3>

              {showNewListForm && (
                <div className="mb-4 p-4 bg-primary/5 rounded-lg border-2 border-primary/20">
                  <Input
                    placeholder="List name (e.g., Weekly Shopping)"
                    value={newListName}
                    onChange={(e) => setNewListName(e.target.value)}
                    className="mb-3 border-2 border-primary/30"
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={handleCreateList}
                      disabled={createListMutation.isPending}
                      className="flex-1 bg-primary hover:bg-primary/90 text-sm"
                    >
                      {createListMutation.isPending ? 'Creating...' : 'Create'}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setShowNewListForm(false)}
                      className="flex-1 text-sm"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                {isLoading ? (
                  <p className="text-sm text-muted-foreground">Loading lists...</p>
                ) : lists && lists.length > 0 ? (
                  lists.map((list) => (
                    <button
                      key={list.id}
                      onClick={() => setSelectedListId(list.id)}
                      className={`w-full text-left p-3 rounded-lg transition-all border-2 ${
                        selectedListId === list.id
                          ? 'bg-primary/10 border-primary text-primary font-semibold'
                          : 'bg-muted/50 border-border hover:border-primary'
                      }`}
                    >
                      {list.name}
                    </button>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">No lists yet. Create one!</p>
                )}
              </div>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {selectedListId && lists ? (
              (() => {
                const list = lists.find((l) => l.id === selectedListId);
                return list ? (
                  <Card className="p-6 border-2 border-primary/20">
                    <h2 className="text-2xl font-bold text-foreground mb-2">{list.name}</h2>
                    {list.description && (
                      <p className="text-foreground/70 mb-6">{list.description}</p>
                    )}

                    {/* Add Item Form */}
                    <div className="bg-primary/5 p-4 rounded-lg border-2 border-primary/20 mb-6">
                      <h3 className="font-semibold text-foreground mb-4">Add Item</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <Input
                          placeholder="Product name"
                          value={newItemName}
                          onChange={(e) => setNewItemName(e.target.value)}
                          className="border-2 border-primary/30"
                        />
                        <Input
                          placeholder="Quantity"
                          type="number"
                          value={newItemQuantity}
                          onChange={(e) => setNewItemQuantity(e.target.value)}
                          className="border-2 border-primary/30"
                        />
                        <Button
                          onClick={handleAddItem}
                          disabled={addItemMutation.isPending}
                          className="bg-primary hover:bg-primary/90"
                        >
                          {addItemMutation.isPending ? 'Adding...' : 'Add'}
                        </Button>
                      </div>
                    </div>

                    {/* Items List */}
                    <div>
                      <h3 className="font-semibold text-foreground mb-4">Items</h3>
                      <div className="space-y-2">
                        {/* Mock items - in production, these would come from the database */}
                        <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg border border-border hover:border-primary transition">
                          <button className="flex-shrink-0">
                            <Check className="w-5 h-5 text-muted-foreground hover:text-primary transition" />
                          </button>
                          <div className="flex-1">
                            <p className="font-medium text-foreground">Milk (1L)</p>
                            <p className="text-xs text-muted-foreground">Qty: 2</p>
                          </div>
                          <button className="text-muted-foreground hover:text-accent transition">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg border border-border hover:border-primary transition">
                          <button className="flex-shrink-0">
                            <Check className="w-5 h-5 text-muted-foreground hover:text-primary transition" />
                          </button>
                          <div className="flex-1">
                            <p className="font-medium text-foreground">Bread (White)</p>
                            <p className="text-xs text-muted-foreground">Qty: 1</p>
                          </div>
                          <button className="text-muted-foreground hover:text-accent transition">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg border border-border hover:border-primary transition">
                          <button className="flex-shrink-0">
                            <Check className="w-5 h-5 text-muted-foreground hover:text-primary transition" />
                          </button>
                          <div className="flex-1">
                            <p className="font-medium text-foreground">Chicken Breast (1kg)</p>
                            <p className="text-xs text-muted-foreground">Qty: 1</p>
                          </div>
                          <button className="text-muted-foreground hover:text-accent transition">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Estimated Total */}
                    <div className="mt-8 pt-6 border-t-2 border-border">
                      <div className="flex justify-between items-center">
                        <p className="font-semibold text-foreground">Estimated Total:</p>
                        <p className="text-2xl font-bold text-secondary">R28.47</p>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">Based on average prices</p>
                    </div>
                  </Card>
                ) : null;
              })()
            ) : (
              <Card className="p-12 text-center border-2 border-primary/20">
                <p className="text-foreground mb-4">Select a list or create a new one to get started</p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
