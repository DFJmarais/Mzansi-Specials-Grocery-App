import { useState } from 'react';
import { Heart, MessageCircle, Share2, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

// Mock data for community posts
const MOCK_POSTS = [
  {
    id: 1,
    author: 'Thandi M.',
    avatar: '👩',
    timestamp: '2 hours ago',
    content: 'Found amazing deals at Spar today! Full cream milk R18.99 (was R24.99) and chicken breast R55.99. Saved R30+ on my shopping!',
    image: null,
    likes: 24,
    comments: 5,
    shares: 3,
    liked: false,
    tags: ['Spar', 'Dairy', 'Meat', 'Specials'],
  },
  {
    id: 2,
    author: 'Mandla K.',
    avatar: '👨',
    timestamp: '4 hours ago',
    content: 'Weekly meal plan for my family of 4: Pap & Vleis, Bobotie, Braai, Durban Curry. Total cost: R450 at OK Foods. Best prices in town!',
    image: null,
    likes: 18,
    comments: 3,
    shares: 2,
    liked: false,
    tags: ['Meal Plan', 'Budget', 'Family', 'OK Foods'],
  },
  {
    id: 3,
    author: 'Naledi P.',
    avatar: '👩‍🦱',
    timestamp: '6 hours ago',
    content: 'Pick n Pay has 20% off all fresh produce today! Tomatoes R9.99/kg, apples R19.99/kg. Perfect for meal prep!',
    image: null,
    likes: 42,
    comments: 8,
    shares: 12,
    liked: false,
    tags: ['Pick n Pay', 'Produce', 'Fresh', 'Limited Time'],
  },
  {
    id: 4,
    author: 'Sipho L.',
    avatar: '👨‍🦱',
    timestamp: '8 hours ago',
    content: 'Just saved R150 using Mzansi Specials price comparison! Bought my weekly groceries at 3 different stores for the best prices.',
    image: null,
    likes: 31,
    comments: 6,
    shares: 5,
    liked: false,
    tags: ['Price Comparison', 'Savings', 'Smart Shopping'],
  },
];

export default function Community() {
  const [posts, setPosts] = useState(MOCK_POSTS);
  const [newPost, setNewPost] = useState('');
  const [selectedTag, setSelectedTag] = useState('All');

  const handlePostSubmit = () => {
    if (newPost.trim()) {
      const post = {
        id: posts.length + 1,
        author: 'You',
        avatar: '😊',
        timestamp: 'just now',
        content: newPost,
        image: null,
        likes: 0,
        comments: 0,
        shares: 0,
        liked: false,
        tags: [],
      };
      setPosts([post, ...posts]);
      setNewPost('');
    }
  };

  const handleLike = (postId: number) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 }
        : post
    ));
  };

  const allTags = ['All', 'Specials', 'Meal Plan', 'Budget', 'Spar', 'Pick n Pay', 'Checkers', 'OK Foods', 'ShopRite'];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white shadow-sm border-b-2 border-primary/20 py-4">
        <div className="container">
          <h1 className="text-3xl font-bold text-primary mb-2">🍽️ Community Specials</h1>
          <p className="text-muted-foreground">Share deals, meal plans, and shopping tips with your community</p>
        </div>
      </div>

      <div className="container py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Feed */}
          <div className="lg:col-span-2 space-y-6">
            {/* Create Post */}
            <Card className="p-6 border-2 border-primary/20">
              <div className="flex gap-4 mb-4">
                <div className="text-3xl">😊</div>
                <div className="flex-1">
                  <textarea
                    placeholder="Share your best grocery deals, meal plans, or shopping tips..."
                    value={newPost}
                    onChange={(e) => setNewPost(e.target.value)}
                    className="w-full p-3 border-2 border-primary/30 rounded-lg focus:border-primary focus:outline-none resize-none"
                    rows={3}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" className="border-2 border-primary/30">
                  📸 Add Image
                </Button>
                <Button 
                  onClick={handlePostSubmit}
                  disabled={!newPost.trim()}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                >
                  📤 Share Deal
                </Button>
              </div>
            </Card>

            {/* Posts Feed */}
            <div className="space-y-4">
              {posts.map((post) => (
                <Card key={post.id} className="p-6 border-2 border-primary/20 hover:shadow-lg transition-all">
                  {/* Post Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="text-4xl">{post.avatar}</div>
                      <div>
                        <p className="font-bold text-foreground">{post.author}</p>
                        <p className="text-sm text-muted-foreground">{post.timestamp}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">⋮</Button>
                  </div>

                  {/* Post Content */}
                  <p className="text-foreground mb-4 leading-relaxed">{post.content}</p>

                  {/* Tags */}
                  {post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {post.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="bg-primary/10 text-primary">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Engagement Stats */}
                  <div className="flex gap-4 text-sm text-muted-foreground mb-4 pb-4 border-b border-border">
                    <span>❤️ {post.likes} likes</span>
                    <span>💬 {post.comments} comments</span>
                    <span>📤 {post.shares} shares</span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleLike(post.id)}
                      className={`flex-1 ${post.liked ? 'text-red-500' : 'text-muted-foreground'}`}
                    >
                      <Heart className={`w-5 h-5 mr-2 ${post.liked ? 'fill-red-500' : ''}`} />
                      Like
                    </Button>
                    <Button variant="ghost" size="sm" className="flex-1 text-muted-foreground">
                      <MessageCircle className="w-5 h-5 mr-2" />
                      Comment
                    </Button>
                    <Button variant="ghost" size="sm" className="flex-1 text-muted-foreground">
                      <Share2 className="w-5 h-5 mr-2" />
                      Share
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Trending Tags */}
            <Card className="p-6 border-2 border-primary/20">
              <h3 className="font-bold text-lg text-foreground mb-4">🔥 Trending</h3>
              <div className="space-y-2">
                {allTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(tag)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-all ${
                      selectedTag === tag
                        ? 'bg-primary text-primary-foreground font-semibold'
                        : 'bg-muted text-foreground hover:bg-primary/10'
                    }`}
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            </Card>

            {/* Top Contributors */}
            <Card className="p-6 border-2 border-primary/20">
              <h3 className="font-bold text-lg text-foreground mb-4">👥 Top Contributors</h3>
              <div className="space-y-3">
                {[
                  { name: 'Thandi M.', avatar: '👩', posts: 24 },
                  { name: 'Mandla K.', avatar: '👨', posts: 18 },
                  { name: 'Naledi P.', avatar: '👩‍🦱', posts: 42 },
                ].map((user) => (
                  <div key={user.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{user.avatar}</span>
                      <div>
                        <p className="font-semibold text-sm text-foreground">{user.name}</p>
                        <p className="text-xs text-muted-foreground">{user.posts} posts</p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" className="border-2 border-primary/30">
                      Follow
                    </Button>
                  </div>
                ))}
              </div>
            </Card>

            {/* Community Stats */}
            <Card className="p-6 border-2 border-primary/20 bg-gradient-to-br from-primary/10 to-accent/10">
              <h3 className="font-bold text-lg text-foreground mb-4">📊 Community Stats</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground">Active Members</p>
                  <p className="text-2xl font-bold text-primary">12,450</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Deals Shared Today</p>
                  <p className="text-2xl font-bold text-primary">1,230</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Savings</p>
                  <p className="text-2xl font-bold text-primary">R2.3M+</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
