import { useState } from 'react';
import { MapPin, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StoreLocator } from '@/components/StoreLocator';
import { STORE_LOCATIONS, getStoresByProvince } from '@/data/store-locations';

const PROVINCES = [
  'Gauteng',
  'Western Cape',
  'KwaZulu-Natal',
  'Free State',
  'Eastern Cape',
];

export default function StoreLocatorPage() {
  const [selectedProvince, setSelectedProvince] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Get stores based on filters
  const filteredStores = selectedProvince
    ? getStoresByProvince(selectedProvince).filter(
        (store) =>
          store.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          store.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
          store.store.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : STORE_LOCATIONS.filter(
        (store) =>
          store.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          store.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
          store.store.toLowerCase().includes(searchQuery.toLowerCase())
      );

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <MapPin className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold text-foreground">Store Locator</h1>
          </div>
          <p className="text-muted-foreground">
            Find the nearest Mzansi Specials partner stores across South Africa
          </p>
        </div>

        {/* Geolocation Section */}
        <Card className="p-6 mb-8 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
          <StoreLocator productName="your products" />
        </Card>

        {/* Search and Filter Section */}
        <div className="space-y-4 mb-8">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search by store name, city, or retailer..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 border-2 border-primary/30 focus:border-primary"
            />
          </div>

          {/* Province Filter */}
          <div>
            <p className="text-sm font-semibold text-foreground mb-3">Filter by Province</p>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedProvince === null ? 'default' : 'outline'}
                onClick={() => setSelectedProvince(null)}
                className={selectedProvince === null ? 'bg-primary' : ''}
              >
                All Provinces
              </Button>
              {PROVINCES.map((province) => (
                <Button
                  key={province}
                  variant={selectedProvince === province ? 'default' : 'outline'}
                  onClick={() => setSelectedProvince(province)}
                  className={selectedProvince === province ? 'bg-primary' : ''}
                >
                  {province}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div>
          <p className="text-sm font-semibold text-muted-foreground mb-4">
            {filteredStores.length} store{filteredStores.length !== 1 ? 's' : ''} found
          </p>

          {filteredStores.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredStores.map((store) => (
                <Card
                  key={store.id}
                  className="p-4 hover:shadow-lg transition-all border-2 border-primary/20 hover:border-primary/50"
                >
                  <div className="space-y-3">
                    {/* Store Header */}
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-foreground">{store.name}</h3>
                        <p className="text-xs text-muted-foreground">{store.city}</p>
                      </div>
                      <Badge className="bg-primary/20 text-primary border-0 text-xs">
                        {store.store}
                      </Badge>
                    </div>

                    {/* Province */}
                    <p className="text-xs text-muted-foreground font-medium">
                      📍 {store.province}
                    </p>

                    {/* Address */}
                    <p className="text-xs text-muted-foreground">{store.address}</p>

                    {/* Contact Info */}
                    <div className="space-y-1">
                      {store.phone && (
                        <p className="text-xs text-muted-foreground">
                          📞 <a href={`tel:${store.phone}`} className="hover:text-primary">
                            {store.phone}
                          </a>
                        </p>
                      )}
                      {store.hours && (
                        <p className="text-xs text-muted-foreground">
                          🕐 {store.hours}
                        </p>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2 pt-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 text-xs"
                        onClick={() => {
                          window.open(
                            `https://www.google.com/maps/search/${encodeURIComponent(
                              store.name
                            )}/@${store.latitude},${store.longitude},15z`,
                            '_blank'
                          );
                        }}
                      >
                        View Map
                      </Button>
                      {store.phone && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 text-xs"
                          onClick={() => window.open(`tel:${store.phone}`)}
                        >
                          Call
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center bg-muted/50">
              <MapPin className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
              <p className="text-muted-foreground">
                No stores found matching your search. Try adjusting your filters.
              </p>
            </Card>
          )}
        </div>

        {/* Info Section */}
        <Card className="mt-8 p-6 bg-primary/5 border-primary/20">
          <h3 className="font-semibold text-foreground mb-2">💡 Store Locator Tips</h3>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li>• Enable location access to see stores sorted by distance</li>
            <li>• Click "View Map" to get directions using Google Maps</li>
            <li>• Call stores to confirm product availability before visiting</li>
            <li>• Store hours may vary by location</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
