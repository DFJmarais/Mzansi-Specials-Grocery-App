import { useState } from 'react';
import { Bell, X, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { COMPLETE_PRODUCTS } from '@/data/products-complete';

interface PriceAlert {
  id: number;
  productName: string;
  targetPrice: number;
  currentPrice?: number;
  store?: string;
  isActive: boolean;
  notificationSent: boolean;
}

export default function PriceAlerts() {
  const [alerts, setAlerts] = useState<PriceAlert[]>([
    {
      id: 1,
      productName: 'Full Cream Milk 1L',
      targetPrice: 15,
      currentPrice: 17.03,
      store: 'Spar',
      isActive: true,
      notificationSent: false,
    },
    {
      id: 2,
      productName: 'Cheddar Cheese 200g',
      targetPrice: 25,
      currentPrice: 26.19,
      store: 'Pick n Pay',
      isActive: true,
      notificationSent: false,
    },
  ]);

  const [newAlert, setNewAlert] = useState({
    productName: '',
    targetPrice: '',
    store: '',
  });

  const [searchResults, setSearchResults] = useState<typeof COMPLETE_PRODUCTS>([]);
  const [showSearch, setShowSearch] = useState(false);

  const handleSearch = (query: string) => {
    if (query.length > 0) {
      const results = COMPLETE_PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 5);
      setSearchResults(results);
      setShowSearch(true);
    } else {
      setShowSearch(false);
    }
  };

  const handleSelectProduct = (product: typeof COMPLETE_PRODUCTS[0]) => {
    setNewAlert({
      ...newAlert,
      productName: product.name,
    });
    setShowSearch(false);
  };

  const handleAddAlert = () => {
    if (newAlert.productName && newAlert.targetPrice) {
      const alert: PriceAlert = {
        id: Math.max(...alerts.map(a => a.id), 0) + 1,
        productName: newAlert.productName,
        targetPrice: parseFloat(newAlert.targetPrice),
        store: newAlert.store || 'All Stores',
        isActive: true,
        notificationSent: false,
      };
      setAlerts([...alerts, alert]);
      setNewAlert({ productName: '', targetPrice: '', store: '' });
    }
  };

  const handleRemoveAlert = (id: number) => {
    setAlerts(alerts.filter(a => a.id !== id));
  };

  const handleToggleAlert = (id: number) => {
    setAlerts(alerts.map(a =>
      a.id === id ? { ...a, isActive: !a.isActive } : a
    ));
  };

  const activeAlerts = alerts.filter(a => a.isActive);
  const inactiveAlerts = alerts.filter(a => !a.isActive);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
          <Bell className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-primary">Price Alerts</h2>
          <p className="text-sm text-muted-foreground">Get notified when prices drop below your targets</p>
        </div>
      </div>

      {/* Add New Alert */}
      <Card className="p-6 border-2 border-primary/20">
        <h3 className="font-bold text-lg mb-4 text-foreground">Set a New Price Alert</h3>
        <div className="space-y-4">
          {/* Product Search */}
          <div className="relative">
            <label className="text-sm font-semibold text-foreground mb-2 block">Product</label>
            <Input
              placeholder="Search for a product..."
              value={newAlert.productName}
              onChange={(e) => {
                setNewAlert({ ...newAlert, productName: e.target.value });
                handleSearch(e.target.value);
              }}
              className="border-2 border-primary/30 focus:border-primary"
            />
            {showSearch && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-white border-2 border-primary/20 rounded-lg shadow-lg z-10">
                {searchResults.map(product => (
                  <button
                    key={product.id}
                    onClick={() => handleSelectProduct(product)}
                    className="w-full text-left px-4 py-2 hover:bg-primary/10 border-b last:border-b-0"
                  >
                    <div className="font-medium text-foreground">{product.name}</div>
                    <div className="text-xs text-muted-foreground">{product.category}</div>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Target Price */}
            <div>
              <label className="text-sm font-semibold text-foreground mb-2 block">Target Price (R)</label>
              <Input
                type="number"
                placeholder="e.g., 15.00"
                value={newAlert.targetPrice}
                onChange={(e) => setNewAlert({ ...newAlert, targetPrice: e.target.value })}
                className="border-2 border-primary/30 focus:border-primary"
                step="0.01"
              />
            </div>

            {/* Store Selection */}
            <div>
              <label className="text-sm font-semibold text-foreground mb-2 block">Store (Optional)</label>
              <select
                value={newAlert.store}
                onChange={(e) => setNewAlert({ ...newAlert, store: e.target.value })}
                className="w-full px-3 py-2 border-2 border-primary/30 rounded-lg focus:border-primary focus:outline-none"
              >
                <option value="">All Stores</option>
                <option value="Spar">Spar</option>
                <option value="Pick n Pay">Pick n Pay</option>
                <option value="Checkers">Checkers</option>
                <option value="OK Foods">OK Foods</option>
                <option value="ShopRite">ShopRite</option>
              </select>
            </div>
          </div>

          <Button
            onClick={handleAddAlert}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
          >
            <Bell className="w-4 h-4 mr-2" />
            Create Alert
          </Button>
        </div>
      </Card>

      {/* Active Alerts */}
      {activeAlerts.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-bold text-lg text-foreground">Active Alerts ({activeAlerts.length})</h3>
          <div className="grid gap-3">
            {activeAlerts.map(alert => {
              const isPriceHit = alert.currentPrice && alert.currentPrice <= alert.targetPrice;
              return (
                <Card
                  key={alert.id}
                  className={`p-4 border-2 ${isPriceHit ? 'border-accent bg-accent/5' : 'border-primary/20'}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-bold text-foreground">{alert.productName}</h4>
                        {isPriceHit && (
                          <Badge className="bg-accent text-white animate-pulse">
                            <TrendingDown className="w-3 h-3 mr-1" />
                            Price Hit!
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">
                        {alert.store && <span>{alert.store} • </span>}
                        Target: <span className="font-semibold text-foreground">R{alert.targetPrice.toFixed(2)}</span>
                        {alert.currentPrice && (
                          <>
                            {' • '}Current: <span className="font-semibold text-foreground">R{alert.currentPrice.toFixed(2)}</span>
                          </>
                        )}
                      </div>
                      {alert.notificationSent && (
                        <Badge variant="secondary" className="text-xs">✓ Notified</Badge>
                      )}
                    </div>
                    <button
                      onClick={() => handleRemoveAlert(alert.id)}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Inactive Alerts */}
      {inactiveAlerts.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-bold text-lg text-muted-foreground">Paused Alerts ({inactiveAlerts.length})</h3>
          <div className="grid gap-3">
            {inactiveAlerts.map(alert => (
              <Card key={alert.id} className="p-4 border-2 border-muted/30 opacity-60">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-bold text-foreground">{alert.productName}</h4>
                    <div className="text-sm text-muted-foreground mt-1">
                      {alert.store && <span>{alert.store} • </span>}
                      Target: R{alert.targetPrice.toFixed(2)}
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggleAlert(alert.id)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {alerts.length === 0 && (
        <div className="text-center py-12">
          <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
          <p className="text-muted-foreground">No price alerts yet. Create one to get started!</p>
        </div>
      )}

      {/* Info Box */}
      <Card className="p-4 bg-secondary/10 border-2 border-secondary/20">
        <p className="text-sm text-foreground">
          <strong>💡 Tip:</strong> Set alerts for products you buy regularly. You'll be notified when prices drop below your target, helping you save money on your grocery shopping!
        </p>
      </Card>
    </div>
  );
}
