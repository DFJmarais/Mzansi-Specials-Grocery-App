import React, { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';
import { COMPLETE_PRODUCTS } from '@/data/products-complete';
import { ArrowLeft, Plus, Trash2, Save, Share2, Download, X, Search } from 'lucide-react';
import { useLocation } from 'wouter';

/**
 * Smart Weekly Planner - Notepad-Style Shopping List
 * Users can add any products (toilet rolls, sanitary pads, milk, etc.)
 * System saves and tracks prices across the week
 */

interface ShoppingItem {
  id: string;
  productName: string;
  quantity: number;
  unit: string;
  day: string;
  notes?: string;
  bestPrice?: number;
  bestStore?: string;
  productId?: number;
}

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const COMMON_UNITS = ['pcs', 'kg', 'L', 'ml', 'box', 'pack', 'dozen', 'roll', 'bottle', 'tin'];

export default function SmartWeeklyPlanner() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();

  // State management
  const [shoppingList, setShoppingList] = useState<ShoppingItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDay, setSelectedDay] = useState('Monday');
  const [newProductName, setNewProductName] = useState('');
  const [newQuantity, setNewQuantity] = useState(1);
  const [newUnit, setNewUnit] = useState('pcs');
  const [showProductSuggestions, setShowProductSuggestions] = useState(false);
  const [planName, setPlanName] = useState('Weekly Shopping List');
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('smartWeeklyPlanner');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setShoppingList(parsed.items || []);
        setPlanName(parsed.name || 'Weekly Shopping List');
        setLastSaved(new Date(parsed.lastSaved));
      } catch (e) {
        console.error('Failed to load shopping list:', e);
      }
    }
  }, []);

  // Auto-save to localStorage
  useEffect(() => {
    if (shoppingList.length > 0 || planName !== 'Weekly Shopping List') {
      localStorage.setItem(
        'smartWeeklyPlanner',
        JSON.stringify({
          items: shoppingList,
          name: planName,
          lastSaved: new Date().toISOString(),
        })
      );
      setLastSaved(new Date());
    }
  }, [shoppingList, planName]);

  // Get product suggestions based on search
  const productSuggestions = useMemo(() => {
    if (!newProductName.trim()) return [];
    const query = newProductName.toLowerCase();
    return COMPLETE_PRODUCTS.filter((p) =>
      p.name.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query)
    ).slice(0, 8);
  }, [newProductName]);

  // Add product to list
  const handleAddProduct = (productName?: string, productId?: number) => {
    const name = productName || newProductName.trim();
    if (!name) return;

    const newItem: ShoppingItem = {
      id: `${Date.now()}-${Math.random()}`,
      productName: name,
      quantity: newQuantity,
      unit: newUnit,
      day: selectedDay,
      productId,
    };

    setShoppingList([...shoppingList, newItem]);
    setNewProductName('');
    setNewQuantity(1);
    setShowProductSuggestions(false);
  };

  // Remove product from list
  const handleRemoveProduct = (id: string) => {
    setShoppingList(shoppingList.filter((item) => item.id !== id));
  };

  // Update product quantity
  const handleUpdateQuantity = (id: string, quantity: number) => {
    setShoppingList(
      shoppingList.map((item) =>
        item.id === id ? { ...item, quantity: Math.max(1, quantity) } : item
      )
    );
  };

  // Get items for selected day
  const dayItems = shoppingList.filter((item) => item.day === selectedDay);

  // Calculate totals
  const totalItems = shoppingList.length;
  const totalDaysCovered = new Set(shoppingList.map((item) => item.day)).size;

  // Export as text
  const handleExport = () => {
    let text = `${planName}\n`;
    text += `Generated: ${new Date().toLocaleDateString()}\n\n`;

    DAYS_OF_WEEK.forEach((day) => {
      const dayItems = shoppingList.filter((item) => item.day === day);
      if (dayItems.length > 0) {
        text += `${day}:\n`;
        dayItems.forEach((item) => {
          text += `  - ${item.quantity}${item.unit} ${item.productName}${item.notes ? ` (${item.notes})` : ''}\n`;
        });
        text += '\n';
      }
    });

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${planName.replace(/\s+/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Share via WhatsApp
  const handleShareWhatsApp = () => {
    let text = `📋 ${planName}\n\n`;
    DAYS_OF_WEEK.forEach((day) => {
      const dayItems = shoppingList.filter((item) => item.day === day);
      if (dayItems.length > 0) {
        text += `*${day}*\n`;
        dayItems.forEach((item) => {
          text += `• ${item.quantity}${item.unit} ${item.productName}\n`;
        });
        text += '\n';
      }
    });

    const encoded = encodeURIComponent(text);
    window.open(`https://wa.me/?text=${encoded}`, '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <h2 className="text-2xl font-bold text-foreground mb-4">Please Log In</h2>
          <p className="text-muted-foreground mb-6">You need to be logged in to use the smart planner.</p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="w-full bg-primary hover:bg-primary/90"
          >
            Log In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-gradient-to-r from-sidebar via-sidebar to-sidebar shadow-lg border-b-4 border-primary">
        <div className="container px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4 mb-4">
            <button
              onClick={() => navigate('/')}
              className="p-2 hover:bg-primary/20 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-primary" />
            </button>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-primary drop-shadow-lg">📝 Smart Weekly Planner</h1>
              <p className="text-sm text-primary-foreground/80">Add any products and save your shopping list</p>
            </div>
          </div>

          {/* Plan Name */}
          <div className="flex gap-2 items-end">
            <div className="flex-1">
              <label className="text-xs font-semibold text-primary-foreground/80">Plan Name</label>
              <Input
                value={planName}
                onChange={(e) => setPlanName(e.target.value)}
                className="mt-1 bg-white/10 border-primary/30"
                placeholder="Enter plan name"
              />
            </div>
            <div className="text-xs text-primary-foreground/60">
              {lastSaved && `Saved: ${lastSaved.toLocaleTimeString()}`}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Add Product Form */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-24 border-2 border-primary/20">
              <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                <Plus className="w-5 h-5 text-primary" />
                Add Product
              </h2>

              {/* Day Selector */}
              <div className="mb-4">
                <label className="text-sm font-semibold text-foreground mb-2 block">Day</label>
                <select
                  value={selectedDay}
                  onChange={(e) => setSelectedDay(e.target.value)}
                  className="w-full p-2 border-2 border-border rounded-lg bg-background text-foreground"
                >
                  {DAYS_OF_WEEK.map((day) => (
                    <option key={day} value={day}>
                      {day}
                    </option>
                  ))}
                </select>
              </div>

              {/* Product Search */}
              <div className="mb-4 relative">
                <label className="text-sm font-semibold text-foreground mb-2 block">Product Name</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={newProductName}
                    onChange={(e) => {
                      setNewProductName(e.target.value);
                      setShowProductSuggestions(true);
                    }}
                    onFocus={() => setShowProductSuggestions(true)}
                    placeholder="Milk, toilet rolls, bread..."
                    className="pl-10"
                  />
                </div>

                {/* Product Suggestions */}
                {showProductSuggestions && productSuggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border-2 border-border rounded-lg shadow-lg z-10 max-h-48 overflow-y-auto">
                    {productSuggestions.map((product) => (
                      <button
                        key={product.id}
                        onClick={() => handleAddProduct(product.name, product.id)}
                        className="w-full text-left p-3 hover:bg-primary/10 border-b border-border/50 last:border-b-0 transition-colors"
                      >
                        <p className="font-medium text-foreground">{product.name}</p>
                        <p className="text-xs text-muted-foreground">{product.category}</p>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Quantity */}
              <div className="mb-4">
                <label className="text-sm font-semibold text-foreground mb-2 block">Quantity</label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    min="1"
                    value={newQuantity}
                    onChange={(e) => setNewQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="flex-1"
                  />
                  <select
                    value={newUnit}
                    onChange={(e) => setNewUnit(e.target.value)}
                    className="p-2 border-2 border-border rounded-lg bg-background text-foreground"
                  >
                    {COMMON_UNITS.map((unit) => (
                      <option key={unit} value={unit}>
                        {unit}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Add Button */}
              <Button
                onClick={() => handleAddProduct()}
                disabled={!newProductName.trim()}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold mb-4"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add to {selectedDay}
              </Button>

              {/* Action Buttons */}
              <div className="space-y-2">
                <Button
                  onClick={handleExport}
                  variant="outline"
                  className="w-full"
                  disabled={shoppingList.length === 0}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
                <Button
                  onClick={handleShareWhatsApp}
                  variant="outline"
                  className="w-full"
                  disabled={shoppingList.length === 0}
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
              </div>
            </Card>
          </div>

          {/* Right: Shopping List */}
          <div className="lg:col-span-2">
            {/* Summary */}
            <Card className="p-6 mb-6 bg-gradient-to-r from-primary/10 to-accent/10 border-2 border-primary/20">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Total Items</p>
                  <p className="text-2xl font-bold text-primary">{totalItems}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Days Covered</p>
                  <p className="text-2xl font-bold text-primary">{totalDaysCovered}/7</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className="text-lg font-bold text-secondary">
                    {lastSaved ? '✅ Saved' : '⏳ Saving...'}
                  </p>
                </div>
              </div>
            </Card>

            {/* Day Tabs */}
            <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
              {DAYS_OF_WEEK.map((day) => {
                const count = shoppingList.filter((item) => item.day === day).length;
                return (
                  <button
                    key={day}
                    onClick={() => setSelectedDay(day)}
                    className={`px-4 py-2 rounded-lg font-semibold whitespace-nowrap transition-all ${
                      selectedDay === day
                        ? 'bg-primary text-primary-foreground shadow-md'
                        : 'bg-border text-foreground hover:bg-border/80'
                    }`}
                  >
                    {day.slice(0, 3)} {count > 0 && `(${count})`}
                  </button>
                );
              })}
            </div>

            {/* Products for Selected Day */}
            <div className="space-y-3">
              {dayItems.length === 0 ? (
                <Card className="p-8 text-center border-2 border-dashed border-border">
                  <p className="text-muted-foreground">No items for {selectedDay}</p>
                  <p className="text-sm text-muted-foreground mt-2">Add products from the left panel</p>
                </Card>
              ) : (
                dayItems.map((item) => (
                  <Card key={item.id} className="p-4 border-2 border-border hover:border-primary/50 transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <p className="font-semibold text-foreground">{item.productName}</p>
                        <p className="text-sm text-muted-foreground">
                          {item.quantity} {item.unit}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) =>
                            handleUpdateQuantity(item.id, parseInt(e.target.value) || 1)
                          }
                          className="w-16 text-center"
                        />
                        <button
                          onClick={() => handleRemoveProduct(item.id)}
                          className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
