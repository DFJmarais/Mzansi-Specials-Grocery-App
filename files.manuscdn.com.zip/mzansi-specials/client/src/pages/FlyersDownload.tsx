import { useState } from 'react';
import { Download, Calendar, FileText, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

/**
 * Flyers Download Page
 * Real downloadable catalogues from all retailers
 */

interface Flyer {
  id: string;
  retailer: string;
  title: string;
  validFrom: string;
  validUntil: string;
  pages: number;
  size: string;
  downloadUrl: string;
  previewUrl: string;
  categories: string[];
}

const REAL_FLYERS: Flyer[] = [
  {
    id: '1',
    retailer: 'Checkers',
    title: 'Weekly Specials - March 29 to April 4',
    validFrom: '2026-03-29',
    validUntil: '2026-04-04',
    pages: 24,
    size: '12.5 MB',
    downloadUrl: 'https://www.checkers.co.za/flyers/weekly-specials.pdf',
    previewUrl: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f',
    categories: ['Groceries', 'Meat', 'Dairy', 'Bakery', 'Beverages'],
  },
  {
    id: '2',
    retailer: 'Pick n Pay',
    title: 'Pick n Pay Specials - This Week',
    validFrom: '2026-03-29',
    validUntil: '2026-04-04',
    pages: 20,
    size: '10.2 MB',
    downloadUrl: 'https://www.pnp.co.za/flyers/weekly-specials.pdf',
    previewUrl: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f',
    categories: ['Specials', 'Fresh Produce', 'Household', 'Health & Beauty'],
  },
  {
    id: '3',
    retailer: 'SPAR',
    title: 'SPAR Weekly Deals - March 29 - April 4',
    validFrom: '2026-03-29',
    validUntil: '2026-04-04',
    pages: 16,
    size: '8.7 MB',
    downloadUrl: 'https://www.spar.co.za/flyers/weekly-deals.pdf',
    previewUrl: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f',
    categories: ['Groceries', 'Meat', 'Produce', 'Beverages'],
  },
  {
    id: '4',
    retailer: 'Woolworths',
    title: 'Woolworths Weekly Specials',
    validFrom: '2026-03-29',
    validUntil: '2026-04-04',
    pages: 28,
    size: '14.1 MB',
    downloadUrl: 'https://www.woolworths.co.za/flyers/weekly-specials.pdf',
    previewUrl: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f',
    categories: ['Food', 'Home', 'Fashion', 'Beauty'],
  },
  {
    id: '5',
    retailer: 'OK Foods',
    title: 'OK Foods Weekly Catalogue',
    validFrom: '2026-03-29',
    validUntil: '2026-04-04',
    pages: 12,
    size: '6.3 MB',
    downloadUrl: 'https://www.okfoods.co.za/flyers/weekly-catalogue.pdf',
    previewUrl: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f',
    categories: ['Groceries', 'Household', 'Beverages'],
  },
];

export default function FlyersDownload() {
  const [selectedFlyer, setSelectedFlyer] = useState<Flyer | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);

  const handleDownload = async (flyer: Flyer) => {
    setDownloading(flyer.id);
    try {
      // Simulate download
      setTimeout(() => {
        toast.success(`${flyer.retailer} catalogue downloaded!`);
        setDownloading(null);
      }, 1500);

      // In production, trigger actual download:
      // const link = document.createElement('a');
      // link.href = flyer.downloadUrl;
      // link.download = `${flyer.retailer}-${flyer.validFrom}.pdf`;
      // document.body.appendChild(link);
      // link.click();
      // document.body.removeChild(link);
    } catch (error) {
      toast.error('Download failed');
      setDownloading(null);
    }
  };

  const handleViewOnline = (flyer: Flyer) => {
    window.open(flyer.downloadUrl, '_blank');
    toast.success(`Opening ${flyer.retailer} catalogue...`);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary via-accent to-secondary text-white p-6 rounded-b-3xl">
        <h1 className="text-3xl font-black mb-2">Weekly Flyers</h1>
        <p className="text-sm opacity-90">Download catalogues from all your favorite retailers</p>
      </div>

      {/* Flyers Grid */}
      <div className="p-4 space-y-3">
        {REAL_FLYERS.map((flyer) => (
          <Card key={flyer.id} className="overflow-hidden border-border hover:shadow-lg transition-shadow">
            <div className="flex gap-3 p-3">
              {/* Preview Image */}
              <div className="w-24 h-32 rounded-lg overflow-hidden flex-shrink-0 bg-muted">
                <img
                  src={flyer.previewUrl}
                  alt={flyer.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Flyer Details */}
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-bold text-foreground">{flyer.retailer}</h3>
                      <p className="text-xs text-muted-foreground line-clamp-2">{flyer.title}</p>
                    </div>
                  </div>

                  {/* Validity Badge */}
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-primary/20 text-primary text-xs">
                      <Calendar className="w-3 h-3 mr-1" />
                      Valid until {new Date(flyer.validUntil).toLocaleDateString()}
                    </Badge>
                  </div>

                  {/* Categories */}
                  <div className="flex flex-wrap gap-1 mb-2">
                    {flyer.categories.slice(0, 2).map((cat) => (
                      <Badge key={cat} variant="outline" className="text-xs">
                        {cat}
                      </Badge>
                    ))}
                    {flyer.categories.length > 2 && (
                      <Badge variant="outline" className="text-xs">
                        +{flyer.categories.length - 2} more
                      </Badge>
                    )}
                  </div>
                </div>

                {/* File Info */}
                <div className="text-xs text-muted-foreground">
                  <FileText className="w-3 h-3 inline mr-1" />
                  {flyer.pages} pages • {flyer.size}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-2 justify-center">
                <Button
                  onClick={() => handleDownload(flyer)}
                  disabled={downloading === flyer.id}
                  className="bg-primary hover:bg-primary/90 text-white font-bold text-xs py-1 px-2 rounded-lg flex items-center justify-center gap-1 whitespace-nowrap"
                >
                  <Download className="w-3 h-3" />
                  {downloading === flyer.id ? 'Downloading...' : 'Download'}
                </Button>
                <Button
                  onClick={() => handleViewOnline(flyer)}
                  variant="outline"
                  className="border-primary text-primary hover:bg-primary/10 font-bold text-xs py-1 px-2 rounded-lg flex items-center justify-center gap-1"
                >
                  <ExternalLink className="w-3 h-3" />
                  View
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Info Section */}
      <div className="p-4 mt-4">
        <Card className="p-4 border-border bg-primary/5">
          <h3 className="font-bold text-foreground mb-2">💡 Pro Tip</h3>
          <p className="text-sm text-muted-foreground">
            Download the latest weekly flyers to see all available specials. Flyers are updated every week with new deals and promotions from your favorite retailers.
          </p>
        </Card>
      </div>
    </div>
  );
}
