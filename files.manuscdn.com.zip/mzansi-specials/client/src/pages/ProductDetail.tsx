import { useState } from 'react';
import { useRoute, useLocation } from 'wouter';
import { ArrowLeft, Heart, Share2, ShoppingCart, TrendingDown, MapPin, Clock } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { FC } from 'react';

/**
 * PRODUCT DETAIL PAGE - Store Comparison & Savings Focus
 * 
 * Purpose: Show all retailer prices for a product with savings highlights
 * Design: Large product image, prominent cheapest price, store comparison matrix
 */

const ProductDetail: FC = () => {
  const [, params] = useRoute('/product/:id');
  const [, setLocation] = useLocation();
  const { t } = useTranslation();
  const [quantity, setQuantity] = useState(1);
  const [isFavorited, setIsFavorited] = useState(false);

  // Mock product data
  const product = {
    id: params?.id || '1',
    name: 'Full Cream Milk 1L',
    brand: 'Clover',
    category: 'Dairy',
    description: 'Fresh, pasteurized full cream milk. Rich in calcium and vitamin D. Perfect for your family.',
    image: '🥛',
    prices: [
      { store: 'Checkers', price: 17.99, original: 21.99, discount: 18, inStock: true },
      { store: 'Pick n Pay', price: 19.99, original: 21.99, discount: 9, inStock: true },
      { store: 'SPAR', price: 18.99, original: 21.99, discount: 14, inStock: true },
      { store: 'Woolworths', price: 20.99, original: 21.99, discount: 5, inStock: true },
      { store: 'OK Foods', price: 21.99, original: 21.99, discount: 0, inStock: false },
    ],
    rating: 4.5,
    reviews: 342,
    lastUpdated: 'Today at 10:30 AM',
  };

  const lowestPrice = Math.min(...product.prices.map(p => p.price));
  const highestPrice = Math.max(...product.prices.map(p => p.price));
  const savings = highestPrice - lowestPrice;
  const cheapestStore = product.prices.find(p => p.price === lowestPrice);

  const navigate = (path: string) => setLocation(path);

  return (
    <div className="main-content" style={{ background: '#FFFFFF' }}>
      {/* HEADER */}
      <div style={{
        background: 'linear-gradient(135deg, #00A651 0%, #008040 100%)',
        color: 'white',
        padding: '1rem',
        position: 'sticky',
        top: 0,
        zIndex: 10,
        display: 'flex',
        alignItems: 'center',
        gap: '1rem',
      }}>
        <button
          onClick={() => navigate(-1 as any)}
          style={{
            background: 'rgba(255, 255, 255, 0.2)',
            border: 'none',
            color: 'white',
            padding: '0.5rem',
            borderRadius: '0.5rem',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <ArrowLeft style={{ width: '24px', height: '24px' }} />
        </button>
        <h1 style={{ fontSize: '1.25rem', fontWeight: 800, margin: 0 }}>
          {t('product.details', 'Product Details')}
        </h1>
      </div>

      <div className="container" style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem 1rem' }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '2rem',
          marginBottom: '3rem',
        }}>
          {/* LEFT: Product Image & Info */}
          <div>
            {/* Product Image */}
            <div style={{
              background: 'linear-gradient(135deg, #F5F5F5, #FFFBF0)',
              borderRadius: '1rem',
              height: '400px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '6rem',
              marginBottom: '1.5rem',
              border: '2px solid #E0E0E0',
            }}>
              {product.image}
            </div>

            {/* Product Info */}
            <div style={{ marginBottom: '1.5rem' }}>
              <div style={{ fontSize: '0.85rem', color: '#999', fontWeight: 600, marginBottom: '0.5rem', textTransform: 'uppercase' }}>
                {product.category} • {product.brand}
              </div>
              <h1 style={{ fontSize: '1.75rem', fontWeight: 800, color: '#1A1A1A', marginBottom: '1rem' }}>
                {product.name}
              </h1>
              <p style={{ fontSize: '1rem', color: '#666', lineHeight: 1.6, marginBottom: '1rem' }}>
                {product.description}
              </p>

              {/* Rating */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
                <span style={{ fontSize: '1rem', color: '#FFB800' }}>⭐ {product.rating}</span>
                <span style={{ fontSize: '0.9rem', color: '#666' }}>({product.reviews} {t('product.reviews', 'reviews')})</span>
              </div>

              {/* Last Updated */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', color: '#999' }}>
                <Clock style={{ width: '16px', height: '16px' }} />
                {t('product.lastUpdated', 'Last updated')}: {product.lastUpdated}
              </div>
            </div>
          </div>

          {/* RIGHT: Price & CTA */}
          <div>
            {/* Cheapest Price Card */}
            <div style={{
              background: 'linear-gradient(135deg, #00A651, #008040)',
              color: 'white',
              borderRadius: '1rem',
              padding: '2rem',
              marginBottom: '1.5rem',
              textAlign: 'center',
            }}>
              <div style={{ fontSize: '0.9rem', opacity: 0.9, marginBottom: '0.5rem' }}>
                {t('product.bestPrice', 'Best Price')}
              </div>
              <div style={{ fontSize: '3rem', fontWeight: 800, marginBottom: '0.5rem' }}>
                R{lowestPrice.toFixed(2)}
              </div>
              <div style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '1rem' }}>
                {t('product.at', 'at')} <strong>{cheapestStore?.store}</strong>
              </div>
              {savings > 0 && (
                <div style={{
                  background: 'rgba(255, 255, 255, 0.2)',
                  padding: '0.75rem',
                  borderRadius: '0.75rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.5rem',
                }}>
                  <TrendingDown style={{ width: '20px', height: '20px' }} />
                  <span>{t('product.saveUpTo', 'Save up to')} <strong>R{savings.toFixed(2)}</strong> {t('product.vsOtherStores', 'vs other stores')}</span>
                </div>
              )}
            </div>

            {/* Quantity & CTA */}
            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ display: 'block', fontSize: '0.9rem', fontWeight: 600, marginBottom: '0.5rem', color: '#1A1A1A' }}>
                {t('product.quantity', 'Quantity')}
              </label>
              <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  style={{
                    background: '#F0F0F0',
                    border: '1px solid #E0E0E0',
                    padding: '0.75rem 1rem',
                    borderRadius: '0.5rem',
                    cursor: 'pointer',
                    fontWeight: 600,
                  }}
                >
                  −
                </button>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  style={{
                    flex: 1,
                    border: '1px solid #E0E0E0',
                    padding: '0.75rem',
                    borderRadius: '0.5rem',
                    textAlign: 'center',
                    fontWeight: 600,
                  }}
                />
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  style={{
                    background: '#F0F0F0',
                    border: '1px solid #E0E0E0',
                    padding: '0.75rem 1rem',
                    borderRadius: '0.5rem',
                    cursor: 'pointer',
                    fontWeight: 600,
                  }}
                >
                  +
                </button>
              </div>

              {/* Action Buttons */}
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button
                  style={{
                    flex: 1,
                    background: 'linear-gradient(135deg, #00A651, #008040)',
                    color: 'white',
                    border: 'none',
                    padding: '1rem',
                    borderRadius: '0.75rem',
                    fontWeight: 700,
                    fontSize: '1rem',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '0.5rem',
                  }}
                >
                  <ShoppingCart style={{ width: '20px', height: '20px' }} />
                  {t('product.addToList', 'Add to List')}
                </button>
                <button
                  onClick={() => setIsFavorited(!isFavorited)}
                  style={{
                    background: isFavorited ? '#FF6600' : '#F0F0F0',
                    color: isFavorited ? 'white' : '#1A1A1A',
                    border: 'none',
                    padding: '1rem',
                    borderRadius: '0.75rem',
                    fontWeight: 700,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Heart style={{ width: '20px', height: '20px', fill: isFavorited ? 'white' : 'none' }} />
                </button>
              </div>
            </div>

            {/* Share Button */}
            <button
              style={{
                width: '100%',
                background: '#F0F0F0',
                border: '1px solid #E0E0E0',
                padding: '0.75rem',
                borderRadius: '0.75rem',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem',
              }}
            >
              <Share2 style={{ width: '18px', height: '18px' }} />
              {t('product.share', 'Share Deal')}
            </button>
          </div>
        </div>

        {/* STORE COMPARISON MATRIX */}
        <div style={{ marginBottom: '3rem' }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800, marginBottom: '1.5rem', color: '#1A1A1A' }}>
            {t('product.pricesAtAllStores', 'Prices at All Stores')}
          </h2>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: '1rem',
          }}>
            {product.prices.map((storePrice) => (
              <div
                key={storePrice.store}
                style={{
                  background: storePrice.price === lowestPrice ? 'linear-gradient(135deg, rgba(0, 166, 81, 0.1), rgba(0, 166, 81, 0.05))' : 'white',
                  border: storePrice.price === lowestPrice ? '2px solid #00A651' : '2px solid #E0E0E0',
                  borderRadius: '1rem',
                  padding: '1.5rem',
                  textAlign: 'center',
                  position: 'relative',
                }}
              >
                {storePrice.price === lowestPrice && (
                  <div style={{
                    position: 'absolute',
                    top: '-12px',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    background: '#00A651',
                    color: 'white',
                    padding: '0.25rem 0.75rem',
                    borderRadius: '0.5rem',
                    fontSize: '0.75rem',
                    fontWeight: 700,
                  }}>
                    {t('product.cheapest', 'CHEAPEST')}
                  </div>
                )}

                {/* Store Name */}
                <div style={{ fontSize: '1rem', fontWeight: 700, color: '#1A1A1A', marginBottom: '1rem' }}>
                  {storePrice.store}
                </div>

                {/* Stock Status */}
                <div style={{
                  fontSize: '0.8rem',
                  fontWeight: 600,
                  marginBottom: '1rem',
                  color: storePrice.inStock ? '#00A651' : '#E31B23',
                }}>
                  {storePrice.inStock ? '✓ In Stock' : '✗ Out of Stock'}
                </div>

                {/* Price */}
                <div style={{ marginBottom: '0.75rem' }}>
                  <div style={{ fontSize: '2rem', fontWeight: 800, color: storePrice.price === lowestPrice ? '#00A651' : '#1A1A1A' }}>
                    R{storePrice.price.toFixed(2)}
                  </div>
                  {storePrice.original > storePrice.price && (
                    <div style={{ fontSize: '0.85rem', color: '#999', textDecoration: 'line-through' }}>
                      R{storePrice.original.toFixed(2)}
                    </div>
                  )}
                </div>

                {/* Discount Badge */}
                {storePrice.discount > 0 && (
                  <div style={{
                    background: 'linear-gradient(135deg, #E31B23, #FF6600)',
                    color: 'white',
                    padding: '0.5rem',
                    borderRadius: '0.5rem',
                    fontSize: '0.9rem',
                    fontWeight: 700,
                    marginBottom: '1rem',
                  }}>
                    {t('product.save', 'Save')} {storePrice.discount}%
                  </div>
                )}

                {/* CTA Button */}
                <button
                  style={{
                    width: '100%',
                    background: storePrice.price === lowestPrice ? 'linear-gradient(135deg, #00A651, #008040)' : '#F0F0F0',
                    color: storePrice.price === lowestPrice ? 'white' : '#1A1A1A',
                    border: 'none',
                    padding: '0.75rem',
                    borderRadius: '0.5rem',
                    fontWeight: 700,
                    cursor: storePrice.inStock ? 'pointer' : 'not-allowed',
                    opacity: storePrice.inStock ? 1 : 0.5,
                  }}
                  disabled={!storePrice.inStock}
                >
                  {storePrice.inStock ? t('product.viewAtStore', 'View at Store') : t('product.outOfStock', 'Out of Stock')}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* PRODUCT SPECS */}
        <div style={{
          background: '#F5F5F5',
          borderRadius: '1rem',
          padding: '2rem',
          marginBottom: '2rem',
        }}>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: '1rem', color: '#1A1A1A' }}>
            {t('product.productInfo', 'Product Information')}
          </h3>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '1.5rem',
          }}>
            <div>
              <div style={{ fontSize: '0.85rem', color: '#999', fontWeight: 600, marginBottom: '0.25rem' }}>
                {t('product.brand', 'Brand')}
              </div>
              <div style={{ fontSize: '1rem', fontWeight: 700, color: '#1A1A1A' }}>
                {product.brand}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '0.85rem', color: '#999', fontWeight: 600, marginBottom: '0.25rem' }}>
                {t('product.category', 'Category')}
              </div>
              <div style={{ fontSize: '1rem', fontWeight: 700, color: '#1A1A1A' }}>
                {product.category}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '0.85rem', color: '#999', fontWeight: 600, marginBottom: '0.25rem' }}>
                {t('product.priceRange', 'Price Range')}
              </div>
              <div style={{ fontSize: '1rem', fontWeight: 700, color: '#1A1A1A' }}>
                R{lowestPrice.toFixed(2)} - R{highestPrice.toFixed(2)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
