import { useState } from 'react';
import { Star, Trophy, Medal, Crown, TrendingUp, Share2, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useAuth } from '@/_core/hooks/useAuth';

/**
 * User Profile Page
 * Display user stars, tier, achievements, and contributions
 */

interface UserStats {
  totalStars: number;
  tier: 'Rookie' | 'Chief' | 'Captain' | 'President';
  barcodeScans: number;
  receiptScans: number;
  pricesSubmitted: number;
  accuracyRate: number;
  joinDate: Date;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt?: Date;
  progress?: number;
  maxProgress?: number;
}

export default function UserProfile() {
  const { user } = useAuth();

  const [userStats] = useState<UserStats>({
    totalStars: 47,
    tier: 'Chief',
    barcodeScans: 23,
    receiptScans: 4,
    pricesSubmitted: 27,
    accuracyRate: 94,
    joinDate: new Date('2026-02-15'),
  });

  const [achievements] = useState<Achievement[]>([
    {
      id: '1',
      name: 'First Scan',
      description: 'Scan your first barcode',
      icon: '📱',
      unlockedAt: new Date('2026-02-16'),
    },
    {
      id: '2',
      name: 'Scanner Pro',
      description: 'Complete 10 barcode scans',
      icon: '🎯',
      unlockedAt: new Date('2026-02-20'),
    },
    {
      id: '3',
      name: 'Receipt Master',
      description: 'Submit 5 receipts',
      icon: '🧾',
      unlockedAt: new Date('2026-03-01'),
    },
    {
      id: '4',
      name: 'Price Detective',
      description: 'Achieve 90% accuracy rate',
      icon: '🔍',
      unlockedAt: new Date('2026-03-15'),
    },
    {
      id: '5',
      name: 'Bargain Hunter',
      description: 'Find 50 deals',
      icon: '🏆',
      progress: 47,
      maxProgress: 50,
    },
    {
      id: '6',
      name: 'Grocery Legend',
      description: 'Reach President tier',
      icon: '👑',
      progress: 47,
      maxProgress: 100,
    },
  ]);

  const tierInfo = {
    Rookie: { icon: '🌱', color: 'bg-blue-50', textColor: 'text-blue-600', starsNeeded: 0 },
    Chief: { icon: '🔥', color: 'bg-orange-50', textColor: 'text-orange-600', starsNeeded: 25 },
    Captain: { icon: '⚡', color: 'bg-purple-50', textColor: 'text-purple-600', starsNeeded: 75 },
    President: { icon: '👑', color: 'bg-yellow-50', textColor: 'text-yellow-600', starsNeeded: 150 },
  };

  const currentTierInfo = tierInfo[userStats.tier];
  const nextTier = userStats.tier === 'President' ? null : Object.entries(tierInfo).find(
    ([_, info]) => info.starsNeeded > userStats.totalStars
  );

  const starsToNextTier = nextTier ? nextTier[1].starsNeeded - userStats.totalStars : 0;

  const handleShareProfile = () => {
    const shareText = `I'm a ${userStats.tier} on Mzansi Specials! 🎉 I've submitted ${userStats.pricesSubmitted} prices and earned ${userStats.totalStars} ⭐ stars. Join me in helping South Africa find the best grocery deals!`;
    if (navigator.share) {
      navigator.share({
        title: 'My Mzansi Specials Profile',
        text: shareText,
        url: window.location.href,
      });
    } else {
      toast.success('Profile link copied!');
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-border p-4">
        <h1 className="text-2xl font-bold text-foreground">My Profile</h1>
      </div>

      {/* Tier Card */}
      <div className={`${currentTierInfo.color} border-b border-border p-4`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-muted-foreground font-semibold">YOUR TIER</p>
            <h2 className={`text-4xl font-bold ${currentTierInfo.textColor}`}>
              {currentTierInfo.icon} {userStats.tier}
            </h2>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground font-semibold">TOTAL STARS</p>
            <p className="text-4xl font-bold text-primary">{userStats.totalStars} ⭐</p>
          </div>
        </div>

        {/* Tier Progress */}
        {userStats.tier !== 'President' && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-semibold text-foreground">
                {starsToNextTier} stars to {nextTier?.[0]}
              </p>
              <p className="text-xs text-muted-foreground">
                {Math.round((userStats.totalStars / (nextTier?.[1].starsNeeded || 100)) * 100)}%
              </p>
            </div>
            <div className="w-full bg-white/50 rounded-full h-2 overflow-hidden">
              <div
                className="bg-primary h-full rounded-full transition-all duration-300"
                style={{
                  width: `${Math.min(
                    (userStats.totalStars / (nextTier?.[1].starsNeeded || 100)) * 100,
                    100
                  )}%`,
                }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Stats Grid */}
      <div className="p-4 grid grid-cols-2 gap-3">
        <Card className="p-3 text-center border-border">
          <p className="text-2xl mb-1">📱</p>
          <p className="text-xs text-muted-foreground">Barcode Scans</p>
          <p className="text-2xl font-bold text-foreground">{userStats.barcodeScans}</p>
        </Card>
        <Card className="p-3 text-center border-border">
          <p className="text-2xl mb-1">🧾</p>
          <p className="text-xs text-muted-foreground">Receipt Scans</p>
          <p className="text-2xl font-bold text-foreground">{userStats.receiptScans}</p>
        </Card>
        <Card className="p-3 text-center border-border">
          <p className="text-2xl mb-1">💰</p>
          <p className="text-xs text-muted-foreground">Prices Submitted</p>
          <p className="text-2xl font-bold text-foreground">{userStats.pricesSubmitted}</p>
        </Card>
        <Card className="p-3 text-center border-border">
          <p className="text-2xl mb-1">✓</p>
          <p className="text-xs text-muted-foreground">Accuracy Rate</p>
          <p className="text-2xl font-bold text-secondary">{userStats.accuracyRate}%</p>
        </Card>
      </div>

      {/* Member Since */}
      <div className="px-4 py-3 bg-muted/30 border-b border-border">
        <p className="text-xs text-muted-foreground">
          Member since {userStats.joinDate.toLocaleDateString('en-ZA', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })}
        </p>
      </div>

      {/* Achievements Section */}
      <div className="p-4">
        <h3 className="text-lg font-bold text-foreground mb-3">Achievements</h3>

        <div className="grid grid-cols-2 gap-3">
          {achievements.map((achievement) => (
            <Card
              key={achievement.id}
              className={`p-3 text-center border-2 transition-all ${
                achievement.unlockedAt
                  ? 'border-primary bg-primary/5'
                  : 'border-border opacity-50'
              }`}
            >
              <p className="text-3xl mb-2">{achievement.icon}</p>
              <p className="text-xs font-bold text-foreground mb-1">{achievement.name}</p>
              <p className="text-xs text-muted-foreground">{achievement.description}</p>

              {achievement.progress !== undefined && (
                <div className="mt-2">
                  <div className="w-full bg-muted rounded-full h-1 overflow-hidden">
                    <div
                      className="bg-primary h-full rounded-full"
                      style={{
                        width: `${(achievement.progress / (achievement.maxProgress || 1)) * 100}%`,
                      }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {achievement.progress}/{achievement.maxProgress}
                  </p>
                </div>
              )}

              {achievement.unlockedAt && (
                <Badge className="mt-2 bg-primary text-white text-xs">
                  Unlocked
                </Badge>
              )}
            </Card>
          ))}
        </div>
      </div>

      {/* Tier Breakdown */}
      <div className="p-4">
        <h3 className="text-lg font-bold text-foreground mb-3">Tier System</h3>

        <div className="space-y-2">
          {Object.entries(tierInfo).map(([tier, info]) => (
            <Card
              key={tier}
              className={`p-3 border-2 ${
                userStats.tier === tier
                  ? 'border-primary bg-primary/5'
                  : 'border-border'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{info.icon}</span>
                  <div>
                    <p className={`font-bold ${info.textColor}`}>{tier}</p>
                    <p className="text-xs text-muted-foreground">
                      {info.starsNeeded}+ stars
                    </p>
                  </div>
                </div>
                {userStats.tier === tier && (
                  <Badge className="bg-primary text-white">Current</Badge>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-4 space-y-2">
        <Button
          onClick={handleShareProfile}
          className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
        >
          <Share2 className="w-5 h-5" />
          Share Profile
        </Button>
        <Button
          variant="outline"
          className="w-full border-2 border-border font-bold py-3 rounded-lg flex items-center justify-center gap-2"
        >
          <Settings className="w-5 h-5" />
          Settings
        </Button>
      </div>
    </div>
  );
}
