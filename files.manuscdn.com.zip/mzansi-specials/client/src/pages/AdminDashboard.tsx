import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Users, TrendingUp, Settings, LogOut, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import AnalyticsDashboard from '@/components/AnalyticsDashboard';

/**
 * Hidden Admin Dashboard
 * Access via: /admin-mzansi-secret-2024
 * Only visible to authenticated admin users
 */

interface AdminStats {
  totalUsers: number;
  totalScans: number;
  totalPrices: number;
  activeDeals: number;
  priceUpdates: number;
  lastUpdate: string;
}

interface PriceSubmission {
  id: string;
  productName: string;
  barcode: string;
  price: number;
  retailer: string;
  submittedBy: string;
  timestamp: string;
  verified: boolean;
  stars: number;
}

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const { user, logout } = useAuth();
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 1247,
    totalScans: 5843,
    totalPrices: 12456,
    activeDeals: 1234,
    priceUpdates: 342,
    lastUpdate: new Date().toLocaleString(),
  });

  const [submissions, setSubmissions] = useState<PriceSubmission[]>([
    {
      id: '1',
      productName: 'Coca-Cola Original 2L',
      barcode: '6001234567890',
      price: 3499,
      retailer: 'Checkers',
      submittedBy: 'user_123',
      timestamp: new Date(Date.now() - 5 * 60000).toLocaleString(),
      verified: true,
      stars: 1,
    },
    {
      id: '2',
      productName: 'Clover Milk 1L',
      barcode: '6009876543210',
      price: 1899,
      retailer: 'Pick n Pay',
      submittedBy: 'user_456',
      timestamp: new Date(Date.now() - 15 * 60000).toLocaleString(),
      verified: false,
      stars: 1,
    },
  ]);

  const [activeTab, setActiveTab] = useState<'analytics' | 'overview' | 'submissions' | 'settings'>('analytics');

  // Check admin access
  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    // Simple admin check - in production, verify against backend
    const isAdmin = user.role === 'admin' || user.email?.includes('admin');
    if (!isAdmin) {
      toast.error('Unauthorized access');
      navigate('/');
    }
  }, [user, navigate]);

  const handleVerifySubmission = (id: string) => {
    setSubmissions(
      submissions.map((sub) => (sub.id === id ? { ...sub, verified: true } : sub))
    );
    toast.success('Price submission verified');
  };

  const handleRejectSubmission = (id: string) => {
    setSubmissions(submissions.filter((sub) => sub.id !== id));
    toast.success('Price submission rejected');
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-primary via-secondary to-accent text-white p-6 rounded-b-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-black">Admin Dashboard</h1>
            <p className="text-sm opacity-90">Manage prices, users, and submissions</p>
          </div>
          <Button
            onClick={handleLogout}
            className="bg-white/20 hover:bg-white/30 text-white font-bold flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2">
          <Button
            onClick={() => setActiveTab('analytics')}
            variant={activeTab === 'analytics' ? 'default' : 'outline'}
            className={
              activeTab === 'analytics'
                ? 'bg-white text-primary hover:bg-gray-100'
                : 'bg-white/20 text-white hover:bg-white/30 border-0'
            }
          >
            📊 Analytics
          </Button>
          <Button
            onClick={() => setActiveTab('overview')}
            variant={activeTab === 'overview' ? 'default' : 'outline'}
            className={
              activeTab === 'overview'
                ? 'bg-white text-primary hover:bg-gray-100'
                : 'bg-white/20 text-white hover:bg-white/30 border-0'
            }
          >
            <BarChart className="w-4 h-4 mr-2" />
            Overview
          </Button>
          <Button
            onClick={() => setActiveTab('submissions')}
            variant={activeTab === 'submissions' ? 'default' : 'outline'}
            className={
              activeTab === 'submissions'
                ? 'bg-white text-primary hover:bg-gray-100'
                : 'bg-white/20 text-white hover:bg-white/30 border-0'
            }
          >
            <AlertCircle className="w-4 h-4 mr-2" />
            Submissions ({submissions.filter((s) => !s.verified).length})
          </Button>
          <Button
            onClick={() => setActiveTab('settings')}
            variant={activeTab === 'settings' ? 'default' : 'outline'}
            className={
              activeTab === 'settings'
                ? 'bg-white text-primary hover:bg-gray-100'
                : 'bg-white/20 text-white hover:bg-white/30 border-0'
            }
          >
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>

      {/* Analytics Tab */}
      {activeTab === 'analytics' && (
        <div className="p-4">
          <AnalyticsDashboard />
        </div>
      )}

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="p-4 space-y-4">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <Card className="p-4 border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Total Users</p>
                  <p className="text-2xl font-bold text-primary">{stats.totalUsers.toLocaleString()}</p>
                </div>
                <Users className="w-8 h-8 text-primary/30" />
              </div>
            </Card>

            <Card className="p-4 border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Total Scans</p>
                  <p className="text-2xl font-bold text-secondary">{stats.totalScans.toLocaleString()}</p>
                </div>
                <BarChart className="w-8 h-8 text-secondary/30" />
              </div>
            </Card>

            <Card className="p-4 border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Prices Submitted</p>
                  <p className="text-2xl font-bold text-accent">{stats.totalPrices.toLocaleString()}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-accent/30" />
              </div>
            </Card>

            <Card className="p-4 border-border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Active Deals</p>
                  <p className="text-2xl font-bold text-primary">{stats.activeDeals.toLocaleString()}</p>
                </div>
                <BarChart className="w-8 h-8 text-primary/30" />
              </div>
            </Card>
          </div>

          {/* System Status */}
          <Card className="p-4 border-border">
            <h3 className="font-bold text-foreground mb-3">System Status</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Price Update Scheduler</span>
                <Badge className="bg-green-500">Running</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Last Update</span>
                <span className="text-sm font-semibold">{stats.lastUpdate}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Updates This Hour</span>
                <span className="text-sm font-semibold">{stats.priceUpdates}</span>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Submissions Tab */}
      {activeTab === 'submissions' && (
        <div className="p-4 space-y-3">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-foreground">Pending Submissions</h3>
            <Badge className="bg-accent">{submissions.filter((s) => !s.verified).length}</Badge>
          </div>

          {submissions.map((submission) => (
            <Card key={submission.id} className="p-4 border-border">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-semibold text-foreground">{submission.productName}</p>
                    <p className="text-xs text-muted-foreground">Barcode: {submission.barcode}</p>
                  </div>
                  {submission.verified ? (
                    <Badge className="bg-green-500">Verified</Badge>
                  ) : (
                    <Badge variant="outline">Pending</Badge>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">Price</p>
                    <p className="font-bold text-primary">R{(submission.price / 100).toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Retailer</p>
                    <p className="font-bold">{submission.retailer}</p>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground">
                  Submitted by {submission.submittedBy} • {submission.timestamp}
                </div>

                {!submission.verified && (
                  <div className="flex gap-2 pt-2">
                    <Button
                      onClick={() => handleVerifySubmission(submission.id)}
                      className="flex-1 bg-green-500 hover:bg-green-600 text-white font-bold text-sm py-2 rounded-lg"
                    >
                      ✓ Verify
                    </Button>
                    <Button
                      onClick={() => handleRejectSubmission(submission.id)}
                      className="flex-1 bg-red-500 hover:bg-red-600 text-white font-bold text-sm py-2 rounded-lg"
                    >
                      ✕ Reject
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Settings Tab */}
      {activeTab === 'settings' && (
        <div className="p-4 space-y-4">
          <Card className="p-4 border-border">
            <h3 className="font-bold text-foreground mb-3">Price Update Settings</h3>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-semibold text-foreground">Update Frequency</label>
                <select className="w-full mt-2 p-2 border-2 border-border rounded-lg text-sm">
                  <option>Every 1 hour</option>
                  <option>Every 2 hours</option>
                  <option>Every 4 hours</option>
                  <option>Daily</option>
                </select>
              </div>
              <Button className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-2 rounded-lg">
                Save Settings
              </Button>
            </div>
          </Card>

          <Card className="p-4 border-border">
            <h3 className="font-bold text-foreground mb-3">Retailer Management</h3>
            <div className="space-y-2">
              {['Checkers', 'Pick n Pay', 'SPAR', 'Woolworths', 'OK Foods'].map((retailer) => (
                <div key={retailer} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                  <span className="text-sm font-semibold">{retailer}</span>
                  <Badge className="bg-green-500">Active</Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
