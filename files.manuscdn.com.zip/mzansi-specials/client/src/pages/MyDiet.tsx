import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';
import { trpc } from '@/lib/trpc';
import { ArrowLeft, Check, Loader2 } from 'lucide-react';
import { useLocation } from 'wouter';

/**
 * My Diet Settings Page
 * Allows users to set their dietary preferences and get personalized recommendations
 */

const DIET_CATEGORIES = [
  { slug: 'gluten-free', name: 'Gluten-Free', icon: '🌾', description: 'Products free from gluten for celiac disease and gluten sensitivity' },
  { slug: 'vegan', name: 'Vegan', icon: '🌱', description: 'Plant-based products with no animal products or by-products' },
  { slug: 'vegetarian', name: 'Vegetarian', icon: '🥬', description: 'Products with no meat, poultry, or fish but may contain dairy and eggs' },
  { slug: 'keto-low-carb', name: 'Keto/Low-Carb', icon: '🥩', description: 'Low carbohydrate products suitable for ketogenic diet' },
  { slug: 'dairy-free', name: 'Dairy-Free', icon: '🥛', description: 'Products with no milk, cheese, butter, or dairy derivatives' },
  { slug: 'lactose-intolerant', name: 'Lactose-Intolerant', icon: '🚫🥛', description: 'Products low or free in lactose for lactose intolerance' },
  { slug: 'organic', name: 'Organic', icon: '🌿', description: 'Certified organic products grown without synthetic pesticides' },
  { slug: 'sugar-free-low-sugar', name: 'Sugar-Free/Low-Sugar', icon: '🍬', description: 'Products with minimal or no added sugar' },
  { slug: 'halal', name: 'Halal', icon: '☪️', description: 'Products prepared according to Islamic dietary laws' },
  { slug: 'kosher', name: 'Kosher', icon: '✡️', description: 'Products prepared according to Jewish dietary laws' },
  { slug: 'low-sodium-heart-healthy', name: 'Low-Sodium/Heart-Healthy', icon: '❤️', description: 'Low sodium products for heart health and blood pressure management' },
  { slug: 'nut-free', name: 'Nut-Free', icon: '🚫🥜', description: 'Products free from tree nuts and peanuts for allergy sufferers' },
  { slug: 'soy-free', name: 'Soy-Free', icon: '🚫🫘', description: 'Products with no soy or soy derivatives' },
  { slug: 'non-gmo', name: 'Non-GMO', icon: '🧬', description: 'Products made without genetically modified organisms' },
  { slug: 'paleo', name: 'Paleo', icon: '🦴', description: 'Products aligned with paleo diet (whole foods, no processed)' },
  { slug: 'high-protein', name: 'High-Protein', icon: '💪', description: 'Products with high protein content for muscle building' },
  { slug: 'diabetic-friendly', name: 'Diabetic-Friendly', icon: '🩺', description: 'Products suitable for diabetic diets with controlled sugar and carbs' },
  { slug: 'egg-free', name: 'Egg-Free', icon: '🚫🥚', description: 'Products with no eggs or egg derivatives' },
  { slug: 'shellfish-free', name: 'Shellfish-Free', icon: '🚫🦐', description: 'Products free from shellfish and crustaceans' },
  { slug: 'sesame-free', name: 'Sesame-Free', icon: '🚫🌰', description: 'Products with no sesame seeds or sesame oil' },
];

export default function MyDiet() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedDiets, setSelectedDiets] = useState<string[]>([]);
  const [primaryDiet, setPrimaryDiet] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Fetch user diet preferences
  const { data: userPreferences, isLoading: isLoadingPrefs } = trpc.diet.getPreferences.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  // Set diet preferences mutation
  const setDietsMutation = trpc.diet.setPreferences.useMutation({
    onSuccess: () => {
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    },
  });

  // Initialize from user preferences
  useEffect(() => {
    if (userPreferences) {
      const diets = userPreferences.map((p: any) => p.slug);
      const primary = userPreferences.find((p: any) => p.isPrimary === 1)?.slug || '';
      setSelectedDiets(diets);
      setPrimaryDiet(primary);
    }
  }, [userPreferences]);

  if (loading || isLoadingPrefs) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <h2 className="text-2xl font-bold text-foreground mb-4">Please Log In</h2>
          <p className="text-muted-foreground mb-6">You need to be logged in to set your dietary preferences.</p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="w-full bg-primary hover:bg-primary/90"
          >
            Log In
          </Button>
        </Card>
      </div>
    );
  }

  const handleToggleDiet = (slug: string) => {
    setSelectedDiets((prev) =>
      prev.includes(slug) ? prev.filter((d) => d !== slug) : [...prev, slug]
    );
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await setDietsMutation.mutateAsync({
        dietSlugs: selectedDiets,
        primarySlug: primaryDiet,
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-gradient-to-r from-sidebar via-sidebar to-sidebar shadow-lg border-b-4 border-primary">
        <div className="container px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation('/')}
              className="p-2 hover:bg-primary/20 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-primary" />
            </button>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-primary drop-shadow-lg">My Dietary Preferences</h1>
              <p className="text-sm text-primary-foreground/80">Personalize your shopping experience</p>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Success Message */}
          {saveSuccess && (
            <div className="mb-6 p-4 bg-green-100 border-2 border-green-500 rounded-lg flex items-center gap-3">
              <Check className="w-5 h-5 text-green-600" />
              <p className="text-green-700 font-semibold">Your dietary preferences have been saved!</p>
            </div>
          )}

          {/* Introduction Card */}
          <Card className="p-6 mb-8 bg-gradient-to-r from-primary/10 to-accent/10 border-2 border-primary/20">
            <h2 className="text-xl font-bold text-foreground mb-2">🥗 Tell Us About Your Diet</h2>
            <p className="text-foreground/80">
              Select your dietary preferences to get personalized product recommendations and filter results by your dietary needs. You can choose multiple preferences.
            </p>
          </Card>

          {/* Diet Categories Grid */}
          <div className="space-y-8">
            {/* Allergies & Intolerances */}
            <div>
              <h3 className="text-lg font-bold text-foreground mb-4">🚫 Allergies & Intolerances</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {DIET_CATEGORIES.filter((d) =>
                  ['gluten-free', 'lactose-intolerant', 'dairy-free', 'nut-free', 'soy-free', 'egg-free', 'shellfish-free', 'sesame-free'].includes(d.slug)
                ).map((diet) => (
                  <DietCategoryCard
                    key={diet.slug}
                    diet={diet}
                    isSelected={selectedDiets.includes(diet.slug)}
                    isPrimary={primaryDiet === diet.slug}
                    onToggle={() => handleToggleDiet(diet.slug)}
                    onSetPrimary={() => setPrimaryDiet(diet.slug)}
                  />
                ))}
              </div>
            </div>

            {/* Lifestyle Choices */}
            <div>
              <h3 className="text-lg font-bold text-foreground mb-4">🌱 Lifestyle Choices</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {DIET_CATEGORIES.filter((d) =>
                  ['vegan', 'vegetarian', 'paleo', 'keto-low-carb'].includes(d.slug)
                ).map((diet) => (
                  <DietCategoryCard
                    key={diet.slug}
                    diet={diet}
                    isSelected={selectedDiets.includes(diet.slug)}
                    isPrimary={primaryDiet === diet.slug}
                    onToggle={() => handleToggleDiet(diet.slug)}
                    onSetPrimary={() => setPrimaryDiet(diet.slug)}
                  />
                ))}
              </div>
            </div>

            {/* Health & Wellness */}
            <div>
              <h3 className="text-lg font-bold text-foreground mb-4">❤️ Health & Wellness</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {DIET_CATEGORIES.filter((d) =>
                  ['high-protein', 'low-sodium-heart-healthy', 'diabetic-friendly', 'sugar-free-low-sugar'].includes(d.slug)
                ).map((diet) => (
                  <DietCategoryCard
                    key={diet.slug}
                    diet={diet}
                    isSelected={selectedDiets.includes(diet.slug)}
                    isPrimary={primaryDiet === diet.slug}
                    onToggle={() => handleToggleDiet(diet.slug)}
                    onSetPrimary={() => setPrimaryDiet(diet.slug)}
                  />
                ))}
              </div>
            </div>

            {/* Religious & Cultural */}
            <div>
              <h3 className="text-lg font-bold text-foreground mb-4">☪️ Religious & Cultural</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {DIET_CATEGORIES.filter((d) =>
                  ['halal', 'kosher'].includes(d.slug)
                ).map((diet) => (
                  <DietCategoryCard
                    key={diet.slug}
                    diet={diet}
                    isSelected={selectedDiets.includes(diet.slug)}
                    isPrimary={primaryDiet === diet.slug}
                    onToggle={() => handleToggleDiet(diet.slug)}
                    onSetPrimary={() => setPrimaryDiet(diet.slug)}
                  />
                ))}
              </div>
            </div>

            {/* Other */}
            <div>
              <h3 className="text-lg font-bold text-foreground mb-4">🌿 Other</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {DIET_CATEGORIES.filter((d) =>
                  ['organic', 'non-gmo'].includes(d.slug)
                ).map((diet) => (
                  <DietCategoryCard
                    key={diet.slug}
                    diet={diet}
                    isSelected={selectedDiets.includes(diet.slug)}
                    isPrimary={primaryDiet === diet.slug}
                    onToggle={() => handleToggleDiet(diet.slug)}
                    onSetPrimary={() => setPrimaryDiet(diet.slug)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Selected Diets Summary */}
          {selectedDiets.length > 0 && (
            <Card className="mt-8 p-6 bg-primary/5 border-2 border-primary/20">
              <h3 className="text-lg font-bold text-foreground mb-4">📋 Your Selected Preferences</h3>
              <div className="flex flex-wrap gap-2 mb-4">
                {selectedDiets.map((slug) => {
                  const diet = DIET_CATEGORIES.find((d) => d.slug === slug);
                  return (
                    <Badge
                      key={slug}
                      className={`text-sm py-2 px-3 ${
                        primaryDiet === slug
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-primary/20 text-primary border border-primary'
                      }`}
                    >
                      {diet?.icon} {diet?.name}
                      {primaryDiet === slug && <span className="ml-2">⭐ Primary</span>}
                    </Badge>
                  );
                })}
              </div>
              <p className="text-sm text-muted-foreground">
                You have selected {selectedDiets.length} dietary preference{selectedDiets.length !== 1 ? 's' : ''}.
                {primaryDiet && ` Your primary preference is ${DIET_CATEGORIES.find((d) => d.slug === primaryDiet)?.name}.`}
              </p>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="mt-8 flex gap-4 justify-end">
            <Button
              variant="outline"
              onClick={() => setLocation('/')}
              className="border-2 border-primary/30"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={isSaving || selectedDiets.length === 0}
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Save Preferences
                </>
              )}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}

/**
 * Diet Category Card Component
 */
interface DietCategoryCardProps {
  diet: (typeof DIET_CATEGORIES)[0];
  isSelected: boolean;
  isPrimary: boolean;
  onToggle: () => void;
  onSetPrimary: () => void;
}

function DietCategoryCard({
  diet,
  isSelected,
  isPrimary,
  onToggle,
  onSetPrimary,
}: DietCategoryCardProps) {
  return (
    <Card
      className={`p-4 cursor-pointer transition-all border-2 ${
        isSelected
          ? isPrimary
            ? 'border-primary bg-primary/10'
            : 'border-primary/50 bg-primary/5'
          : 'border-border hover:border-primary/30'
      }`}
      onClick={onToggle}
    >
      <div className="flex items-start justify-between mb-3">
        <span className="text-3xl">{diet.icon}</span>
        {isSelected && (
          <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center">
            <Check className="w-3 h-3 text-primary-foreground" />
          </div>
        )}
      </div>
      <h4 className="font-bold text-foreground mb-1">{diet.name}</h4>
      <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{diet.description}</p>
      {isSelected && (
        <Button
          size="sm"
          variant={isPrimary ? 'default' : 'outline'}
          onClick={(e) => {
            e.stopPropagation();
            onSetPrimary();
          }}
          className="w-full text-xs"
        >
          {isPrimary ? '⭐ Primary' : 'Set as Primary'}
        </Button>
      )}
    </Card>
  );
}
