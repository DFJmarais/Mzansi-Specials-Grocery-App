import { useState, useMemo } from 'react';
import { Search, Filter, TrendingDown, MapPin, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { useLocation } from 'wouter';

const MOCK_PRODUCTS = [
  {
    id: 1,
    name: 'Full Cream Milk (1L)',
    category: 'Dairy',
    prices: [
      { store: 'Spar', price: 18.99, special: true, discount: 15 },
      { store: 'Pick n Pay', price: 19.99, special: false },
      { store: 'Checkers', price: 17.99, special: true, discount: 20 },
      { store: 'OK Foods', price: 20.99, special: false },
    ],
  },
  {
    id: 2,
    name: 'Rainbow Butter 500g',
    category: 'Dairy',
    prices: [
      { store: 'Spar', price: 32.99, special: false },
      { store: 'Pick n Pay', price: 34.99, special: true, discount: 10 },
      { store: 'Checkers', price: 31.99, special: true, discount: 15 },
      { store: 'OK Foods', price: 35.99, special: false },
    ],
  },
  {
    id: 3,
    name: 'Fresh Tomatoes 1kg',
    category: 'Produce',
    prices: [
      { store: 'Spar', price: 12.99, special: false },
      { store: 'Pick n Pay', price: 14.99, special: false },
      { store: 'Checkers', price: 11.99, special: true, discount: 30 },
      { store: 'OK Foods', price: 13.99, special: false },
    ],
  },
  {
    id: 4,
    name: 'Free Range Chicken Breast 500g',
    category: 'Meat',
    prices: [
      { store: 'Spar', price: 59.99, special: true, discount: 12 },
      { store: 'Pick n Pay', price: 64.99, special: false },
      { store: 'Checkers', price: 61.99, special: false },
      { store: 'OK Foods', price: 55.99, special: true, discount: 20 },
    ],
  },
];

const CATEGORIES = ['All', 'Dairy', 'Meat', 'Produce', 'Bakery', 'Pantry'];
const STORES = ['All Stores', 'Spar', 'Pick n Pay', 'Checkers', 'OK Foods'];

export default function Home() {
  const { t } = useLanguage();
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStore, setSelectedStore] = useState('All Stores');
  const [showFilters, setShowFilters] = useState(false);

  const filteredProducts = useMemo(() => {
    return MOCK_PRODUCTS.filter((product) => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const getBestPrice = (prices: typeof MOCK_PRODUCTS[0]['prices']) => {
    if (selectedStore === 'All Stores') {
      return prices.reduce((min, p) => (p.price < min.price ? p : min));
    }
    return prices.find((p) => p.store === selectedStore) || prices[0];
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b-2 border-primary/20">
        <div className="container py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">M</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-primary">{t('app.title')}</h1>
                <p className="text-xs text-muted-foreground">{t('app.tagline')}</p>
              </div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder={t('home.search_placeholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-11 border-2 border-primary/30 focus:border-primary"
              />
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowFilters(!showFilters)}
              className="border-2 border-primary/30 hover:bg-primary/10"
            >
              <Filter className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Filters */}
        {showFilters && (
          <div className="border-t-2 border-primary/20 bg-primary/5 py-4">
            <div className="container">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Category Filter */}
                <div>
                  <p className="text-sm font-semibold text-foreground mb-2">{t('browse.filter_by_category')}</p>
                  <div className="flex flex-wrap gap-2">
                    {CATEGORIES.map((cat) => (
                      <Badge
                        key={cat}
                        variant={selectedCategory === cat ? 'default' : 'outline'}
                        className={`cursor-pointer transition-all ${
                          selectedCategory === cat
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-white text-foreground border-primary/30 hover:border-primary'
                        }`}
                        onClick={() => setSelectedCategory(cat)}
                      >
                        {cat === 'All' ? t('browse.all_stores') : t(`category.${cat.toLowerCase()}`)}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Store Filter */}
                <div>
                  <p className="text-sm font-semibold text-foreground mb-2">{t('browse.filter_by_store')}</p>
                  <div className="flex flex-wrap gap-2">
                    {STORES.map((store) => (
                      <Badge
                        key={store}
                        variant={selectedStore === store ? 'default' : 'outline'}
                        className={`cursor-pointer transition-all ${
                          selectedStore === store
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-white text-foreground border-primary/30 hover:border-primary'
                        }`}
                        onClick={() => setSelectedStore(store)}
                      >
                        {store === 'All Stores' ? t('browse.all_stores') : t(`retailer.${store.toLowerCase().replace(/ /g, '_')}`)}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative py-8 md:py-12 overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
          backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663467531875/2YpGsQ5zYUh2Xb4PxAFN6v/mzansi-pattern-background-fvFRWmuPr5scBrfcZvBVn2.webp)',
          backgroundSize: 'cover'
        }} />
        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-primary mb-4">
                {t('home.hero_title')}
              </h2>
              <p className="text-lg text-foreground/80 mb-6">
                {t('home.hero_subtitle')}
              </p>
              <div className="flex gap-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <TrendingDown className="w-5 h-5 text-accent" />
                  {t('home.products_label')}
                </div>
                <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Star className="w-5 h-5 text-accent" />
                  {t('home.stores_label')}
                </div>
              </div>
            </div>
            <div className="hidden md:block">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663467531875/2YpGsQ5zYUh2Xb4PxAFN6v/mzansi-hero-banner-8yLPqjmZ6zz2wnpqgYRsmi.webp"
                alt="South African market"
                className="rounded-xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-8 bg-primary/5">
        <div className="container">
          <div className="grid grid-cols-3 gap-4 md:gap-8">
            <div className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-primary">{t('home.products_available')}</p>
              <p className="text-sm text-muted-foreground">{t('home.products_label')}</p>
            </div>
            <div className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-primary">{t('home.stores_compared')}</p>
              <p className="text-sm text-muted-foreground">{t('home.stores_label')}</p>
            </div>
            <div className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-accent">{t('home.average_savings')}</p>
              <p className="text-sm text-muted-foreground">{t('home.savings_label')}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Browse Categories */}
      <section className="py-12">
        <div className="container">
          <h3 className="text-2xl font-bold mb-6">{t('home.browse_categories')}</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {CATEGORIES.filter(c => c !== 'All').map((cat) => (
              <button
                key={cat}
                onClick={() => navigate('/browse')}
                className="p-4 bg-white border-2 border-primary/20 rounded-lg hover:border-primary hover:shadow-lg transition-all text-center"
              >
                <p className="font-semibold text-foreground">{t(`category.${cat.toLowerCase()}`)}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12">
        <div className="container">
          <h3 className="text-2xl font-bold mb-6">{t('home.hot_deals')}</h3>
          {filteredProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">{t('browse.no_products')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product) => {
                const bestPrice = getBestPrice(product.prices);
                const allPrices = product.prices;
                const cheapest = Math.min(...allPrices.map((p) => p.price));
                const savings = Math.round(((Math.max(...allPrices.map((p) => p.price)) - cheapest) / Math.max(...allPrices.map((p) => p.price))) * 100);

                return (
                  <Card
                    key={product.id}
                    className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2 border-primary/20 cursor-pointer"
                    onClick={() => navigate(`/product/${product.id}`)}
                  >
                    {/* Card Header */}
                    <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-4 border-b-2 border-primary/20">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-bold text-foreground text-lg">{product.name}</h3>
                          <p className="text-sm text-muted-foreground">{product.category}</p>
                        </div>
                        {bestPrice.special && (
                          <Badge className="bg-accent text-white animate-pulse">
                            {bestPrice.discount}% OFF
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Best Price Highlight */}
                    <div className="p-4 bg-secondary/5 border-b-2 border-secondary/20">
                      <p className="text-xs text-muted-foreground mb-1">{t('product.best_price')}</p>
                      <div className="flex items-baseline gap-2">
                        <span className="text-3xl font-bold text-secondary">R{bestPrice.price.toFixed(2)}</span>
                        <span className="text-sm text-muted-foreground">{bestPrice.store}</span>
                      </div>
                      {savings > 0 && (
                        <p className="text-xs text-accent font-semibold mt-2">
                          {t('product.save_up_to')} R{(Math.max(...allPrices.map((p) => p.price)) - cheapest).toFixed(2)}
                        </p>
                      )}
                    </div>

                    {/* Price Comparison */}
                    <div className="p-4 space-y-3">
                      <p className="text-xs font-semibold text-foreground/70 uppercase">{t('product.prices_at_all_stores')}</p>
                      {allPrices.map((priceInfo) => (
                        <div
                          key={priceInfo.store}
                          className={`flex items-center justify-between p-2 rounded-lg transition-all ${
                            priceInfo.store === bestPrice.store
                              ? 'bg-secondary/10 border-2 border-secondary'
                              : 'bg-muted/50 border border-border'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm font-medium text-foreground">{priceInfo.store}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-foreground">R{priceInfo.price.toFixed(2)}</span>
                            {priceInfo.special && (
                              <Badge variant="secondary" className="text-xs bg-accent/20 text-accent border-0">
                                Special
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* CTA */}
                    <div className="p-4 border-t-2 border-primary/20">
                      <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold">
                        {t('home.view_deal')}
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
