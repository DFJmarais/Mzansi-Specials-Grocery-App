import { useState, useMemo } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bell, Trash2, Check, Filter } from 'lucide-react';
import { getLoginUrl } from '@/const';

interface Notification {
  id: number;
  type: 'price_drop' | 'list_shared' | 'deal_alert' | 'system';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: Date;
  actionUrl?: string;
  relatedData?: Record<string, any>;
}

export default function NotificationCenter() {
  const { user, isAuthenticated, loading } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      type: 'price_drop',
      title: 'Price Drop: Milk (1L)',
      message: 'Milk (1L) at Checkers dropped from R18.99 to R16.99 - Save R2.00!',
      isRead: false,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      relatedData: {
        oldPrice: 1899,
        newPrice: 1699,
        storeName: 'Checkers',
        percentageDrop: 11,
        amountSaved: 200,
      },
    },
    {
      id: 2,
      type: 'price_drop',
      title: 'Price Drop: Chicken Breast (1kg)',
      message: 'Chicken Breast (1kg) at SPAR dropped from R61.99 to R54.99 - Save R7.00!',
      isRead: false,
      createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      relatedData: {
        oldPrice: 6199,
        newPrice: 5499,
        storeName: 'SPAR',
        percentageDrop: 11,
        amountSaved: 700,
      },
    },
    {
      id: 3,
      type: 'deal_alert',
      title: 'Hot Deal: Bread 50% Off',
      message: 'Bread is on special at Pick n Pay - 50% off this week only!',
      isRead: true,
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    },
    {
      id: 4,
      type: 'list_shared',
      title: 'Shopping List Shared',
      message: 'Sarah shared "Weekly Groceries" list with you',
      isRead: true,
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    },
  ]);

  const [filterType, setFilterType] = useState<'all' | Notification['type']>('all');
  const [showUnreadOnly, setShowUnreadOnly] = useState(false);

  const filteredNotifications = useMemo(() => {
    return notifications.filter(notif => {
      if (filterType !== 'all' && notif.type !== filterType) return false;
      if (showUnreadOnly && notif.isRead) return false;
      return true;
    });
  }, [notifications, filterType, showUnreadOnly]);

  const unreadCount = useMemo(() => {
    return notifications.filter(n => !n.isRead).length;
  }, [notifications]);

  const markAsRead = (id: number) => {
    setNotifications(notifications.map(n =>
      n.id === id ? { ...n, isRead: true } : n
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, isRead: true })));
  };

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const getTypeColor = (type: Notification['type']) => {
    switch (type) {
      case 'price_drop':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'deal_alert':
        return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'list_shared':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'system':
        return 'bg-gray-100 text-gray-800 border-gray-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getTypeIcon = (type: Notification['type']) => {
    switch (type) {
      case 'price_drop':
        return '📉';
      case 'deal_alert':
        return '🔥';
      case 'list_shared':
        return '👥';
      case 'system':
        return 'ℹ️';
      default:
        return '🔔';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin">
          <Bell className="w-8 h-8 text-primary" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="container py-12">
        <Card className="p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Sign in to View Notifications</h2>
          <p className="text-muted-foreground mb-6">
            Get alerts for price drops, deals, and shopping list updates
          </p>
          <Button onClick={() => window.location.href = getLoginUrl()}>
            Sign In to Continue
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="container py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-primary flex items-center gap-2">
              <Bell className="w-8 h-8" />
              Notifications
            </h1>
            <p className="text-muted-foreground">
              {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}
            </p>
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              Mark All as Read
            </Button>
          )}
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={filterType === 'all' ? 'default' : 'outline'}
            onClick={() => setFilterType('all')}
            size="sm"
          >
            All
          </Button>
          <Button
            variant={filterType === 'price_drop' ? 'default' : 'outline'}
            onClick={() => setFilterType('price_drop')}
            size="sm"
          >
            📉 Price Drops
          </Button>
          <Button
            variant={filterType === 'deal_alert' ? 'default' : 'outline'}
            onClick={() => setFilterType('deal_alert')}
            size="sm"
          >
            🔥 Deals
          </Button>
          <Button
            variant={filterType === 'list_shared' ? 'default' : 'outline'}
            onClick={() => setFilterType('list_shared')}
            size="sm"
          >
            👥 Shared
          </Button>
          <Button
            variant={showUnreadOnly ? 'default' : 'outline'}
            onClick={() => setShowUnreadOnly(!showUnreadOnly)}
            size="sm"
            className="ml-auto"
          >
            <Filter className="w-4 h-4 mr-2" />
            Unread Only
          </Button>
        </div>
      </div>

      {/* Notifications List */}
      {filteredNotifications.length === 0 ? (
        <Card className="p-12 text-center">
          <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
          <h3 className="text-lg font-semibold mb-2">No notifications</h3>
          <p className="text-muted-foreground">
            {showUnreadOnly
              ? 'You have no unread notifications'
              : 'You will see notifications here when prices drop or deals are available'}
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredNotifications.map(notification => (
            <Card
              key={notification.id}
              className={`p-4 cursor-pointer transition-all hover:shadow-md ${
                !notification.isRead ? 'bg-blue-50 border-blue-200' : ''
              }`}
              onClick={() => !notification.isRead && markAsRead(notification.id)}
            >
              <div className="flex items-start gap-4">
                {/* Type Icon */}
                <div className="text-2xl mt-1">
                  {getTypeIcon(notification.type)}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="font-semibold text-foreground">
                      {notification.title}
                    </h3>
                    <Badge className={getTypeColor(notification.type)}>
                      {notification.type === 'price_drop' && 'Price Drop'}
                      {notification.type === 'deal_alert' && 'Deal Alert'}
                      {notification.type === 'list_shared' && 'Shared'}
                      {notification.type === 'system' && 'System'}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">
                    {notification.message}
                  </p>

                  {/* Related Data */}
                  {notification.relatedData && (
                    <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded mb-2">
                      {notification.relatedData.percentageDrop && (
                        <p>
                          💰 Save R{(notification.relatedData.amountSaved / 100).toFixed(2)} ({notification.relatedData.percentageDrop}% off)
                        </p>
                      )}
                    </div>
                  )}

                  {/* Timestamp */}
                  <p className="text-xs text-muted-foreground">
                    {formatTime(notification.createdAt)}
                  </p>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  {!notification.isRead && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        markAsRead(notification.id);
                      }}
                      title="Mark as read"
                    >
                      <Check className="w-4 h-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteNotification(notification.id);
                    }}
                    className="text-destructive hover:text-destructive"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function formatTime(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;

  return date.toLocaleDateString();
}
