import { useState } from 'react';
import { Trophy, TrendingUp, Medal } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/_core/hooks/useAuth';

/**
 * Leaderboard Page
 * Display top contributors and rankings
 */

interface LeaderboardUser {
  rank: number;
  userId: string;
  userName: string;
  tier: 'Rookie' | 'Chief' | 'Captain' | 'President';
  stars: number;
  contributions: number;
  accuracy: number;
  avatar?: string;
}

export default function Leaderboard() {
  const { user } = useAuth();
  const [timeframe, setTimeframe] = useState<'all-time' | 'monthly' | 'weekly'>('all-time');

  const [leaderboardData] = useState<LeaderboardUser[]>([
    {
      rank: 1,
      userId: 'user1',
      userName: 'Thabo M.',
      tier: 'President',
      stars: 287,
      contributions: 156,
      accuracy: 98,
      avatar: '👨',
    },
    {
      rank: 2,
      userId: 'user2',
      userName: 'Nomsa K.',
      tier: 'Captain',
      stars: 198,
      contributions: 112,
      accuracy: 96,
      avatar: '👩',
    },
    {
      rank: 3,
      userId: 'user3',
      userName: 'Sipho L.',
      tier: 'Captain',
      stars: 167,
      contributions: 89,
      accuracy: 94,
      avatar: '👨',
    },
    {
      rank: 4,
      userId: 'user4',
      userName: 'Zandile N.',
      tier: 'Chief',
      stars: 134,
      contributions: 67,
      accuracy: 92,
      avatar: '👩',
    },
    {
      rank: 5,
      userId: 'user5',
      userName: 'Mandla T.',
      tier: 'Chief',
      stars: 98,
      contributions: 54,
      accuracy: 89,
      avatar: '👨',
    },
    {
      rank: 6,
      userId: 'user6',
      userName: 'Lerato S.',
      tier: 'Chief',
      stars: 87,
      contributions: 48,
      accuracy: 91,
      avatar: '👩',
    },
    {
      rank: 7,
      userId: 'user7',
      userName: 'Kabelo M.',
      tier: 'Rookie',
      stars: 45,
      contributions: 23,
      accuracy: 88,
      avatar: '👨',
    },
    {
      rank: 8,
      userId: 'user8',
      userName: 'Amara D.',
      tier: 'Rookie',
      stars: 34,
      contributions: 18,
      accuracy: 85,
      avatar: '👩',
    },
  ]);

  const tierIcons: Record<string, string> = {
    Rookie: '🌱',
    Chief: '🔥',
    Captain: '⚡',
    President: '👑',
  };

  const getMedalIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return '🥇';
      case 2:
        return '🥈';
      case 3:
        return '🥉';
      default:
        return `#${rank}`;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-border p-4">
        <h1 className="text-2xl font-bold text-foreground mb-2">Leaderboard</h1>
        <p className="text-sm text-muted-foreground">Top grocery price contributors</p>
      </div>

      {/* Timeframe Tabs */}
      <div className="bg-white border-b border-border p-4">
        <div className="flex gap-2">
          {(['all-time', 'monthly', 'weekly'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1 rounded-full text-sm font-semibold capitalize transition-all ${
                timeframe === tf
                  ? 'bg-primary text-white'
                  : 'bg-muted text-foreground hover:bg-muted/80'
              }`}
            >
              {tf === 'all-time' ? 'All Time' : tf === 'monthly' ? 'This Month' : 'This Week'}
            </button>
          ))}
        </div>
      </div>

      {/* Top 3 Podium */}
      <div className="p-4 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="grid grid-cols-3 gap-2 mb-4">
          {leaderboardData.slice(0, 3).map((user, index) => (
            <div key={user.userId} className="text-center">
              <div
                className={`relative mb-2 ${
                  index === 0 ? 'order-2' : index === 1 ? 'order-1' : 'order-3'
                }`}
              >
                {/* Podium */}
                <div
                  className={`rounded-t-lg p-3 text-center ${
                    index === 0
                      ? 'bg-yellow-100 h-32'
                      : index === 1
                      ? 'bg-gray-100 h-28'
                      : 'bg-orange-100 h-24'
                  }`}
                >
                  <p className="text-3xl mb-1">{user.avatar}</p>
                  <p className="text-lg font-bold text-foreground">{getMedalIcon(user.rank)}</p>
                  <p className="text-xs font-bold text-foreground mt-1">{user.userName}</p>
                  <p className="text-xs text-muted-foreground">{user.stars} ⭐</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Leaderboard List */}
      <div className="p-4 space-y-2">
        {leaderboardData.map((user) => (
          <Card
            key={user.userId}
            className={`p-3 border-2 transition-all ${
              user.userId === user.userId
                ? 'border-primary bg-primary/5'
                : 'border-border hover:border-primary/30'
            }`}
          >
            <div className="flex items-center gap-3">
              {/* Rank */}
              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-sm flex-shrink-0">
                {user.rank <= 3 ? getMedalIcon(user.rank) : `#${user.rank}`}
              </div>

              {/* User Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{user.avatar}</span>
                  <div>
                    <p className="font-bold text-foreground text-sm">{user.userName}</p>
                    <div className="flex items-center gap-1">
                      <span className="text-xs">{tierIcons[user.tier]}</span>
                      <p className="text-xs text-muted-foreground">{user.tier}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="text-right flex-shrink-0">
                <p className="font-bold text-primary text-lg">{user.stars} ⭐</p>
                <div className="flex items-center gap-1 justify-end mt-1">
                  <TrendingUp className="w-3 h-3 text-secondary" />
                  <p className="text-xs text-muted-foreground">{user.contributions}</p>
                </div>
                <p className="text-xs text-muted-foreground">{user.accuracy}% accuracy</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Info Section */}
      <div className="p-4 bg-muted/30 border-t border-border mt-4">
        <div className="flex gap-2">
          <Trophy className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-foreground text-sm mb-1">How Rankings Work</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Ranked by total stars earned</li>
              <li>• Bonus for high accuracy rates</li>
              <li>• Tiebreaker: most recent contributions</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
