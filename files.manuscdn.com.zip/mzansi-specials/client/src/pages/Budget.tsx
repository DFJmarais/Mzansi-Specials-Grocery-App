import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';
import { AlertCircle, TrendingUp, DollarSign, Trash2 } from 'lucide-react';
import { getProductsWithKeywords } from '@/data/products-complete';

export default function Budget() {
  const { user, isAuthenticated } = useAuth();
  const products = getProductsWithKeywords();

  const [budget, setBudget] = useState<number | null>(null);
  const [budgetInput, setBudgetInput] = useState('');
  const [cartItems, setCartItems] = useState<Array<{ productId: number; quantity: number; price: number }>>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedQuantity, setSelectedQuantity] = useState(1);

  // Filter products based on search
  const filteredProducts = useMemo(() => {
    if (!searchQuery) return [];
    const query = searchQuery.toLowerCase();
    return products.filter(p =>
      p.name.toLowerCase().includes(query) ||
      (p.searchKeywords || []).some((kw: string) => kw.toLowerCase().includes(query))
    ).slice(0, 10);
  }, [searchQuery, products]);

  // Calculate total spending
  const totalSpending = useMemo(() => {
    return cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }, [cartItems]);

  // Calculate remaining budget
  const remainingBudget = budget ? budget - totalSpending : null;
  const budgetPercentage = budget ? (totalSpending / budget) * 100 : 0;
  const isOverBudget = remainingBudget !== null && remainingBudget < 0;

  const handleSetBudget = () => {
    const amount = parseFloat(budgetInput);
    if (amount > 0) {
      setBudget(amount);
      setBudgetInput('');
    }
  };

  const handleAddToCart = (productId: number, price: number) => {
    const existingItem = cartItems.find(item => item.productId === productId);
    if (existingItem) {
      setCartItems(cartItems.map(item =>
        item.productId === productId
          ? { ...item, quantity: item.quantity + selectedQuantity }
          : item
      ));
    } else {
      setCartItems([...cartItems, { productId, quantity: selectedQuantity, price }]);
    }
    setSearchQuery('');
    setSelectedQuantity(1);
  };

  const handleRemoveItem = (productId: number) => {
    setCartItems(cartItems.filter(item => item.productId !== productId));
  };

  const handleUpdateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
    } else {
      setCartItems(cartItems.map(item =>
        item.productId === productId ? { ...item, quantity } : item
      ));
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 text-center max-w-md">
          <h2 className="text-2xl font-bold mb-4">Sign In Required</h2>
          <p className="text-muted-foreground mb-6">Please sign in to use the Budget Tracker</p>
          <Button onClick={() => window.location.href = getLoginUrl()} className="w-full">
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <h1 className="text-4xl font-bold text-primary mb-2">Shopping Budget Tracker</h1>
        <p className="text-muted-foreground mb-8">Plan your shopping and stay within budget</p>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Budget Setup */}
          <Card className="p-6 md:col-span-1">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-primary" />
              Set Budget
            </h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold mb-2 block">Budget Amount (R)</label>
                <Input
                  type="number"
                  placeholder="e.g., 1000"
                  value={budgetInput}
                  onChange={(e) => setBudgetInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSetBudget()}
                />
              </div>
              <Button onClick={handleSetBudget} className="w-full">
                Set Budget
              </Button>

              {budget && (
                <div className="mt-6 p-4 bg-secondary/10 rounded-lg border border-secondary">
                  <p className="text-sm text-muted-foreground mb-2">Total Budget</p>
                  <p className="text-2xl font-bold text-secondary">R{budget.toFixed(2)}</p>
                </div>
              )}
            </div>
          </Card>

          {/* Budget Progress */}
          {budget && (
            <Card className="p-6 md:col-span-1">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Progress
              </h2>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-semibold">Spending</span>
                    <span className={`text-sm font-bold ${isOverBudget ? 'text-red-600' : 'text-green-600'}`}>
                      R{totalSpending.toFixed(2)}
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        isOverBudget ? 'bg-red-500' : budgetPercentage > 75 ? 'bg-orange-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${Math.min(budgetPercentage, 100)}%` }}
                    />
                  </div>
                </div>

                <div className="p-3 bg-background rounded-lg border">
                  <p className="text-xs text-muted-foreground mb-1">Remaining</p>
                  <p className={`text-lg font-bold ${remainingBudget! < 0 ? 'text-red-600' : 'text-green-600'}`}>
                    R{remainingBudget?.toFixed(2) || '0.00'}
                  </p>
                </div>

                {isOverBudget && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex gap-2">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                    <p className="text-sm text-red-600 font-semibold">Over budget by R{Math.abs(remainingBudget!).toFixed(2)}</p>
                  </div>
                )}
              </div>
            </Card>
          )}

          {/* Search & Add Products */}
          <Card className="p-6 md:col-span-1">
            <h2 className="text-xl font-bold mb-4">Add Products</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold mb-2 block">Search Product</label>
                <Input
                  type="text"
                  placeholder="Search milk, bread, eggs..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {filteredProducts.length > 0 && (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {filteredProducts.map(product => {
                    const bestPrice = product.prices.reduce((min, p) => p.price < min.price ? p : min);
                    return (
                      <div key={product.id} className="p-2 bg-muted rounded-lg">
                        <p className="text-sm font-semibold">{product.name}</p>
                        <p className="text-xs text-muted-foreground mb-2">R{bestPrice.price.toFixed(2)}</p>
                        <div className="flex gap-2">
                          <Input
                            type="number"
                            min="1"
                            value={selectedQuantity}
                            onChange={(e) => setSelectedQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                            className="w-16 h-8"
                          />
                          <Button
                            size="sm"
                            onClick={() => handleAddToCart(product.id, bestPrice.price)}
                            className="flex-1"
                          >
                            Add
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Cart Items */}
        {cartItems.length > 0 && (
          <Card className="p-6 mt-6">
            <h2 className="text-2xl font-bold mb-4">Shopping Cart</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 font-semibold">Product</th>
                    <th className="text-center py-2 font-semibold">Quantity</th>
                    <th className="text-right py-2 font-semibold">Price</th>
                    <th className="text-right py-2 font-semibold">Total</th>
                    <th className="text-center py-2 font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {cartItems.map(item => {
                    const product = products.find(p => p.id === item.productId);
                    return (
                      <tr key={item.productId} className="border-b hover:bg-muted/50">
                        <td className="py-3">{product?.name}</td>
                        <td className="text-center py-3">
                          <Input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleUpdateQuantity(item.productId, parseInt(e.target.value) || 1)}
                            className="w-16 mx-auto"
                          />
                        </td>
                        <td className="text-right py-3">R{item.price.toFixed(2)}</td>
                        <td className="text-right py-3 font-semibold">R{(item.price * item.quantity).toFixed(2)}</td>
                        <td className="text-center py-3">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveItem(item.productId)}
                          >
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="mt-6 p-4 bg-secondary/10 rounded-lg border border-secondary">
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold">Total Spending:</span>
                <span className={`text-2xl font-bold ${isOverBudget ? 'text-red-600' : 'text-green-600'}`}>
                  R{totalSpending.toFixed(2)}
                </span>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
