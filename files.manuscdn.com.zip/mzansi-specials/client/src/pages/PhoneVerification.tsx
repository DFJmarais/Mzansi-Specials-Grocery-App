import { useState } from 'react';
import { Phone, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';

export default function PhoneVerification() {
  const [step, setStep] = useState<'phone' | 'otp' | 'verified'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes

  const handleSendOTP = async () => {
    if (!phoneNumber.trim()) {
      toast.error('Please enter your phone number');
      return;
    }

    setLoading(true);
    try {
      // In production: Call API to send OTP
      // const response = await fetch('/api/sms/send-otp', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ phoneNumber })
      // });

      console.log(`[Phone Verification] Sending OTP to ${phoneNumber}`);
      toast.success('OTP sent to your phone!');
      setStep('otp');

      // Start countdown
      const interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (error) {
      toast.error('Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!otp.trim() || otp.length !== 6) {
      toast.error('Please enter a valid 6-digit code');
      return;
    }

    setLoading(true);
    try {
      // In production: Call API to verify OTP
      // const response = await fetch('/api/sms/verify-otp', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ phoneNumber, otp })
      // });

      console.log(`[Phone Verification] Verifying OTP: ${otp}`);
      toast.success('Phone verified successfully!');
      setStep('verified');
    } catch (error) {
      toast.error('Invalid OTP code');
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary via-secondary to-accent text-white p-6 rounded-b-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-black">📱 Phone Verification</h1>
            <p className="text-sm opacity-90">Enable WhatsApp price alerts</p>
          </div>
          <Phone className="w-10 h-10 opacity-50" />
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {step === 'phone' && (
          <Card className="p-6 border-border space-y-4">
            <h2 className="text-xl font-bold text-foreground">Enter Your Phone Number</h2>
            <p className="text-sm text-muted-foreground">
              We'll send you an OTP code to verify your phone number. You'll receive price alerts and deals via WhatsApp.
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Phone Number</label>
                <input
                  type="tel"
                  placeholder="+27 60 422 0217"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-border rounded-lg focus:outline-none focus:border-primary text-base"
                />
                <p className="text-xs text-muted-foreground mt-2">Format: +27 or 0 followed by your number</p>
              </div>

              <Button
                onClick={handleSendOTP}
                disabled={loading}
                className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg"
              >
                {loading ? 'Sending...' : 'Send OTP Code'}
              </Button>
            </div>

            <Card className="p-4 bg-secondary/10 border-secondary">
              <p className="text-sm text-foreground">
                ✓ We'll send a 6-digit code to your phone
                <br />✓ Code expires in 10 minutes
                <br />✓ You can try up to 3 times
              </p>
            </Card>
          </Card>
        )}

        {step === 'otp' && (
          <Card className="p-6 border-border space-y-4">
            <h2 className="text-xl font-bold text-foreground">Enter OTP Code</h2>
            <p className="text-sm text-muted-foreground">
              We sent a 6-digit code to {phoneNumber}
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">OTP Code</label>
                <input
                  type="text"
                  placeholder="000000"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  maxLength={6}
                  className="w-full px-4 py-3 border-2 border-border rounded-lg focus:outline-none focus:border-primary text-2xl font-bold text-center tracking-widest"
                />
              </div>

              <div className="flex items-center justify-between">
                <p className={`text-sm font-semibold ${timeLeft < 60 ? 'text-red-500' : 'text-muted-foreground'}`}>
                  Time remaining: {formatTime(timeLeft)}
                </p>
                {timeLeft === 0 && (
                  <Button
                    onClick={() => {
                      setStep('phone');
                      setOtp('');
                      setTimeLeft(600);
                    }}
                    variant="outline"
                    size="sm"
                  >
                    Resend Code
                  </Button>
                )}
              </div>

              <Button
                onClick={handleVerifyOTP}
                disabled={loading || otp.length !== 6}
                className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg"
              >
                {loading ? 'Verifying...' : 'Verify Code'}
              </Button>

              <Button
                onClick={() => {
                  setStep('phone');
                  setOtp('');
                }}
                variant="outline"
                className="w-full border-border text-foreground py-3 rounded-lg"
              >
                Back
              </Button>
            </div>

            <Card className="p-4 bg-warning/10 border-warning">
              <div className="flex gap-2">
                <AlertCircle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
                <p className="text-sm text-foreground">
                  Don't share this code with anyone. We'll never ask for it.
                </p>
              </div>
            </Card>
          </Card>
        )}

        {step === 'verified' && (
          <Card className="p-6 border-border space-y-4 text-center">
            <div className="flex justify-center mb-4">
              <CheckCircle className="w-16 h-16 text-green-500" />
            </div>

            <h2 className="text-2xl font-black text-foreground">Phone Verified! ✓</h2>
            <p className="text-muted-foreground">
              Your phone number has been verified successfully. You'll now receive price alerts and exclusive deals via WhatsApp.
            </p>

            <div className="space-y-2 bg-green-50 p-4 rounded-lg">
              <p className="text-sm font-semibold text-foreground">✓ WhatsApp alerts enabled</p>
              <p className="text-sm font-semibold text-foreground">✓ Price drop notifications active</p>
              <p className="text-sm font-semibold text-foreground">✓ Weekly deals digest ready</p>
            </div>

            <Button
              onClick={() => {
                // Navigate to home or profile
                window.location.href = '/';
              }}
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg"
            >
              Start Shopping
            </Button>
          </Card>
        )}
      </div>

      {/* Info Section */}
      <div className="p-4">
        <Card className="p-4 border-border bg-accent/10">
          <h3 className="font-bold text-foreground mb-2">💡 Why Verify Your Phone?</h3>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>✓ Get instant price drop alerts</li>
            <li>✓ Receive exclusive WhatsApp deals</li>
            <li>✓ Weekly grocery savings digest</li>
            <li>✓ Early access to new specials</li>
            <li>✓ Personalized recommendations</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
