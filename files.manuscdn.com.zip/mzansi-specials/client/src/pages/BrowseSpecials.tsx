import { useState, useMemo, useCallback } from 'react';
import { Search, Filter, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PRODUCTS_1500 } from '@/data/products-1500';

/**
 * Browse Specials - 1,500 Products with Pagination & Filtering
 * Comprehensive product catalog with efficient pagination and search
 */

const RETAILERS = ['All', 'Spar', 'Pick n Pay', 'Checkers', 'Woolworths', 'OK Foods', 'Food Lovers'];
const CATEGORIES = ['All', 'Dairy', 'Meat', 'Produce', 'Bakery', 'Pantry', 'Beverages', 'Frozen', 'Snacks', 'Household'];
const PRODUCTS_PER_PAGE = 50;

export default function BrowseSpecials() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRetailer, setSelectedRetailer] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('name');
  const [showOutOfStock, setShowOutOfStock] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  // Filter and search products
  const filteredProducts = useMemo(() => {
    let filtered = PRODUCTS_1500;

    // Filter by category
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }

    // Filter by retailer
    if (selectedRetailer !== 'All') {
      filtered = filtered.filter(p => {
        const retailerData = p.prices.find(r => r.store === selectedRetailer);
        return retailerData && (showOutOfStock || retailerData.inStock);
      });
    } else if (!showOutOfStock) {
      filtered = filtered.filter(p => p.prices.some(r => r.inStock));
    }

    // Filter by search
    if (searchQuery) {
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.subcategory.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort
    if (sortBy === 'price-low') {
      filtered.sort((a, b) => {
        const aPrice = Math.min(...a.prices.map(r => r.price));
        const bPrice = Math.min(...b.prices.map(r => r.price));
        return aPrice - bPrice;
      });
    } else if (sortBy === 'price-high') {
      filtered.sort((a, b) => {
        const aPrice = Math.max(...a.prices.map(r => r.price));
        const bPrice = Math.max(...b.prices.map(r => r.price));
        return bPrice - aPrice;
      });
    } else {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    }

    return filtered;
  }, [searchQuery, selectedRetailer, selectedCategory, sortBy, showOutOfStock]);

  // Pagination
  const totalPages = Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE);
  const paginatedProducts = useMemo(() => {
    const startIdx = (currentPage - 1) * PRODUCTS_PER_PAGE;
    return filteredProducts.slice(startIdx, startIdx + PRODUCTS_PER_PAGE);
  }, [filteredProducts, currentPage]);

  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
    window.scrollTo(0, 0);
  }, [totalPages]);

  const getBestPrice = (prices: typeof PRODUCTS_1500[0]['prices']) => {
    if (selectedRetailer === 'All') {
      return prices.reduce((min, p) => (p.price < min.price ? p : min));
    }
    return prices.find((p) => p.store === selectedRetailer) || prices[0];
  };

  const getInStockCount = (prices: typeof PRODUCTS_1500[0]['prices']) => {
    return prices.filter(p => p.inStock).length;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b-2 border-primary/20">
        <div className="container py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">M</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-primary">Browse Specials</h1>
                <p className="text-xs text-muted-foreground">{filteredProducts.length} products found</p>
              </div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-10 h-11 border-2 border-primary/30 focus:border-primary"
              />
            </div>
          </div>

          {/* Filters */}
          <div className="space-y-3">
            {/* Category Filter */}
            <div>
              <p className="text-sm font-semibold text-foreground mb-2">Category</p>
              <div className="flex flex-wrap gap-2">
                {CATEGORIES.map((cat) => (
                  <Badge
                    key={cat}
                    variant={selectedCategory === cat ? 'default' : 'outline'}
                    className={`cursor-pointer transition-all ${
                      selectedCategory === cat
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-white text-foreground border-primary/30 hover:border-primary'
                    }`}
                    onClick={() => {
                      setSelectedCategory(cat);
                      setCurrentPage(1);
                    }}
                  >
                    {cat}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Retailer Filter */}
            <div>
              <p className="text-sm font-semibold text-foreground mb-2">Retailer</p>
              <div className="flex flex-wrap gap-2">
                {RETAILERS.map((store) => (
                  <Badge
                    key={store}
                    variant={selectedRetailer === store ? 'default' : 'outline'}
                    className={`cursor-pointer transition-all ${
                      selectedRetailer === store
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-white text-foreground border-primary/30 hover:border-primary'
                    }`}
                    onClick={() => {
                      setSelectedRetailer(store);
                      setCurrentPage(1);
                    }}
                  >
                    {store}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Sort & Options */}
            <div className="flex gap-4 items-center">
              <div className="flex items-center gap-2">
                <label className="text-sm font-semibold">Sort:</label>
                <select
                  value={sortBy}
                  onChange={(e) => {
                    setSortBy(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="px-3 py-1 border border-primary/30 rounded text-sm"
                >
                  <option value="name">Name (A-Z)</option>
                  <option value="price-low">Price (Low to High)</option>
                  <option value="price-high">Price (High to Low)</option>
                </select>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showOutOfStock}
                  onChange={(e) => {
                    setShowOutOfStock(e.target.checked);
                    setCurrentPage(1);
                  }}
                  className="w-4 h-4"
                />
                <span className="text-sm">Show Out of Stock</span>
              </label>
            </div>
          </div>
        </div>
      </header>

      {/* Products Grid */}
      <section className="py-12">
        <div className="container">
          {paginatedProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">No products found. Try a different search.</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {paginatedProducts.map((product) => {
                  const bestPrice = getBestPrice(product.prices);
                  const inStockCount = getInStockCount(product.prices);
                  const allPrices = product.prices;
                  const cheapest = Math.min(...allPrices.map((p) => p.price));
                  const savings = Math.round(
                    ((Math.max(...allPrices.map((p) => p.price)) - cheapest) /
                      Math.max(...allPrices.map((p) => p.price))) *
                      100
                  );

                  return (
                  <Card
                    key={product.id}
                    className="overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-2 border-primary/20 cursor-pointer"
                    onClick={() => window.location.href = `/product/${product.id}`}
                  >
                    {/* Product Image */}
                    {product.image && (
                      <div className="w-full h-48 bg-gradient-to-br from-primary/5 to-accent/5 flex items-center justify-center overflow-hidden">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover hover:scale-105 transition-transform"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                      </div>
                    )}
                    {/* Card Header */}
                    <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-4 border-b-2 border-primary/20">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-bold text-foreground text-sm">{product.name}</h3>
                            <p className="text-xs text-muted-foreground">{product.subcategory}</p>
                          </div>
                          <Badge className="bg-secondary text-white text-xs">
                            {inStockCount}/6
                          </Badge>
                        </div>
                      </div>

                      {/* Best Price Highlight */}
                      <div className="p-4 bg-secondary/5 border-b-2 border-secondary/20">
                        <p className="text-xs text-muted-foreground mb-1">Best Price</p>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-secondary">R{bestPrice.price.toFixed(2)}</span>
                          <span className="text-xs text-muted-foreground">{bestPrice.store}</span>
                        </div>
                        {savings > 0 && (
                          <p className="text-xs text-accent font-semibold mt-1">
                            Save up to R{(Math.max(...allPrices.map((p) => p.price)) - cheapest).toFixed(2)}
                          </p>
                        )}
                      </div>

                      {/* Last Updated */}
                      <div className="px-4 py-2 bg-muted/30 text-xs text-muted-foreground border-b">
                        Updated {product.lastUpdated}
                      </div>

                      {/* Price Comparison */}
                      <div className="p-4 space-y-2">
                        {allPrices.slice(0, 3).map((priceInfo) => (
                          <div
                            key={priceInfo.store}
                            className={`flex items-center justify-between p-2 rounded text-xs ${
                              priceInfo.store === bestPrice.store
                                ? 'bg-secondary/10 border border-secondary'
                                : 'bg-muted/50'
                            }`}
                          >
                            <span className="font-medium">{priceInfo.store}</span>
                            <div className="flex items-center gap-2">
                              <span>R{priceInfo.price.toFixed(2)}</span>
                              {!priceInfo.inStock && <Badge variant="destructive" className="text-xs">OOS</Badge>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </Card>
                  );
                })}
              </div>

              {/* Pagination */}
              <div className="flex items-center justify-center gap-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <div className="flex items-center gap-2">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    const pageNum = currentPage <= 3 ? i + 1 : currentPage - 2 + i;
                    return pageNum <= totalPages ? (
                      <Button
                        key={pageNum}
                        variant={currentPage === pageNum ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => handlePageChange(pageNum)}
                      >
                        {pageNum}
                      </Button>
                    ) : null;
                  })}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
                <span className="text-sm text-muted-foreground ml-4">
                  Page {currentPage} of {totalPages} ({filteredProducts.length} total)
                </span>
              </div>
            </>
          )}
        </div>
      </section>
    </div>
  );
}
