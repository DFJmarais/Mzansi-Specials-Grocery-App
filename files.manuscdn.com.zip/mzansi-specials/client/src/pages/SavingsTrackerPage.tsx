import { useState } from 'react';
import { TrendingUp, Award, Target, Zap } from 'lucide-react';

interface SavingsData {
  weekly: number;
  monthly: number;
  yearly: number;
  totalTransactions: number;
}

// Mock data - will be replaced with tRPC queries
const SAVINGS_DATA: SavingsData = {
  weekly: 245.50,
  monthly: 980.00,
  yearly: 12000.00,
  totalTransactions: 47,
};

interface Achievement {
  id: number;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  requirement: number;
  current: number;
}

const ACHIEVEMENTS: Achievement[] = [
  {
    id: 1,
    title: 'First Saver',
    description: 'Save your first R50',
    icon: '🌱',
    unlocked: true,
    requirement: 50,
    current: 245.50,
  },
  {
    id: 2,
    title: 'Savvy Shopper',
    description: 'Save R500 in a month',
    icon: '🛒',
    unlocked: true,
    requirement: 500,
    current: 980,
  },
  {
    id: 3,
    title: 'Budget Master',
    description: 'Save R1000 in a month',
    icon: '💰',
    unlocked: true,
    requirement: 1000,
    current: 980,
  },
  {
    id: 4,
    title: 'Mzansi Legend',
    description: 'Save R10,000 in a year',
    icon: '👑',
    unlocked: true,
    requirement: 10000,
    current: 12000,
  },
  {
    id: 5,
    title: 'Super Saver',
    description: 'Make 100 transactions',
    icon: '⚡',
    unlocked: false,
    requirement: 100,
    current: 47,
  },
  {
    id: 6,
    title: 'Stretch Your Rand',
    description: 'Save R50,000 in a year',
    icon: '🎯',
    unlocked: false,
    requirement: 50000,
    current: 12000,
  },
];

const MILESTONES = [
  { amount: 100, item: 'a loaf of bread' },
  { amount: 250, item: 'a chicken' },
  { amount: 500, item: 'a bag of rice (5kg)' },
  { amount: 1000, item: 'a week of groceries' },
  { amount: 2500, item: 'a month of groceries' },
  { amount: 5000, item: 'a new appliance' },
];

export default function SavingsTrackerPage() {
  const [timeframe, setTimeframe] = useState<'weekly' | 'monthly' | 'yearly'>('monthly');

  const currentSavings = SAVINGS_DATA[timeframe];
  const milestone = MILESTONES.find((m) => m.amount <= currentSavings);
  const nextMilestone = MILESTONES.find((m) => m.amount > currentSavings);

  const getEncouragingMessage = (savings: number) => {
    if (savings < 50) {
      return "🌱 You're just getting started! Keep adding items to your list.";
    } else if (savings < 250) {
      return '💪 Great start! You\'re already saving money like a pro!';
    } else if (savings < 500) {
      return '🎉 Awesome! You\'re stretching that rand like a true Mzansi shopper!';
    } else if (savings < 1000) {
      return '🚀 Incredible! You\'re saving enough for a week of groceries!';
    } else if (savings < 5000) {
      return '👑 You\'re a savings legend! Keep up the amazing work!';
    } else {
      return '🏆 Congratulations! You\'re saving like a true Mzansi champion!';
    }
  };

  const getProgressPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  return (
    <div className="bg-white">
      {/* Page Header */}
      <section className="container py-6 md:py-8">
        <h1 className="section-title flex items-center gap-3">
          <TrendingUp className="w-8 h-8 text-primary" />
          Savings Tracker
        </h1>
        <p className="text-text-secondary">
          Track your savings and celebrate your money-saving wins!
        </p>
      </section>

      {/* Timeframe Selector */}
      <section className="container py-6 border-b-2 border-border">
        <div className="flex gap-2">
          {(['weekly', 'monthly', 'yearly'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-4 py-2 rounded-lg font-semibold transition-all capitalize ${
                timeframe === tf
                  ? 'bg-primary text-white'
                  : 'bg-surface text-text-primary border-2 border-border hover:border-primary'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </section>

      {/* Main Savings Display */}
      <section className="container py-8">
        <div className="bg-gradient-to-br from-primary to-blue rounded-2xl p-8 md:p-12 text-white text-center mb-8">
          <p className="text-lg opacity-90 mb-2 capitalize">Total Savings This {timeframe}</p>
          <h2 className="text-5xl md:text-6xl font-bold mb-4">R{currentSavings.toFixed(2)}</h2>
          <p className="text-lg opacity-95">{getEncouragingMessage(currentSavings)}</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-primary/10 p-6 rounded-xl border-2 border-primary/20 text-center">
            <div className="text-3xl font-bold text-primary mb-2">R{SAVINGS_DATA.weekly.toFixed(2)}</div>
            <div className="text-sm text-text-secondary font-semibold">Weekly Savings</div>
          </div>
          <div className="bg-secondary/10 p-6 rounded-xl border-2 border-secondary/20 text-center">
            <div className="text-3xl font-bold text-secondary mb-2">R{SAVINGS_DATA.monthly.toFixed(2)}</div>
            <div className="text-sm text-text-secondary font-semibold">Monthly Savings</div>
          </div>
          <div className="bg-accent/10 p-6 rounded-xl border-2 border-accent/20 text-center">
            <div className="text-3xl font-bold text-accent mb-2">R{SAVINGS_DATA.yearly.toFixed(2)}</div>
            <div className="text-sm text-text-secondary font-semibold">Yearly Savings</div>
          </div>
        </div>

        {/* Milestone Progress */}
        {nextMilestone && (
          <div className="bg-gradient-to-r from-secondary/10 to-accent/10 border-2 border-secondary/20 rounded-xl p-6 md:p-8 mb-8">
            <h3 className="text-xl font-bold text-text-primary mb-4">🎯 Next Milestone</h3>
            <p className="text-lg text-text-primary font-semibold mb-4">
              Save R{nextMilestone.amount} for {nextMilestone.item}
            </p>
            <div className="w-full bg-border rounded-full h-4 overflow-hidden mb-3">
              <div
                className="bg-gradient-to-r from-primary to-accent h-full transition-all duration-500"
                style={{ width: `${getProgressPercentage(currentSavings, nextMilestone.amount)}%` }}
              />
            </div>
            <div className="flex justify-between text-sm text-text-secondary">
              <span>R{currentSavings.toFixed(2)}</span>
              <span>R{nextMilestone.amount}</span>
            </div>
            <p className="text-sm text-text-secondary mt-3">
              You need R{(nextMilestone.amount - currentSavings).toFixed(2)} more to reach this milestone!
            </p>
          </div>
        )}

        {/* Current Milestone */}
        {milestone && (
          <div className="bg-green-50 border-2 border-green-200 rounded-xl p-6 md:p-8 mb-8">
            <h3 className="text-xl font-bold text-green-700 mb-2">✅ You've Saved Enough For:</h3>
            <p className="text-2xl font-bold text-green-600">{milestone.item}</p>
            <p className="text-sm text-green-600 mt-2">
              That's R{milestone.amount} in savings! 🎉
            </p>
          </div>
        )}
      </section>

      {/* Achievements */}
      <section className="container py-8 border-t-2 border-border">
        <h2 className="section-title flex items-center gap-3">
          <Award className="w-8 h-8 text-accent" />
          Achievements & Badges
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
          {ACHIEVEMENTS.map((achievement) => {
            const progress = getProgressPercentage(achievement.current, achievement.requirement);
            return (
              <div
                key={achievement.id}
                className={`p-4 rounded-xl border-2 text-center transition-all ${
                  achievement.unlocked
                    ? 'bg-yellow-50 border-yellow-300'
                    : 'bg-gray-50 border-border opacity-75'
                }`}
              >
                <div className="text-4xl mb-2">{achievement.icon}</div>
                <h4 className="font-bold text-sm mb-1">{achievement.title}</h4>
                <p className="text-xs text-text-secondary mb-3">{achievement.description}</p>
                {!achievement.unlocked && (
                  <>
                    <div className="w-full bg-border rounded-full h-2 mb-2 overflow-hidden">
                      <div
                        className="bg-primary h-full transition-all"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <p className="text-xs text-text-secondary">
                      {achievement.current}/{achievement.requirement}
                    </p>
                  </>
                )}
                {achievement.unlocked && (
                  <div className="text-xs font-bold text-yellow-600">🏆 Unlocked!</div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Tips Section */}
      <section className="container py-12 mb-20">
        <div className="bg-primary/5 border-2 border-primary/20 rounded-xl p-6 md:p-8">
          <h3 className="text-xl font-bold text-primary mb-4 flex items-center gap-2">
            <Zap className="w-6 h-6" />
            Tips to Save Even More
          </h3>
          <ul className="space-y-3 text-text-secondary">
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">1.</span>
              <span>Compare prices across all 5 retailers every week</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">2.</span>
              <span>Check catalogues for weekly specials before shopping</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">3.</span>
              <span>Buy seasonal produce for better prices</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">4.</span>
              <span>Plan your meals to avoid impulse purchases</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">5.</span>
              <span>Use your shopping list to stay focused</span>
            </li>
          </ul>
        </div>
      </section>

      {/* Motivational Quote */}
      <section className="container py-12 mb-20">
        <div className="bg-gradient-to-r from-accent to-secondary rounded-2xl p-8 md:p-12 text-center text-white">
          <p className="text-2xl md:text-3xl font-bold mb-4">
            "Stretch your rand, for the people, real deals for real Mzansi families!"
          </p>
          <p className="text-lg opacity-90">
            Every rand saved is a rand earned. Keep shopping smart! 💚
          </p>
        </div>
      </section>
    </div>
  );
}
