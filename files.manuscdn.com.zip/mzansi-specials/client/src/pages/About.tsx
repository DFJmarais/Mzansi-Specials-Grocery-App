import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Check, TrendingDown, MapPin, Zap, Shield } from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-accent text-white py-12">
        <div className="container">
          <Button
            variant="ghost"
            onClick={() => (window.location.href = '/')}
            className="text-white hover:bg-white/20 gap-2 mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <div className="space-y-2">
            <h1 className="text-5xl font-bold">Mzansi Specials</h1>
            <p className="text-xl text-white/90">Your one-stop app for grocery specials across South Africa.</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-16 space-y-12">
        {/* Description Section */}
        <section className="max-w-3xl">
          <div className="space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-4">About Mzansi Specials</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Mzansi Specials helps you find the latest grocery deals, discounts, and specials from stores near you — all in one place.
              </p>
            </div>

            <div className="bg-primary/5 border-l-4 border-primary p-6 rounded-lg">
              <p className="text-foreground leading-relaxed">
                We focus on giving you accurate, up-to-date prices so you can save money and make smarter shopping decisions without the hassle.
              </p>
            </div>
          </div>
        </section>

        {/* Key Points Section */}
        <section>
          <h2 className="text-3xl font-bold text-foreground mb-8">Why Choose Mzansi Specials?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Point 1 */}
            <Card className="p-6 hover:shadow-lg transition-all">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <MapPin className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-2">Discover the best specials near you</h3>
                  <p className="text-muted-foreground">Find deals and discounts from retailers closest to your location, tailored to your area.</p>
                </div>
              </div>
            </Card>

            {/* Point 2 */}
            <Card className="p-6 hover:shadow-lg transition-all">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <TrendingDown className="w-8 h-8 text-accent" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-2">Compare prices across stores</h3>
                  <p className="text-muted-foreground">See real-time prices from Spar, Pick n Pay, Checkers, Woolworths, and more in seconds.</p>
                </div>
              </div>
            </Card>

            {/* Point 3 */}
            <Card className="p-6 hover:shadow-lg transition-all">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <Zap className="w-8 h-8 text-yellow-500" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-2">Stay updated with the latest deals</h3>
                  <p className="text-muted-foreground">Get instant notifications when your favorite products go on sale or reach your target price.</p>
                </div>
              </div>
            </Card>

            {/* Point 4 */}
            <Card className="p-6 hover:shadow-lg transition-all">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <Shield className="w-8 h-8 text-green-500" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-foreground mb-2">No clutter, no confusion — just real savings</h3>
                  <p className="text-muted-foreground">Simple, clean interface designed for South African shoppers who want results fast.</p>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Features Section */}
        <section className="bg-gradient-to-r from-primary/5 to-accent/5 p-8 rounded-lg">
          <h2 className="text-3xl font-bold text-foreground mb-8">What You Get</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              '1000+ grocery products tracked daily',
              'Real-time prices from 5+ major retailers',
              'Smart price alerts for your favorites',
              'Price history charts to spot trends',
              'Easy-to-use shopping cart',
              'Multi-language support (11 SA languages)',
              'Wishlist and favorites',
              'Store locator with directions',
            ].map((feature, index) => (
              <div key={index} className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                <p className="text-foreground">{feature}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-gradient-to-r from-primary to-accent text-white rounded-lg p-12 text-center space-y-6">
          <h2 className="text-3xl font-bold">Ready to Start Saving?</h2>
          <p className="text-lg text-white/90 max-w-2xl mx-auto">
            Join thousands of South African shoppers who are already saving money with Mzansi Specials.
          </p>
          <Button
            size="lg"
            onClick={() => (window.location.href = '/')}
            className="bg-white text-primary hover:bg-white/90 font-semibold gap-2"
          >
            Start Shopping Now
          </Button>
        </section>

        {/* Trust Section */}
        <section className="text-center space-y-6">
          <h2 className="text-2xl font-bold text-foreground">Trusted by South Africans</h2>
          <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
            <div>
              <p className="text-3xl font-bold text-primary">1000+</p>
              <p className="text-muted-foreground">Products Tracked</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-primary">5+</p>
              <p className="text-muted-foreground">Major Retailers</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-primary">Daily</p>
              <p className="text-muted-foreground">Price Updates</p>
            </div>
          </div>
        </section>
      </div>

      {/* Footer CTA */}
      <div className="bg-muted py-12 mt-16">
        <div className="container text-center space-y-4">
          <h3 className="text-2xl font-bold text-foreground">Have questions?</h3>
          <p className="text-muted-foreground">Contact us at support@mzansispecials.co.za</p>
        </div>
      </div>
    </div>
  );
}
