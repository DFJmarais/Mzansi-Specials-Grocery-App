import { useState } from 'react';
import { Plus, Trash2, Gift, TrendingUp, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface LoyaltyAccount {
  retailer: string;
  cardNumber: string;
  points: number;
  tier: string;
}

const RETAILERS = [
  { name: 'Checkers', program: 'Checkers Rewards', icon: '🏪', color: 'bg-red-50' },
  { name: 'Pick n Pay', program: 'Smart Shopper', icon: '🛒', color: 'bg-blue-50' },
  { name: 'SPAR', program: 'MoreCard', icon: '🏬', color: 'bg-green-50' },
  { name: 'Woolworths', program: 'Rewards', icon: '🏢', color: 'bg-purple-50' },
  { name: 'OK Foods', program: 'Loyalty', icon: '🛍️', color: 'bg-orange-50' },
];

export default function LoyaltyPrograms() {
  const [accounts, setAccounts] = useState<LoyaltyAccount[]>([]);
  const [selectedRetailer, setSelectedRetailer] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [showForm, setShowForm] = useState(false);

  const linkAccount = () => {
    if (!selectedRetailer || !cardNumber.trim()) {
      toast.error('Please select a retailer and enter card number');
      return;
    }

    const newAccount: LoyaltyAccount = {
      retailer: selectedRetailer,
      cardNumber,
      points: Math.floor(Math.random() * 10000),
      tier: 'Standard',
    };

    setAccounts([...accounts, newAccount]);
    setSelectedRetailer('');
    setCardNumber('');
    setShowForm(false);
    toast.success(`${selectedRetailer} account linked!`);
  };

  const removeAccount = (retailer: string) => {
    setAccounts(accounts.filter((a) => a.retailer !== retailer));
    toast.success(`${retailer} account removed`);
  };

  const totalPoints = accounts.reduce((sum, a) => sum + a.points, 0);

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary via-secondary to-accent text-white p-6 rounded-b-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-black">💳 Loyalty Programs</h1>
            <p className="text-sm opacity-90">Link your retailer loyalty cards</p>
          </div>
          <Gift className="w-10 h-10 opacity-50" />
        </div>
      </div>

      {/* Total Points */}
      {accounts.length > 0 && (
        <div className="p-4">
          <Card className="p-4 border-border bg-gradient-to-r from-primary/10 to-accent/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-semibold">Total Points</p>
                <p className="text-3xl font-black text-primary">{totalPoints.toLocaleString()}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-accent" />
            </div>
          </Card>
        </div>
      )}

      {/* Linked Accounts */}
      {accounts.length > 0 && (
        <div className="p-4 space-y-3">
          <h3 className="font-bold text-foreground">Your Linked Accounts</h3>
          {accounts.map((account) => {
            const retailer = RETAILERS.find((r) => r.name === account.retailer);
            return (
              <Card key={account.retailer} className={`p-4 border-border ${retailer?.color}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{retailer?.icon}</span>
                    <div>
                      <p className="font-bold text-foreground">{account.retailer}</p>
                      <p className="text-xs text-muted-foreground">{retailer?.program}</p>
                      <p className="text-sm font-semibold text-primary mt-1">
                        {account.points.toLocaleString()} points
                      </p>
                    </div>
                  </div>
                  <Button
                    onClick={() => removeAccount(account.retailer)}
                    variant="ghost"
                    size="sm"
                    className="text-red-500 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add Account Form */}
      <div className="p-4">
        {!showForm ? (
          <Button
            onClick={() => setShowForm(true)}
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-2 rounded-lg flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Link Loyalty Account
          </Button>
        ) : (
          <Card className="p-4 border-border space-y-3">
            <h3 className="font-bold text-foreground">Link New Account</h3>

            <select
              value={selectedRetailer}
              onChange={(e) => setSelectedRetailer(e.target.value)}
              className="w-full px-4 py-2 border-2 border-border rounded-lg focus:outline-none focus:border-primary"
            >
              <option value="">Select Retailer</option>
              {RETAILERS.map((r) => (
                <option key={r.name} value={r.name}>
                  {r.icon} {r.name} ({r.program})
                </option>
              ))}
            </select>

            <input
              type="text"
              placeholder="Enter loyalty card number"
              value={cardNumber}
              onChange={(e) => setCardNumber(e.target.value)}
              className="w-full px-4 py-2 border-2 border-border rounded-lg focus:outline-none focus:border-primary"
            />

            <div className="flex gap-2">
              <Button
                onClick={linkAccount}
                className="flex-1 bg-primary hover:bg-primary/90 text-white font-bold py-2 rounded-lg"
              >
                Link Account
              </Button>
              <Button
                onClick={() => setShowForm(false)}
                variant="outline"
                className="flex-1 border-border text-foreground py-2 rounded-lg"
              >
                Cancel
              </Button>
            </div>
          </Card>
        )}
      </div>

      {/* Available Retailers */}
      {accounts.length === 0 && (
        <div className="p-4 space-y-3">
          <h3 className="font-bold text-foreground">Available Programs</h3>
          {RETAILERS.map((retailer) => (
            <Card key={retailer.name} className={`p-4 border-border ${retailer.color}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{retailer.icon}</span>
                  <div>
                    <p className="font-bold text-foreground">{retailer.name}</p>
                    <p className="text-xs text-muted-foreground">{retailer.program}</p>
                  </div>
                </div>
                <Zap className="w-5 h-5 text-accent" />
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Rewards Info */}
      <div className="p-4">
        <Card className="p-4 border-border bg-accent/10">
          <h3 className="font-bold text-foreground mb-2">💡 Why Link Your Cards?</h3>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>✓ See personalized offers just for you</li>
            <li>✓ Track your loyalty points</li>
            <li>✓ Get exclusive deals</li>
            <li>✓ Earn double rewards on specials</li>
            <li>✓ Redeem points directly in app</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
