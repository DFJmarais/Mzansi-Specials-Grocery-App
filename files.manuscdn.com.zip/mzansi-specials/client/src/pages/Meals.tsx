import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ChefHat, Zap, ShoppingCart, Trash2 } from 'lucide-react';

const MEALS_LIST = [
  'Pap & Vleis',
  'Booty',
  'Eggs & Toast',
  'Vetkoek with Jam',
  'Chicken & Rice',
  'Bobotie',
  'Durban Curry',
  'Braai',
  'Sago Pudding',
  'Oats with Banana',
  'Fried Bread',
  'Milk Tart',
  'Bunny Chow',
  'Sosaties',
  'Samp & Beans',
  'Pap & Sous',
  'Potjiekos',
];

const INGREDIENTS_DB: Record<string, Array<{ name: string; price: number; store: string }>> = {
  'Pap & Vleis': [
    { name: 'Maize Meal (1kg)', price: 45.99, store: 'Spar' },
    { name: 'Beef Steak (500g)', price: 89.99, store: 'Pick n Pay' },
  ],
  'Booty': [
    { name: 'Maize Meal (1kg)', price: 45.99, store: 'Spar' },
    { name: 'Beans (1kg)', price: 34.99, store: 'Checkers' },
  ],
  'Eggs & Toast': [
    { name: 'Eggs (12 pack)', price: 28.99, store: 'OK Foods' },
    { name: 'Bread Loaf', price: 8.99, store: 'Spar' },
  ],
  'Vetkoek with Jam': [
    { name: 'Flour (2kg)', price: 19.99, store: 'Pick n Pay' },
    { name: 'Jam (500g)', price: 24.99, store: 'Checkers' },
  ],
  'Chicken & Rice': [
    { name: 'Chicken Breast (1kg)', price: 64.99, store: 'Checkers' },
    { name: 'Rice (5kg)', price: 79.99, store: 'Pick n Pay' },
  ],
  'Bobotie': [
    { name: 'Ground Beef (500g)', price: 74.99, store: 'Checkers' },
    { name: 'Onion (1kg)', price: 12.99, store: 'Spar' },
    { name: 'Eggs (12 pack)', price: 28.99, store: 'OK Foods' },
  ],
  'Durban Curry': [
    { name: 'Chicken Breast (1kg)', price: 64.99, store: 'Checkers' },
    { name: 'Curry Powder', price: 15.99, store: 'Pick n Pay' },
    { name: 'Rice (5kg)', price: 79.99, store: 'Pick n Pay' },
  ],
  'Braai': [
    { name: 'Beef Steak (500g)', price: 89.99, store: 'Pick n Pay' },
    { name: 'Pork Chops (500g)', price: 69.99, store: 'Spar' },
    { name: 'Chicken Breast (1kg)', price: 64.99, store: 'Checkers' },
  ],
  'Sago Pudding': [
    { name: 'Sago (500g)', price: 18.99, store: 'Spar' },
    { name: 'Milk (1L)', price: 17.02, store: 'OK Foods' },
    { name: 'Sugar (1kg)', price: 14.99, store: 'Pick n Pay' },
  ],
  'Oats with Banana': [
    { name: 'Oats (500g)', price: 22.99, store: 'Checkers' },
    { name: 'Banana (1kg)', price: 16.99, store: 'Spar' },
    { name: 'Milk (1L)', price: 17.02, store: 'OK Foods' },
  ],
  'Fried Bread': [
    { name: 'Bread Loaf', price: 8.99, store: 'Spar' },
    { name: 'Oil (1L)', price: 29.99, store: 'Pick n Pay' },
  ],
  'Milk Tart': [
    { name: 'Milk (1L)', price: 17.02, store: 'OK Foods' },
    { name: 'Flour (2kg)', price: 19.99, store: 'Pick n Pay' },
    { name: 'Eggs (12 pack)', price: 28.99, store: 'OK Foods' },
  ],
  'Bunny Chow': [
    { name: 'Bread Loaf', price: 8.99, store: 'Spar' },
    { name: 'Curry Powder', price: 15.99, store: 'Pick n Pay' },
    { name: 'Chicken Breast (1kg)', price: 64.99, store: 'Checkers' },
  ],
  'Sosaties': [
    { name: 'Beef Steak (500g)', price: 89.99, store: 'Pick n Pay' },
    { name: 'Onion (1kg)', price: 12.99, store: 'Spar' },
  ],
  'Samp & Beans': [
    { name: 'Samp (1kg)', price: 21.99, store: 'Checkers' },
    { name: 'Beans (1kg)', price: 34.99, store: 'Checkers' },
  ],
  'Pap & Sous': [
    { name: 'Maize Meal (1kg)', price: 45.99, store: 'Spar' },
    { name: 'Beef Stew Meat (500g)', price: 74.99, store: 'Checkers' },
  ],
  'Potjiekos': [
    { name: 'Beef Stew Meat (500g)', price: 74.99, store: 'Checkers' },
    { name: 'Potato (2kg)', price: 18.99, store: 'Spar' },
    { name: 'Carrot (1kg)', price: 14.99, store: 'Pick n Pay' },
  ],
};

export default function Meals() {
  const [selectedMeals, setSelectedMeals] = useState<string[]>([]);
  const [shoppingList, setShoppingList] = useState<Array<{ name: string; price: number; store: string }>>([]);
  const [showShoppingList, setShowShoppingList] = useState(false);

  const toggleMeal = (meal: string) => {
    setSelectedMeals(prev =>
      prev.includes(meal)
        ? prev.filter(m => m !== meal)
        : [...prev, meal]
    );
  };

  const generateShoppingList = () => {
    const list: Array<{ name: string; price: number; store: string }> = [];
    selectedMeals.forEach(meal => {
      const ingredients = INGREDIENTS_DB[meal] || [];
      list.push(...ingredients);
    });
    setShoppingList(list);
    setShowShoppingList(true);
  };

  const clearSelection = () => {
    setSelectedMeals([]);
    setShoppingList([]);
    setShowShoppingList(false);
  };

  const totalCost = shoppingList.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <ChefHat className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold text-primary">Meal Planner</h1>
          </div>
          <p className="text-muted-foreground text-lg">Select meals and generate your shopping list with ingredient costs</p>
        </div>

        {/* Meal Selection Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mb-8">
          {MEALS_LIST.map(meal => (
            <button
              key={meal}
              onClick={() => toggleMeal(meal)}
              className={`p-4 rounded-lg border-2 font-semibold transition-all text-center ${
                selectedMeals.includes(meal)
                  ? 'border-primary bg-primary/15 text-primary'
                  : 'border-border bg-card text-foreground hover:border-primary hover:bg-card/80'
              }`}
            >
              {meal}
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 mb-8 justify-center">
          <Button
            onClick={generateShoppingList}
            disabled={selectedMeals.length === 0}
            size="lg"
            className="bg-accent hover:bg-accent/90 text-white font-bold px-8 py-6 text-lg rounded-lg shadow-lg flex items-center gap-2"
          >
            <Zap className="w-6 h-6" />
            GENERATE SHOPPING LIST
          </Button>
          {selectedMeals.length > 0 && (
            <Button
              onClick={clearSelection}
              variant="outline"
              size="lg"
              className="px-8 py-6 text-lg"
            >
              Clear All
            </Button>
          )}
        </div>

        {/* Shopping List Display */}
        {showShoppingList && shoppingList.length > 0 && (
          <Card className="p-8 border-2 border-primary/20 bg-card">
            <div className="flex items-center gap-3 mb-6">
              <ShoppingCart className="w-7 h-7 text-primary" />
              <h2 className="text-3xl font-bold text-primary">Shopping List</h2>
              <span className="ml-auto text-sm text-muted-foreground">
                {selectedMeals.length} meal{selectedMeals.length !== 1 ? 's' : ''} selected
              </span>
            </div>

            {/* Ingredients List */}
            <div className="space-y-3 mb-8">
              {shoppingList.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-muted/50 rounded-lg border border-border flex justify-between items-center hover:bg-muted/70 transition-colors"
                >
                  <div className="flex-1">
                    <p className="font-semibold text-foreground text-lg">{item.name}</p>
                    <p className="text-sm text-muted-foreground">Best price at {item.store}</p>
                  </div>
                  <p className="text-xl font-bold text-primary ml-4">R{item.price.toFixed(2)}</p>
                </div>
              ))}
            </div>

            {/* Total Cost */}
            <div className="p-6 bg-primary/10 rounded-lg border-2 border-primary/20">
              <p className="text-2xl font-bold text-primary">
                Total Shopping Cost: R{totalCost.toFixed(2)}
              </p>
            </div>
          </Card>
        )}

        {/* Empty State */}
        {!showShoppingList && selectedMeals.length === 0 && (
          <div className="text-center py-16">
            <p className="text-xl text-muted-foreground">Select meals above to create your shopping list</p>
          </div>
        )}

        {/* Selected but not generated */}
        {!showShoppingList && selectedMeals.length > 0 && (
          <div className="text-center py-12 bg-muted/30 rounded-lg border border-border">
            <p className="text-lg text-muted-foreground">
              Click "GENERATE SHOPPING LIST" to see ingredients and costs
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
