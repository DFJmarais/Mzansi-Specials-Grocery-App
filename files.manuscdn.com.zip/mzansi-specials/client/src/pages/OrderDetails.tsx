import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Package, Truck, MapPin, Calendar } from 'lucide-react';
import { useLocation } from 'wouter';

export default function OrderDetails() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  
  // Get order ID from URL params
  const orderId = parseInt(new URLSearchParams(window.location.search).get('id') || '0');
  
  // Get order details
  const { data: order, isLoading } = trpc.orders.getOrderDetails.useQuery({
    orderId,
  });

  // Get delivery tracking
  const { data: tracking } = trpc.orders.getDeliveryTracking.useQuery({
    orderId,
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto text-center py-12">
          <p className="text-lg text-muted-foreground">Please log in to view order details</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto">
          <div className="h-96 bg-muted rounded-lg animate-pulse" />
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto">
          <Button variant="outline" onClick={() => navigate('/orders')} className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Orders
          </Button>
          <Card className="p-12 text-center">
            <p className="text-lg text-muted-foreground">Order not found</p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <Button variant="outline" onClick={() => navigate('/orders')} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Orders
        </Button>

        {/* Order Header */}
        <Card className="p-6 mb-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold">{order.orderNumber}</h1>
              <p className="text-muted-foreground">Order placed on {(order as any).createdAt ? new Date((order as any).createdAt).toLocaleDateString() : 'N/A'}</p>
            </div>
            <Badge className="bg-green-100 text-green-800 text-lg px-4 py-2">
              {order.status.toUpperCase()}
            </Badge>
          </div>
        </Card>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Order Summary */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Order Total</span>
                <span className="font-semibold">R{(order.totalAmount / 100).toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Items</span>
                <span className="font-semibold">{order.items?.length || 0}</span>
              </div>
              <div className="border-t pt-3 flex justify-between">
                <span className="font-semibold">Total</span>
                <span className="font-bold text-lg">R{(order.totalAmount / 100).toFixed(2)}</span>
              </div>
            </div>
          </Card>

          {/* Shipping Address */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Shipping Address
            </h2>
            <p className="text-muted-foreground">{(order as any).shippingAddress || 'Address not available'}</p>
          </Card>
        </div>

        {/* Order Items */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Items</h2>
          <div className="space-y-3">
            {order.items?.map((item: any) => (
              <div key={item.id} className="flex justify-between items-center border-b pb-3">
                <div>
                  <p className="font-medium">{item.productName}</p>
                  <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                </div>
                <p className="font-semibold">R{(item.totalPrice / 100).toFixed(2)}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Delivery Tracking */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
            <Truck className="w-5 h-5" />
            Delivery Tracking
          </h2>

          <div className="space-y-6">
            {/* Current Status */}
            <div className="bg-primary/10 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-2">
                <Package className="w-6 h-6 text-primary" />
                <div>
                  <p className="font-semibold text-lg">{tracking?.currentStatus?.toUpperCase()}</p>
                  <p className="text-sm text-muted-foreground">{tracking?.location}</p>
                </div>
              </div>
              <p className="text-sm">
                <Calendar className="w-4 h-4 inline mr-2" />
                Estimated Delivery: {tracking?.estimatedDelivery ? new Date(tracking.estimatedDelivery).toLocaleDateString() : 'TBD'}
              </p>
            </div>

            {/* Tracking History Timeline */}
            <div>
              <h3 className="font-semibold mb-4">Tracking History</h3>
              <div className="space-y-4">
                {tracking?.trackingHistory?.map((event: any, index: number) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="w-4 h-4 rounded-full bg-primary" />
                      {index < (tracking?.trackingHistory?.length - 1) && (
                        <div className="w-1 h-12 bg-border mt-2" />
                      )}
                    </div>
                    <div className="pb-4">
                      <p className="font-semibold">{event.status?.toUpperCase()}</p>
                      <p className="text-sm text-muted-foreground">{event.notes}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {event.timestamp ? new Date(event.timestamp).toLocaleString() : 'N/A'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
