import { useState } from 'react';
import { Heart, Trash2, Bell, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useAuth } from '@/_core/hooks/useAuth';

/**
 * Wishlist Page
 * Users can save favorite products and track prices
 */

interface WishlistItem {
  id: string;
  productName: string;
  brand: string;
  category: string;
  currentPrice: number;
  lowestPrice: number;
  highestPrice: number;
  imageUrl?: string;
  retailers: Array<{
    name: string;
    price: number;
    url: string;
  }>;
  priceDropAlert: boolean;
  alertThreshold?: number;
  addedDate: Date;
}

export default function Wishlist() {
  const { user } = useAuth();
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([
    {
      id: '1',
      productName: 'Coca-Cola Original Taste 2L',
      brand: 'Coca-Cola',
      category: 'Beverages',
      currentPrice: 3499,
      lowestPrice: 3299,
      highestPrice: 4199,
      imageUrl: 'https://via.placeholder.com/200x200?text=Coca-Cola',
      retailers: [
        { name: 'Checkers', price: 3499, url: '#' },
        { name: 'Pick n Pay', price: 3599, url: '#' },
        { name: 'SPAR', price: 3799, url: '#' },
      ],
      priceDropAlert: true,
      alertThreshold: 3300,
      addedDate: new Date('2026-03-20'),
    },
  ]);

  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [showAlertSettings, setShowAlertSettings] = useState<string | null>(null);

  const categories = ['All', ...Array.from(new Set(wishlistItems.map((item) => item.category)))];

  const filteredItems =
    filterCategory === 'All'
      ? wishlistItems
      : wishlistItems.filter((item) => item.category === filterCategory);

  const handleRemoveFromWishlist = (id: string) => {
    setWishlistItems(wishlistItems.filter((item) => item.id !== id));
    toast.success('Removed from wishlist');
  };

  const handleSetPriceAlert = (id: string, threshold: number) => {
    setWishlistItems(
      wishlistItems.map((item) =>
        item.id === id
          ? { ...item, priceDropAlert: true, alertThreshold: threshold }
          : item
      )
    );
    toast.success(`Price alert set for R${(threshold / 100).toFixed(2)}`);
    setShowAlertSettings(null);
  };

  const handleShareWishlist = () => {
    const shareText = `Check out my grocery wishlist on Mzansi Specials! ${wishlistItems.length} items tracked.`;
    if (navigator.share) {
      navigator.share({
        title: 'My Mzansi Specials Wishlist',
        text: shareText,
        url: window.location.href,
      });
    } else {
      toast.success('Wishlist link copied!');
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-border p-4">
        <h1 className="text-2xl font-bold text-foreground mb-2">My Wishlist</h1>
        <p className="text-sm text-muted-foreground">
          {wishlistItems.length} items • Track prices and get alerts
        </p>
      </div>

      {/* Stats */}
      <div className="bg-white border-b border-border p-4">
        <div className="grid grid-cols-3 gap-3">
          <Card className="p-3 text-center border-border">
            <p className="text-xs text-muted-foreground">Total Items</p>
            <p className="text-2xl font-bold text-primary">{wishlistItems.length}</p>
          </Card>
          <Card className="p-3 text-center border-border">
            <p className="text-xs text-muted-foreground">Avg Price</p>
            <p className="text-2xl font-bold text-foreground">
              R{(wishlistItems.reduce((sum, item) => sum + item.currentPrice, 0) / wishlistItems.length / 100).toFixed(2)}
            </p>
          </Card>
          <Card className="p-3 text-center border-border">
            <p className="text-xs text-muted-foreground">Price Alerts</p>
            <p className="text-2xl font-bold text-accent">
              {wishlistItems.filter((item) => item.priceDropAlert).length}
            </p>
          </Card>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border-b border-border p-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                filterCategory === cat
                  ? 'bg-primary text-white'
                  : 'bg-muted text-foreground hover:bg-muted/80'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Wishlist Items */}
      <div className="p-4 space-y-3">
        {filteredItems.length === 0 ? (
          <Card className="p-8 text-center border-border">
            <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
            <p className="text-foreground font-semibold mb-2">No items in wishlist</p>
            <p className="text-sm text-muted-foreground">
              Add products to track prices and get notified of price drops
            </p>
          </Card>
        ) : (
          filteredItems.map((item) => (
            <Card key={item.id} className="overflow-hidden border-border hover:shadow-md transition-shadow">
              <div className="flex gap-3 p-3">
                {/* Image */}
                <div className="w-20 h-20 bg-muted rounded-lg overflow-hidden flex-shrink-0">
                  {item.imageUrl ? (
                    <img
                      src={item.imageUrl}
                      alt={item.productName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-2xl">
                      📦
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div>
                      <p className="text-xs text-muted-foreground font-semibold">{item.brand}</p>
                      <h3 className="font-bold text-foreground line-clamp-2">
                        {item.productName}
                      </h3>
                    </div>
                    {item.priceDropAlert && (
                      <Badge className="bg-accent text-white text-xs flex-shrink-0">
                        <Bell className="w-3 h-3 mr-1" />
                        Alert
                      </Badge>
                    )}
                  </div>

                  {/* Price Info */}
                  <div className="mb-2">
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="text-lg font-bold text-primary">
                        R{(item.currentPrice / 100).toFixed(2)}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        Low: R{(item.lowestPrice / 100).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Retailers */}
                  <div className="flex gap-1 flex-wrap mb-2">
                    {item.retailers.map((retailer) => (
                      <Badge
                        key={retailer.name}
                        variant="outline"
                        className="text-xs cursor-pointer hover:bg-muted"
                      >
                        {retailer.name}: R{(retailer.price / 100).toFixed(2)}
                      </Badge>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowAlertSettings(item.id)}
                      className="text-xs px-2 py-1 rounded bg-muted hover:bg-muted/80 text-foreground font-semibold transition-colors"
                    >
                      <Bell className="w-3 h-3 inline mr-1" />
                      Alert
                    </button>
                    <button
                      onClick={() => handleRemoveFromWishlist(item.id)}
                      className="text-xs px-2 py-1 rounded bg-red-50 hover:bg-red-100 text-red-600 font-semibold transition-colors"
                    >
                      <Trash2 className="w-3 h-3 inline mr-1" />
                      Remove
                    </button>
                  </div>
                </div>
              </div>

              {/* Alert Settings */}
              {showAlertSettings === item.id && (
                <div className="border-t border-border p-3 bg-muted/30">
                  <p className="text-sm font-semibold text-foreground mb-2">
                    Alert me when price drops below:
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      defaultValue={(item.alertThreshold || item.currentPrice) / 100}
                      step="0.01"
                      className="flex-1 px-2 py-1 border border-border rounded text-sm"
                      placeholder="Price in Rands"
                    />
                    <Button
                      onClick={() =>
                        handleSetPriceAlert(
                          item.id,
                          Math.round(
                            parseFloat(
                              (
                                document.querySelector(
                                  `input[placeholder="Price in Rands"]`
                                ) as HTMLInputElement
                              )?.value || '0'
                            ) * 100
                          )
                        )
                      }
                      size="sm"
                      className="bg-primary hover:bg-primary/90 text-white"
                    >
                      Set Alert
                    </Button>
                  </div>
                </div>
              )}
            </Card>
          ))
        )}
      </div>

      {/* Share Button */}
      {wishlistItems.length > 0 && (
        <div className="fixed bottom-24 right-4 left-4">
          <Button
            onClick={handleShareWishlist}
            className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
          >
            <Share2 className="w-5 h-5" />
            Share Wishlist
          </Button>
        </div>
      )}
    </div>
  );
}
