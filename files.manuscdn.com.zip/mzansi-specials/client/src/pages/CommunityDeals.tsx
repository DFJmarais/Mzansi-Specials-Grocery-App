import { useState } from 'react';
import { Heart, MessageCircle, Share2, TrendingDown, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useAuth } from '@/_core/hooks/useAuth';

/**
 * Community Deals Page
 * Users share their best grocery deals and savings
 */

interface CommunityDeal {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  title: string;
  description: string;
  productName: string;
  retailer: string;
  originalPrice: number;
  dealPrice: number;
  savings: number;
  savingsPercent: number;
  category: string;
  imageUrl?: string;
  likes: number;
  comments: number;
  shares: number;
  createdAt: Date;
  isLiked?: boolean;
}

export default function CommunityDeals() {
  const { user } = useAuth();
  const [deals, setDeals] = useState<CommunityDeal[]>([
    {
      id: '1',
      userId: 'user1',
      userName: 'Thabo M.',
      userAvatar: '👨',
      title: 'Massive Coca-Cola Deal at Checkers!',
      description: 'Found 2L bottles on special - perfect for the weekend braai!',
      productName: 'Coca-Cola Original Taste 2L',
      retailer: 'Checkers',
      originalPrice: 4199,
      dealPrice: 3499,
      savings: 700,
      savingsPercent: 17,
      category: 'Beverages',
      imageUrl: 'https://via.placeholder.com/200x200?text=Coca-Cola',
      likes: 234,
      comments: 45,
      shares: 89,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      isLiked: false,
    },
    {
      id: '2',
      userId: 'user2',
      userName: 'Nomsa K.',
      userAvatar: '👩',
      title: 'Best Chicken Price This Month',
      description: 'Pick n Pay has the freshest chicken at unbeatable prices',
      productName: 'Chicken Breast 1kg',
      retailer: 'Pick n Pay',
      originalPrice: 6499,
      dealPrice: 5299,
      savings: 1200,
      savingsPercent: 18,
      category: 'Meat',
      imageUrl: 'https://via.placeholder.com/200x200?text=Chicken',
      likes: 156,
      comments: 32,
      shares: 67,
      createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      isLiked: false,
    },
    {
      id: '3',
      userId: 'user3',
      userName: 'Sipho L.',
      userAvatar: '👨',
      title: 'SPAR Rice Special - Stock Up!',
      description: '5kg bags of rice at 25% off - grab them while they last',
      productName: 'Rice 5kg',
      retailer: 'SPAR',
      originalPrice: 7999,
      dealPrice: 5999,
      savings: 2000,
      savingsPercent: 25,
      category: 'Pantry',
      imageUrl: 'https://via.placeholder.com/200x200?text=Rice',
      likes: 412,
      comments: 78,
      shares: 145,
      createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      isLiked: false,
    },
  ]);

  const [sortBy, setSortBy] = useState<'recent' | 'trending' | 'savings'>('trending');
  const [showPostForm, setShowPostForm] = useState(false);

  const sortedDeals = [...deals].sort((a, b) => {
    switch (sortBy) {
      case 'recent':
        return b.createdAt.getTime() - a.createdAt.getTime();
      case 'trending':
        return b.likes + b.comments + b.shares - (a.likes + a.comments + a.shares);
      case 'savings':
        return b.savings - a.savings;
      default:
        return 0;
    }
  });

  const handleLike = (id: string) => {
    setDeals(
      deals.map((deal) =>
        deal.id === id
          ? {
              ...deal,
              likes: deal.isLiked ? deal.likes - 1 : deal.likes + 1,
              isLiked: !deal.isLiked,
            }
          : deal
      )
    );
  };

  const handleShare = (deal: CommunityDeal) => {
    const shareText = `Check out this deal! ${deal.title} - Save R${(deal.savings / 100).toFixed(2)} on Mzansi Specials`;
    if (navigator.share) {
      navigator.share({
        title: deal.title,
        text: shareText,
        url: window.location.href,
      });
    } else {
      toast.success('Deal link copied!');
    }
  };

  const totalSavings = deals.reduce((sum, deal) => sum + deal.savings, 0);
  const totalUsers = new Set(deals.map((deal) => deal.userId)).size;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-border p-4">
        <h1 className="text-2xl font-bold text-foreground mb-2">Community Deals</h1>
        <p className="text-sm text-muted-foreground">
          Discover amazing deals shared by South African shoppers
        </p>
      </div>

      {/* Stats */}
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 border-b border-border p-4">
        <div className="grid grid-cols-3 gap-3">
          <div>
            <p className="text-xs text-muted-foreground">Total Savings</p>
            <p className="text-2xl font-bold text-primary">
              R{(totalSavings / 100).toFixed(0)}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Active Users</p>
            <p className="text-2xl font-bold text-secondary">{totalUsers}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Deals Shared</p>
            <p className="text-2xl font-bold text-accent">{deals.length}</p>
          </div>
        </div>
      </div>

      {/* Post Deal Button */}
      <div className="p-4 border-b border-border">
        <Button
          onClick={() => setShowPostForm(!showPostForm)}
          className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg"
        >
          Share Your Best Deal
        </Button>
      </div>

      {/* Sort Options */}
      <div className="bg-white border-b border-border p-4">
        <div className="flex gap-2">
          {(['recent', 'trending', 'savings'] as const).map((option) => (
            <button
              key={option}
              onClick={() => setSortBy(option)}
              className={`px-3 py-1 rounded-full text-sm font-semibold capitalize transition-all ${
                sortBy === option
                  ? 'bg-primary text-white'
                  : 'bg-muted text-foreground hover:bg-muted/80'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      {/* Deals Feed */}
      <div className="p-4 space-y-3">
        {sortedDeals.map((deal) => (
          <Card key={deal.id} className="overflow-hidden border-border hover:shadow-md transition-shadow">
            {/* Deal Header */}
            <div className="p-3 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-lg">
                  {deal.userAvatar}
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">{deal.userName}</p>
                  <p className="text-xs text-muted-foreground">
                    {Math.floor((Date.now() - deal.createdAt.getTime()) / (60 * 60 * 1000))}h ago
                  </p>
                </div>
              </div>
              <Badge className="bg-secondary text-white text-xs">
                {deal.retailer}
              </Badge>
            </div>

            {/* Deal Content */}
            <div className="p-3">
              <h3 className="font-bold text-foreground mb-1">{deal.title}</h3>
              <p className="text-sm text-muted-foreground mb-3">{deal.description}</p>

              {/* Image & Savings */}
              <div className="flex gap-3 mb-3">
                <div className="w-20 h-20 bg-muted rounded-lg overflow-hidden flex-shrink-0">
                  {deal.imageUrl ? (
                    <img
                      src={deal.imageUrl}
                      alt={deal.productName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-2xl">
                      🛒
                    </div>
                  )}
                </div>

                <div className="flex-1">
                  <p className="text-xs text-muted-foreground mb-1">{deal.productName}</p>
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-lg font-bold text-primary">
                      R{(deal.dealPrice / 100).toFixed(2)}
                    </span>
                    <span className="text-sm line-through text-muted-foreground">
                      R{(deal.originalPrice / 100).toFixed(2)}
                    </span>
                  </div>
                  <Badge className="bg-accent text-white text-xs">
                    <TrendingDown className="w-3 h-3 mr-1" />
                    Save R{(deal.savings / 100).toFixed(2)} ({deal.savingsPercent}%)
                  </Badge>
                </div>
              </div>

              {/* Category */}
              <div className="mb-3">
                <Badge variant="outline" className="text-xs">
                  {deal.category}
                </Badge>
              </div>
            </div>

            {/* Engagement Stats */}
            <div className="bg-muted/30 p-3 border-t border-border flex items-center justify-between text-xs">
              <div className="flex gap-3">
                <span className="text-muted-foreground">
                  ❤️ {deal.likes} Likes
                </span>
                <span className="text-muted-foreground">
                  💬 {deal.comments} Comments
                </span>
                <span className="text-muted-foreground">
                  📤 {deal.shares} Shares
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="p-3 border-t border-border flex gap-2">
              <Button
                onClick={() => handleLike(deal.id)}
                variant="outline"
                size="sm"
                className={`flex-1 ${
                  deal.isLiked
                    ? 'bg-red-50 border-red-200 text-red-600'
                    : 'border-border text-foreground'
                }`}
              >
                <Heart
                  className={`w-4 h-4 mr-1 ${deal.isLiked ? 'fill-red-600' : ''}`}
                />
                Like
              </Button>
              <Button
                onClick={() => handleShare(deal)}
                variant="outline"
                size="sm"
                className="flex-1 border-border text-foreground"
              >
                <Share2 className="w-4 h-4 mr-1" />
                Share
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
