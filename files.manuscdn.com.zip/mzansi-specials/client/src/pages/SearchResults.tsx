import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, Filter, ChevronDown, TrendingDown, Zap } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { FC } from 'react';

/**
 * SEARCH RESULTS PAGE - Modern Price Comparison Focus
 * 
 * Purpose: Show search results with emphasis on cheapest options
 * Design: Clean product cards, price comparison, filtering, sorting
 */

const SearchResults: FC = () => {
  const [, setLocation] = useLocation();
  const { t } = useTranslation();
  const [sortBy, setSortBy] = useState<'price-low' | 'price-high' | 'savings'>('price-low');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedStores, setSelectedStores] = useState<string[]>([]);

  // Mock search results data
  const mockResults = [
    { id: 1, name: 'Full Cream Milk 1L', category: 'Dairy', prices: [{ store: 'Checkers', price: 17.99, original: 21.99 }, { store: 'SPAR', price: 18.99, original: 21.99 }, { store: 'Pick n Pay', price: 19.99, original: 21.99 }] },
    { id: 2, name: 'Chicken Breast 1kg', category: 'Meat', prices: [{ store: 'Checkers', price: 54.99, original: 69.99 }, { store: 'SPAR', price: 59.99, original: 69.99 }, { store: 'Woolworths', price: 64.99, original: 69.99 }] },
    { id: 3, name: 'Bread White Loaf', category: 'Bakery', prices: [{ store: 'Pick n Pay', price: 7.99, original: 9.99 }, { store: 'Checkers', price: 8.49, original: 9.99 }, { store: 'SPAR', price: 8.99, original: 9.99 }] },
    { id: 4, name: 'Tomatoes 1kg', category: 'Produce', prices: [{ store: 'Woolworths', price: 9.99, original: 14.99 }, { store: 'Checkers', price: 11.99, original: 14.99 }, { store: 'SPAR', price: 12.99, original: 14.99 }] },
    { id: 5, name: 'Rice 5kg', category: 'Pantry', prices: [{ store: 'Checkers', price: 75.99, original: 84.99 }, { store: 'SPAR', price: 79.99, original: 84.99 }, { store: 'Pick n Pay', price: 82.99, original: 84.99 }] },
    { id: 6, name: 'Eggs Dozen', category: 'Dairy', prices: [{ store: 'SPAR', price: 24.99, original: 29.99 }, { store: 'Checkers', price: 26.99, original: 29.99 }, { store: 'Woolworths', price: 28.99, original: 29.99 }] },
  ];

  const stores = ['Checkers', 'Pick n Pay', 'SPAR', 'Woolworths', 'OK Foods'];

  // Get cheapest price for each product
  const getLowestPrice = (prices: any[]) => Math.min(...prices.map(p => p.price));
  const getCheapestStore = (prices: any[]) => prices.find(p => p.price === getLowestPrice(prices))?.store;

  // Sort results
  const sortedResults = useMemo(() => {
    let results = [...mockResults];

    if (selectedStores.length > 0) {
      results = results.filter(product => 
        product.prices.some(p => selectedStores.includes(p.store))
      );
    }

    if (sortBy === 'price-low') {
      results.sort((a, b) => getLowestPrice(a.prices) - getLowestPrice(b.prices));
    } else if (sortBy === 'price-high') {
      results.sort((a, b) => getLowestPrice(b.prices) - getLowestPrice(a.prices));
    } else if (sortBy === 'savings') {
      results.sort((a, b) => {
        const savingsA = Math.max(...a.prices.map(p => p.original)) - getLowestPrice(a.prices);
        const savingsB = Math.max(...b.prices.map(p => p.original)) - getLowestPrice(b.prices);
        return savingsB - savingsA;
      });
    }

    return results;
  }, [sortBy, selectedStores]);

  const navigate = (path: string) => setLocation(path);

  return (
    <div className="main-content" style={{ background: '#FFFFFF' }}>
      {/* HEADER */}
      <div style={{
        background: 'linear-gradient(135deg, #00A651 0%, #008040 100%)',
        color: 'white',
        padding: '1.5rem 1rem',
        position: 'sticky',
        top: 0,
        zIndex: 10,
      }}>
        <div className="container" style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
            <button
              onClick={() => navigate('/')}
              style={{
                background: 'rgba(255, 255, 255, 0.2)',
                border: 'none',
                color: 'white',
                padding: '0.5rem',
                borderRadius: '0.5rem',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <ArrowLeft style={{ width: '24px', height: '24px' }} />
            </button>
            <div>
              <h1 style={{ fontSize: '1.5rem', fontWeight: 800, margin: 0 }}>
                {t('search.results', 'Search Results')}
              </h1>
              <p style={{ fontSize: '0.9rem', opacity: 0.9, margin: 0 }}>
                {sortedResults.length} {t('search.productsFound', 'products found')}
              </p>
            </div>
          </div>

          {/* SORT & FILTER BAR */}
          <div style={{
            display: 'flex',
            gap: '0.75rem',
            flexWrap: 'wrap',
            alignItems: 'center',
          }}>
            {/* Sort Dropdown */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              style={{
                background: 'rgba(255, 255, 255, 0.2)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                color: 'white',
                padding: '0.5rem 1rem',
                borderRadius: '0.5rem',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              <option value="price-low" style={{ color: '#1A1A1A' }}>
                {t('search.cheapestFirst', 'Cheapest First')}
              </option>
              <option value="price-high" style={{ color: '#1A1A1A' }}>
                {t('search.mostExpensive', 'Most Expensive')}
              </option>
              <option value="savings" style={{ color: '#1A1A1A' }}>
                {t('search.highestSavings', 'Highest Savings')}
              </option>
            </select>

            {/* Filter Button */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              style={{
                background: 'rgba(255, 255, 255, 0.2)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                color: 'white',
                padding: '0.5rem 1rem',
                borderRadius: '0.5rem',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
              }}
            >
              <Filter style={{ width: '18px', height: '18px' }} />
              {t('search.filters', 'Filters')}
            </button>
          </div>
        </div>
      </div>

      {/* FILTERS PANEL */}
      {showFilters && (
        <div style={{
          background: 'linear-gradient(135deg, rgba(0, 166, 81, 0.05), rgba(0, 166, 81, 0.02))',
          borderBottom: '2px solid #00A651',
          padding: '1.5rem 1rem',
        }}>
          <div className="container" style={{ maxWidth: '1200px', margin: '0 auto' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: '1rem', color: '#1A1A1A' }}>
              {t('search.filterByStore', 'Filter by Store')}
            </h3>
            <div style={{
              display: 'flex',
              gap: '0.75rem',
              flexWrap: 'wrap',
            }}>
              {stores.map((store) => (
                <label
                  key={store}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    padding: '0.75rem 1rem',
                    background: selectedStores.includes(store) ? '#00A651' : 'white',
                    border: '2px solid #00A651',
                    borderRadius: '0.75rem',
                    cursor: 'pointer',
                    color: selectedStores.includes(store) ? 'white' : '#1A1A1A',
                    fontWeight: 600,
                    transition: 'all 0.3s ease',
                  }}
                >
                  <input
                    type="checkbox"
                    checked={selectedStores.includes(store)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedStores([...selectedStores, store]);
                      } else {
                        setSelectedStores(selectedStores.filter(s => s !== store));
                      }
                    }}
                    style={{ cursor: 'pointer' }}
                  />
                  {store}
                </label>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* RESULTS GRID */}
      <div className="container" style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem 1rem' }}>
        {sortedResults.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: '3rem 1rem',
            background: '#F5F5F5',
            borderRadius: '1rem',
          }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '0.5rem', color: '#1A1A1A' }}>
              {t('search.noResults', 'No products found')}
            </h2>
            <p style={{ color: '#666', marginBottom: '1.5rem' }}>
              {t('search.tryDifferent', 'Try different search terms or filters')}
            </p>
            <button
              onClick={() => navigate('/')}
              style={{
                background: 'linear-gradient(135deg, #00A651, #008040)',
                color: 'white',
                border: 'none',
                padding: '0.75rem 1.5rem',
                borderRadius: '0.75rem',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              {t('common.backHome', 'Back to Home')}
            </button>
          </div>
        ) : (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: '1.5rem',
          }}>
            {sortedResults.map((product) => {
              const lowestPrice = getLowestPrice(product.prices);
              const cheapestStore = getCheapestStore(product.prices);
              const maxPrice = Math.max(...product.prices.map(p => p.original));
              const savings = maxPrice - lowestPrice;
              const savingsPercent = Math.round((savings / maxPrice) * 100);

              return (
                <div
                  key={product.id}
                  onClick={() => navigate(`/product/${product.id}`)}
                  style={{
                    background: 'white',
                    border: '2px solid #E0E0E0',
                    borderRadius: '1rem',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                    display: 'flex',
                    flexDirection: 'column',
                  }}
                  onMouseEnter={(e) => {
                    const el = e.currentTarget as HTMLDivElement;
                    el.style.transform = 'translateY(-8px)';
                    el.style.boxShadow = '0 12px 24px rgba(0, 0, 0, 0.15)';
                    el.style.borderColor = '#00A651';
                  }}
                  onMouseLeave={(e) => {
                    const el = e.currentTarget as HTMLDivElement;
                    el.style.transform = 'translateY(0)';
                    el.style.boxShadow = 'none';
                    el.style.borderColor = '#E0E0E0';
                  }}
                >
                  {/* Savings Badge */}
                  {savingsPercent > 0 && (
                    <div style={{
                      background: 'linear-gradient(135deg, #E31B23, #FF6600)',
                      color: 'white',
                      padding: '0.75rem 1rem',
                      textAlign: 'center',
                      fontSize: '0.9rem',
                      fontWeight: 700,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.5rem',
                    }}>
                      <TrendingDown style={{ width: '18px', height: '18px' }} />
                      {t('search.save', 'Save')} {savingsPercent}%
                    </div>
                  )}

                  {/* Product Image Placeholder */}
                  <div style={{
                    background: 'linear-gradient(135deg, #F5F5F5, #FFFBF0)',
                    height: '180px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '3rem',
                  }}>
                    🛒
                  </div>

                  {/* Product Info */}
                  <div style={{ padding: '1.25rem', flex: 1, display: 'flex', flexDirection: 'column' }}>
                    {/* Category */}
                    <div style={{ fontSize: '0.8rem', color: '#999', fontWeight: 600, marginBottom: '0.5rem', textTransform: 'uppercase' }}>
                      {product.category}
                    </div>

                    {/* Product Name */}
                    <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#1A1A1A', marginBottom: '1rem', lineHeight: 1.3 }}>
                      {product.name}
                    </h3>

                    {/* Price Section */}
                    <div style={{ marginBottom: '1rem', flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.5rem', marginBottom: '0.5rem' }}>
                        <span style={{ fontSize: '1.75rem', fontWeight: 800, color: '#00A651' }}>
                          R{lowestPrice.toFixed(2)}
                        </span>
                        <span style={{ fontSize: '0.85rem', color: '#999', textDecoration: 'line-through' }}>
                          R{maxPrice.toFixed(2)}
                        </span>
                      </div>
                      <div style={{ fontSize: '0.85rem', color: '#00A651', fontWeight: 600 }}>
                        {t('search.at', 'at')} {cheapestStore}
                      </div>
                    </div>

                    {/* All Prices */}
                    <div style={{
                      background: '#F5F5F5',
                      borderRadius: '0.75rem',
                      padding: '0.75rem',
                      marginBottom: '1rem',
                      fontSize: '0.8rem',
                    }}>
                      <div style={{ fontWeight: 600, marginBottom: '0.5rem', color: '#666' }}>
                        {t('search.allPrices', 'All Prices')}:
                      </div>
                      {product.prices.map((p) => (
                        <div key={p.store} style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          padding: '0.25rem 0',
                          color: p.price === lowestPrice ? '#00A651' : '#666',
                          fontWeight: p.price === lowestPrice ? 700 : 500,
                        }}>
                          <span>{p.store}</span>
                          <span>R{p.price.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    {/* CTA Button */}
                    <button
                      style={{
                        width: '100%',
                        background: 'linear-gradient(135deg, #00A651, #008040)',
                        color: 'white',
                        border: 'none',
                        padding: '0.75rem',
                        borderRadius: '0.75rem',
                        fontWeight: 700,
                        cursor: 'pointer',
                        fontSize: '0.95rem',
                      }}
                    >
                      {t('common.viewDetails', 'View Details')}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchResults;
