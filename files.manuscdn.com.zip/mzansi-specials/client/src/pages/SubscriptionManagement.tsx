import React, { useState } from 'react';
import { useSubscription } from '@/contexts/SubscriptionContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Check } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function SubscriptionManagement() {
  const { tier, setTier, features } = useSubscription();
  const { t } = useLanguage();
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  const tiers = [
    {
      name: 'Free',
      price: 'R0',
      period: 'Forever',
      id: 'free',
    },
    {
      name: 'Plus',
      price: 'R19.99',
      period: '/month',
      id: 'plus',
    },
    {
      name: 'Pro',
      price: 'R49.99',
      period: '/month',
      id: 'pro',
    },
  ];

  const handleUpgrade = (newTier: string) => {
    setTier(newTier as any);
    // In production, this would trigger App Store/Google Play purchase flow
  };

  const handleDowngrade = (newTier: string) => {
    setTier(newTier as any);
  };

  const handleCancel = () => {
    setTier('free');
    setShowCancelConfirm(false);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Subscription Management
          </h1>
          <p className="text-muted-foreground">
            Manage your Mzansi Specials subscription
          </p>
        </div>

        {/* Current Plan */}
        <Card className="mb-8 p-6 bg-primary/5 border-primary">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Current Plan: <span className="text-primary capitalize">{tier}</span>
          </h2>

          {tier !== 'free' && (
            <div className="space-y-2 mb-6">
              <p className="text-foreground">
                <strong>Renews:</strong> {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}
              </p>
              <p className="text-foreground">
                <strong>Auto-renewal:</strong> Enabled
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div>
              <p className="text-sm text-muted-foreground">Products</p>
              <p className="text-2xl font-bold text-foreground">
                {features.products}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Price Alerts</p>
              <p className="text-2xl font-bold text-foreground">
                {features.priceAlerts ? '✓' : '✗'}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Barcode Scan</p>
              <p className="text-2xl font-bold text-foreground">
                {features.barcodeScanning ? '✓' : '✗'}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Receipt OCR</p>
              <p className="text-2xl font-bold text-foreground">
                {features.receiptOCR ? '✓' : '✗'}
              </p>
            </div>
          </div>

          {tier !== 'free' && (
            <Button
              variant="destructive"
              onClick={() => setShowCancelConfirm(true)}
            >
              Cancel Subscription
            </Button>
          )}
        </Card>

        {/* Change Plan */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Change Your Plan
          </h2>

          <div className="grid md:grid-cols-3 gap-6">
            {tiers.map((plan) => (
              <Card
                key={plan.id}
                className={`p-6 ${
                  tier === plan.id ? 'border-primary border-2' : ''
                }`}
              >
                <h3 className="text-xl font-bold text-foreground mb-2">
                  {plan.name}
                </h3>
                <p className="text-3xl font-bold text-primary mb-4">
                  {plan.price}
                  <span className="text-sm text-muted-foreground ml-2">
                    {plan.period}
                  </span>
                </p>

                {tier === plan.id ? (
                  <Button disabled className="w-full mb-4">
                    <Check className="w-4 h-4 mr-2" />
                    Current Plan
                  </Button>
                ) : tier === 'free' || (tier === 'plus' && plan.id === 'pro') ? (
                  <Button
                    onClick={() => handleUpgrade(plan.id)}
                    className="w-full mb-4 bg-primary text-primary-foreground"
                  >
                    Upgrade
                  </Button>
                ) : (
                  <Button
                    onClick={() => handleDowngrade(plan.id)}
                    variant="outline"
                    className="w-full mb-4"
                  >
                    Downgrade
                  </Button>
                )}
              </Card>
            ))}
          </div>
        </div>

        {/* Billing History */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Billing History
          </h2>
          <p className="text-muted-foreground">
            Your billing history will appear here once you subscribe.
          </p>
        </Card>

        {/* Cancel Confirmation Modal */}
        {showCancelConfirm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="max-w-md w-full p-6">
              <h3 className="text-xl font-bold text-foreground mb-4">
                Cancel Subscription?
              </h3>
              <p className="text-muted-foreground mb-6">
                You'll lose access to premium features. Your current plan will remain active until the end of your billing period.
              </p>
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  onClick={() => setShowCancelConfirm(false)}
                  className="flex-1"
                >
                  Keep Subscription
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleCancel}
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
