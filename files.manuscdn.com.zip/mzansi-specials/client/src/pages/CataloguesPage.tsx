import { useState } from 'react';
import { BookOpen, Download, Eye, Calendar } from 'lucide-react';

interface Catalogue {
  id: number;
  retailer: string;
  title: string;
  validFrom: string;
  validTo: string;
  image: string;
  pages: number;
  lastUpdated: string;
  categories: string[];
}

// Mock data - will be replaced with tRPC queries
const CATALOGUES: Catalogue[] = [
  {
    id: 1,
    retailer: 'Checkers',
    title: 'Weekly Specials - March 29 to April 4',
    validFrom: 'March 29, 2026',
    validTo: 'April 4, 2026',
    image: 'https://images.unsplash.com/photo-1556740738-b6a63e27c4df?w=400&h=500&fit=crop',
    pages: 24,
    lastUpdated: 'March 29, 2026',
    categories: ['Groceries', 'Meat', 'Produce', 'Dairy', 'Bakery'],
  },
  {
    id: 2,
    retailer: 'Pick n Pay',
    title: 'Pick n Pay Specials - This Week',
    validFrom: 'March 29, 2026',
    validTo: 'April 4, 2026',
    image: 'https://images.unsplash.com/photo-1578681994506-b90f8534e213?w=400&h=500&fit=crop',
    pages: 28,
    lastUpdated: 'March 29, 2026',
    categories: ['Groceries', 'Meat', 'Produce', 'Household'],
  },
  {
    id: 3,
    retailer: 'SPAR',
    title: 'SPAR Weekly Deals',
    validFrom: 'March 29, 2026',
    validTo: 'April 4, 2026',
    image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&h=500&fit=crop',
    pages: 20,
    lastUpdated: 'March 29, 2026',
    categories: ['Groceries', 'Meat', 'Produce', 'Pantry'],
  },
  {
    id: 4,
    retailer: 'Woolworths',
    title: 'Woolworths Food Specials',
    validFrom: 'March 29, 2026',
    validTo: 'April 4, 2026',
    image: 'https://images.unsplash.com/photo-1578681994506-b90f8534e213?w=400&h=500&fit=crop',
    pages: 32,
    lastUpdated: 'March 29, 2026',
    categories: ['Groceries', 'Meat', 'Produce', 'Dairy', 'Bakery', 'Household'],
  },
  {
    id: 5,
    retailer: 'OK Foods',
    title: 'OK Foods Weekly Catalogue',
    validFrom: 'March 29, 2026',
    validTo: 'April 4, 2026',
    image: 'https://images.unsplash.com/photo-1556740738-b6a63e27c4df?w=400&h=500&fit=crop',
    pages: 16,
    lastUpdated: 'March 29, 2026',
    categories: ['Groceries', 'Meat', 'Produce'],
  },
];

const RETAILERS = ['All Retailers', 'Checkers', 'Pick n Pay', 'SPAR', 'Woolworths', 'OK Foods'];

export default function CataloguesPage() {
  const [selectedRetailer, setSelectedRetailer] = useState('All Retailers');
  const [selectedCatalogue, setSelectedCatalogue] = useState<Catalogue | null>(null);

  const filteredCatalogues =
    selectedRetailer === 'All Retailers'
      ? CATALOGUES
      : CATALOGUES.filter((c) => c.retailer === selectedRetailer);

  return (
    <div className="bg-white">
      {/* Page Header */}
      <section className="container py-6 md:py-8">
        <h1 className="section-title flex items-center gap-3">
          <BookOpen className="w-8 h-8 text-primary" />
          Weekly Catalogues & Flyers
        </h1>
        <p className="text-text-secondary">
          Browse the latest weekly flyers from all your favorite retailers. Updated every week!
        </p>
      </section>

      {/* Retailer Filter */}
      <section className="container py-6 border-b-2 border-border">
        <p className="text-sm font-semibold text-text-secondary mb-3">Filter by Retailer</p>
        <div className="flex flex-wrap gap-2">
          {RETAILERS.map((retailer) => (
            <button
              key={retailer}
              onClick={() => setSelectedRetailer(retailer)}
              className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                selectedRetailer === retailer
                  ? 'bg-primary text-white'
                  : 'bg-surface text-text-primary border-2 border-border hover:border-primary'
              }`}
            >
              {retailer}
            </button>
          ))}
        </div>
      </section>

      {/* Catalogues Grid */}
      <section className="container py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCatalogues.map((catalogue) => (
            <div
              key={catalogue.id}
              className="bg-white border-2 border-border rounded-xl overflow-hidden hover:shadow-lg hover:border-primary transition-all"
            >
              {/* Catalogue Image */}
              <div className="relative overflow-hidden bg-surface h-64">
                <img
                  src={catalogue.image}
                  alt={catalogue.title}
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                />
                {/* Pages Badge */}
                <div className="absolute top-3 right-3 bg-primary text-white px-3 py-1 rounded-lg font-bold text-sm">
                  {catalogue.pages} pages
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                {/* Retailer Name */}
                <h3 className="text-lg font-bold text-primary mb-2">{catalogue.retailer}</h3>

                {/* Title */}
                <h4 className="font-semibold text-text-primary mb-3">{catalogue.title}</h4>

                {/* Valid Dates */}
                <div className="flex items-center gap-2 text-sm text-text-secondary mb-3">
                  <Calendar className="w-4 h-4" />
                  <span>
                    {catalogue.validFrom} - {catalogue.validTo}
                  </span>
                </div>

                {/* Categories */}
                <div className="mb-4">
                  <p className="text-xs font-semibold text-text-secondary mb-2">Categories:</p>
                  <div className="flex flex-wrap gap-1">
                    {catalogue.categories.map((cat) => (
                      <span
                        key={cat}
                        className="text-xs bg-primary/10 text-primary px-2 py-1 rounded"
                      >
                        {cat}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Last Updated */}
                <p className="text-xs text-text-secondary mb-4">
                  Updated: {catalogue.lastUpdated}
                </p>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedCatalogue(catalogue)}
                    className="flex-1 btn-primary flex items-center justify-center gap-2"
                  >
                    <Eye className="w-4 h-4" />
                    View
                  </button>
                  <button 
                    onClick={() => {
                      const link = document.createElement('a');
                      link.href = `https://example.com/catalogues/${catalogue.retailer.toLowerCase()}.pdf`;
                      link.download = `${catalogue.retailer}-${catalogue.validFrom}.pdf`;
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    }}
                    className="flex-1 btn-secondary flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Download
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Info Section */}
      <section className="container py-12 mb-20">
        <div className="bg-primary/5 border-2 border-primary/20 rounded-xl p-6 md:p-8">
          <h3 className="text-xl font-bold text-primary mb-3">💡 How to Use Catalogues</h3>
          <ul className="space-y-2 text-text-secondary">
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">1.</span>
              <span>Select a retailer to view their latest weekly flyer</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">2.</span>
              <span>Click "View" to browse the full catalogue page by page</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">3.</span>
              <span>Click "Download" to save the PDF for offline viewing</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-primary font-bold">4.</span>
              <span>Add items from the catalogue to your shopping list</span>
            </li>
          </ul>
        </div>
      </section>

      {/* Catalogue Viewer Modal (Placeholder) */}
      {selectedCatalogue && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-auto">
            <div className="sticky top-0 bg-white border-b-2 border-border p-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-primary">{selectedCatalogue.retailer}</h2>
              <button
                onClick={() => setSelectedCatalogue(null)}
                className="text-text-secondary hover:text-text-primary text-2xl"
              >
                ×
              </button>
            </div>
            <div className="p-4">
              <img
                src={selectedCatalogue.image}
                alt={selectedCatalogue.title}
                className="w-full rounded-lg mb-4"
              />
              <p className="text-text-secondary mb-4">
                Full catalogue viewer coming soon. Download PDF to view all {selectedCatalogue.pages}{' '}
                pages.
              </p>
              <button className="btn-primary w-full flex items-center justify-center gap-2">
                <Download className="w-4 h-4" />
                Download Full Catalogue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
