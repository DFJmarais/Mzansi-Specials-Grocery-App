import { useState, useRef, useEffect } from 'react';
import { Camera, Upload, X, Check, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useAuth } from '@/_core/hooks/useAuth';

/**
 * Barcode Scanner Page
 * Users scan product barcodes to submit prices and earn stars
 */

interface ScannedProduct {
  barcode: string;
  productName: string;
  price: number;
  retailer: string;
  timestamp: Date;
  verified: boolean;
}

export default function BarcodeScanner() {
  const { user } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isScanning, setIsScanning] = useState(false);
  const [scannedProducts, setScannedProducts] = useState<ScannedProduct[]>([]);
  const [manualPrice, setManualPrice] = useState<string>('');
  const [selectedRetailer, setSelectedRetailer] = useState<string>('Checkers');
  const [showManualEntry, setShowManualEntry] = useState(false);
  const [starsEarned, setStarsEarned] = useState(0);

  const retailers = ['Checkers', 'Pick n Pay', 'SPAR', 'Woolworths', 'OK Foods'];

  // Start camera
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsScanning(true);
      }
    } catch (error) {
      toast.error('Camera access denied. Please enable camera permissions.');
      console.error('Camera error:', error);
    }
  };

  // Stop camera
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      setIsScanning(false);
    }
  };

  // Capture barcode from video
  const captureBarcode = () => {
    if (canvasRef.current && videoRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
        // In production, use a barcode library like QuaggaJS or ZXing
        // For now, simulate barcode detection
        simulateBarcodeDetection();
      }
    }
  };

  // Simulate barcode detection (in production, use real barcode library)
  const simulateBarcodeDetection = () => {
    const mockBarcodes = [
      { barcode: '6001234567890', productName: 'Coca-Cola 2L', price: 3499 },
      { barcode: '6009876543210', productName: 'Chicken Breast 1kg', price: 5999 },
      { barcode: '6005555555555', productName: 'Rice 5kg', price: 7999 },
    ];

    const randomProduct = mockBarcodes[Math.floor(Math.random() * mockBarcodes.length)];

    const newProduct: ScannedProduct = {
      barcode: randomProduct.barcode,
      productName: randomProduct.productName,
      price: randomProduct.price,
      retailer: selectedRetailer,
      timestamp: new Date(),
      verified: false,
    };

    setScannedProducts([...scannedProducts, newProduct]);
    setStarsEarned(starsEarned + 1);
    toast.success(`✓ Scanned: ${randomProduct.productName}`);
  };

  // Handle manual price entry
  const handleManualEntry = (productName: string) => {
    if (!manualPrice || parseFloat(manualPrice) <= 0) {
      toast.error('Please enter a valid price');
      return;
    }

    const newProduct: ScannedProduct = {
      barcode: `MANUAL-${Date.now()}`,
      productName: productName,
      price: Math.round(parseFloat(manualPrice) * 100),
      retailer: selectedRetailer,
      timestamp: new Date(),
      verified: false,
    };

    setScannedProducts([...scannedProducts, newProduct]);
    setStarsEarned(starsEarned + 1);
    setManualPrice('');
    setShowManualEntry(false);
    toast.success(`✓ Price added for ${productName}`);
  };

  // Submit all scanned products
  const handleSubmitPrices = async () => {
    if (scannedProducts.length === 0) {
      toast.error('No products to submit');
      return;
    }

    try {
      // In production, call tRPC mutation to save prices
      // await trpc.scanner.submitPrices.useMutation({
      //   products: scannedProducts,
      //   userId: user?.id,
      // });

      toast.success(`✓ Submitted ${scannedProducts.length} prices! +${starsEarned} ⭐`);
      setScannedProducts([]);
      setStarsEarned(0);
    } catch (error) {
      toast.error('Failed to submit prices');
    }
  };

  // Remove scanned product
  const removeProduct = (index: number) => {
    setScannedProducts(scannedProducts.filter((_, i) => i !== index));
    setStarsEarned(Math.max(0, starsEarned - 1));
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-border p-4">
        <h1 className="text-2xl font-bold text-foreground mb-1">Scan Prices</h1>
        <p className="text-sm text-muted-foreground">
          Earn ⭐ stars by scanning products and submitting prices
        </p>
      </div>

      {/* Stars Earned */}
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Stars This Session</p>
            <p className="text-3xl font-bold text-primary">{starsEarned} ⭐</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Your Tier</p>
            <p className="text-lg font-bold text-secondary">Rookie</p>
          </div>
        </div>
      </div>

      {/* Scanner Section */}
      {!isScanning ? (
        <div className="p-4 space-y-3">
          <Button
            onClick={startCamera}
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-lg flex items-center justify-center gap-2"
          >
            <Camera className="w-6 h-6" />
            Start Camera Scanner
          </Button>

          <Button
            onClick={() => fileInputRef.current?.click()}
            variant="outline"
            className="w-full border-2 border-border py-6 font-bold rounded-lg flex items-center justify-center gap-2"
          >
            <Upload className="w-6 h-6" />
            Upload Receipt Image
          </Button>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                toast.success('Receipt uploaded! Processing...');
                // In production, send to OCR service
              }
            }}
          />
        </div>
      ) : (
        <div className="p-4 space-y-3">
          {/* Video Feed */}
          <div className="relative bg-black rounded-lg overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-80 object-cover"
            />
            <canvas ref={canvasRef} className="hidden" width={640} height={480} />

            {/* Scanning Guide */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-64 h-32 border-2 border-primary rounded-lg opacity-50" />
            </div>

            {/* Close Button */}
            <button
              onClick={stopCamera}
              className="absolute top-3 right-3 bg-red-600 hover:bg-red-700 text-white p-2 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Capture & Manual Entry Buttons */}
          <div className="flex gap-2">
            <Button
              onClick={captureBarcode}
              className="flex-1 bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg"
            >
              <Camera className="w-5 h-5 mr-2" />
              Capture Barcode
            </Button>
            <Button
              onClick={() => setShowManualEntry(!showManualEntry)}
              variant="outline"
              className="flex-1 border-2 border-border font-bold py-3 rounded-lg"
            >
              Manual Entry
            </Button>
          </div>

          {/* Manual Entry Form */}
          {showManualEntry && (
            <Card className="p-4 border-border">
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-semibold text-foreground">Product Name</label>
                  <input
                    type="text"
                    placeholder="e.g., Coca-Cola 2L"
                    className="w-full px-3 py-2 border border-border rounded-lg text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="text-sm font-semibold text-foreground">Price (R)</label>
                  <input
                    type="number"
                    value={manualPrice}
                    onChange={(e) => setManualPrice(e.target.value)}
                    placeholder="0.00"
                    step="0.01"
                    className="w-full px-3 py-2 border border-border rounded-lg text-sm mt-1"
                  />
                </div>

                <div>
                  <label className="text-sm font-semibold text-foreground">Retailer</label>
                  <select
                    value={selectedRetailer}
                    onChange={(e) => setSelectedRetailer(e.target.value)}
                    className="w-full px-3 py-2 border border-border rounded-lg text-sm mt-1"
                  >
                    {retailers.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </div>

                <Button
                  onClick={() => handleManualEntry('Product')}
                  className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold"
                >
                  Add Price
                </Button>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Scanned Products List */}
      {scannedProducts.length > 0 && (
        <div className="p-4">
          <h2 className="text-lg font-bold text-foreground mb-3">
            Scanned Products ({scannedProducts.length})
          </h2>

          <div className="space-y-2 mb-4">
            {scannedProducts.map((product, index) => (
              <Card key={index} className="p-3 border-border flex items-center justify-between">
                <div className="flex-1">
                  <p className="font-semibold text-foreground text-sm">{product.productName}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className="bg-secondary text-white text-xs">{product.retailer}</Badge>
                    <span className="text-sm font-bold text-primary">
                      R{(product.price / 100).toFixed(2)}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => removeProduct(index)}
                  className="text-red-600 hover:text-red-700 p-2"
                >
                  <X className="w-5 h-5" />
                </button>
              </Card>
            ))}
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmitPrices}
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
          >
            <Check className="w-5 h-5" />
            Submit {scannedProducts.length} Prices
          </Button>
        </div>
      )}

      {/* Info Section */}
      <div className="p-4 bg-muted/30 border-t border-border mt-4">
        <div className="flex gap-2 mb-3">
          <AlertCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-foreground text-sm mb-1">How to Earn Stars</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Scan a barcode: +1 ⭐</li>
              <li>• Submit a receipt: +5 ⭐</li>
              <li>• Accurate price verified: +2 ⭐</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
