import { useState } from 'react';
import { Share2, Copy, MessageCircle, Mail, Link2, Trophy, Users, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';

export default function ReferralPage() {
  const [copied, setCopied] = useState(false);
  const referralCode = 'MZANSI2024'; // In production: fetch from user data
  const referralLink = `https://mzansispec.app?ref=${referralCode}`;

  const stats = [
    { label: 'Friends Invited', value: '5', icon: '👥' },
    { label: 'Stars Earned', value: '250', icon: '⭐' },
    { label: 'Rank', value: 'Chief', icon: '🏅' },
  ];

  const bonuses = [
    { action: 'Friend signs up', stars: 50, icon: '📱' },
    { action: 'Friend scans product', stars: 25, icon: '📸' },
    { action: 'Friend uploads receipt', stars: 50, icon: '🧾' },
    { action: 'Friend reaches Chief tier', stars: 100, icon: '👑' },
  ];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    toast.success('Referral code copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast.success('Referral link copied!');
  };

  const shareOnWhatsApp = () => {
    const message = `🔥 Hey! I'm saving BIG on groceries with Mzansi Specials! 💰\n\nUse my referral code: ${referralCode}\n\nEarn 50 bonus ⭐ stars just for signing up!\n\nDownload now: ${referralLink}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  const shareOnSMS = () => {
    const message = `Mzansi Specials: Save on groceries! Use code ${referralCode} to earn 50 bonus stars. ${referralLink}`;
    window.open(`sms:?body=${encodeURIComponent(message)}`, '_blank');
  };

  const shareOnEmail = () => {
    const subject = 'Join me on Mzansi Specials - Save on Groceries!';
    const body = `Hi there!\n\nI'm saving big on groceries with Mzansi Specials and want you to join too!\n\nUse my referral code: ${referralCode}\n\nYou'll earn 50 bonus stars just for signing up!\n\nStart saving today: ${referralLink}`;
    window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-secondary via-primary to-accent text-white p-6 rounded-b-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-black">🎁 Referral Program</h1>
            <p className="text-sm opacity-90">Earn stars by inviting friends</p>
          </div>
          <Gift className="w-10 h-10 opacity-50" />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 p-4">
        {stats.map((stat, idx) => (
          <Card key={idx} className="p-4 text-center border-border">
            <div className="text-2xl mb-1">{stat.icon}</div>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
            <p className="text-lg font-bold text-primary">{stat.value}</p>
          </Card>
        ))}
      </div>

      {/* Referral Code Section */}
      <div className="px-4 mb-6">
        <Card className="p-6 border-2 border-primary/30 bg-primary/5">
          <h2 className="text-lg font-bold text-foreground mb-4">Your Referral Code</h2>

          <div className="bg-white border-2 border-primary rounded-lg p-4 mb-4 text-center">
            <p className="text-xs text-muted-foreground mb-2">Share this code with friends</p>
            <p className="text-3xl font-black text-primary mb-2">{referralCode}</p>
            <p className="text-xs text-muted-foreground">Earn 50 ⭐ per referral</p>
          </div>

          <Button
            onClick={handleCopyCode}
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
          >
            <Copy className="w-4 h-4" />
            {copied ? 'Copied!' : 'Copy Code'}
          </Button>
        </Card>
      </div>

      {/* Share Options */}
      <div className="px-4 mb-6">
        <h2 className="text-lg font-bold text-foreground mb-3">Share Your Code</h2>

        <div className="space-y-2">
          <Button
            onClick={shareOnWhatsApp}
            className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            Share on WhatsApp
          </Button>

          <Button
            onClick={shareOnSMS}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
          >
            <Share2 className="w-5 h-5" />
            Share via SMS
          </Button>

          <Button
            onClick={shareOnEmail}
            className="w-full bg-purple-500 hover:bg-purple-600 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
          >
            <Mail className="w-5 h-5" />
            Share via Email
          </Button>

          <Button
            onClick={handleCopyLink}
            className="w-full bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
          >
            <Link2 className="w-5 h-5" />
            Copy Referral Link
          </Button>
        </div>
      </div>

      {/* Bonus Breakdown */}
      <div className="px-4 mb-6">
        <h2 className="text-lg font-bold text-foreground mb-3">How You Earn Stars</h2>

        <div className="space-y-2">
          {bonuses.map((bonus, idx) => (
            <Card key={idx} className="p-4 border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{bonus.icon}</span>
                <span className="text-sm font-semibold text-foreground">{bonus.action}</span>
              </div>
              <span className="text-lg font-bold text-secondary">+{bonus.stars}⭐</span>
            </Card>
          ))}
        </div>
      </div>

      {/* Leaderboard Preview */}
      <div className="px-4 mb-6">
        <Card className="p-6 border-border">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-foreground">Top Referrers</h2>
            <Trophy className="w-5 h-5 text-accent" />
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border-2 border-yellow-200">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🥇</span>
                <div>
                  <p className="font-bold text-foreground">You</p>
                  <p className="text-xs text-muted-foreground">Chief Recruiter</p>
                </div>
              </div>
              <span className="font-bold text-yellow-600">250⭐</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🥈</span>
                <div>
                  <p className="font-bold text-foreground">Sarah M.</p>
                  <p className="text-xs text-muted-foreground">Chief Recruiter</p>
                </div>
              </div>
              <span className="font-bold text-gray-600">220⭐</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🥉</span>
                <div>
                  <p className="font-bold text-foreground">James K.</p>
                  <p className="text-xs text-muted-foreground">Rookie Referrer</p>
                </div>
              </div>
              <span className="font-bold text-orange-600">180⭐</span>
            </div>
          </div>

          <Button
            className="w-full mt-4 bg-primary hover:bg-primary/90 text-white font-bold py-2 rounded-lg"
          >
            View Full Leaderboard
          </Button>
        </Card>
      </div>

      {/* Info Section */}
      <div className="px-4 mb-6">
        <Card className="p-4 border-border bg-accent/10">
          <h3 className="font-bold text-foreground mb-2">💡 Referral Tips</h3>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>✓ Share with friends who love saving money</li>
            <li>✓ Post your code on social media</li>
            <li>✓ Earn more when friends scan & upload receipts</li>
            <li>✓ Unlock special badges and achievements</li>
            <li>✓ Reach President tier for exclusive rewards</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
