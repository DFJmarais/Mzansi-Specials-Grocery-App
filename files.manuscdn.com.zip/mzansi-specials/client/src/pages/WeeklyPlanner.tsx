import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';
import { ArrowLeft, Plus, Calendar, ShoppingCart, Clock } from 'lucide-react';
import { useLocation } from 'wouter';

/**
 * Weekly Grocery Planner Page
 * Plan meals for the week, generate shopping lists, and track budget
 */

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const MEAL_TYPES = ['breakfast', 'lunch', 'dinner', 'snack'];

const SOUTH_AFRICAN_MEALS = {
  breakfast: [
    'Pap with milk and sugar',
    'Boerewors and eggs',
    'Vetkoek with jam',
    'Toast with peanut butter',
    'Porridge with fruit',
    'Eggs and toast',
    'Cereal with milk',
  ],
  lunch: [
    'Bunny chow',
    'Potjiekos',
    'Bobotie',
    'Boerewors with pap',
    'Chicken and rice',
    'Fish and chips',
    'Sarmies (sandwiches)',
    'Koeksister',
  ],
  dinner: [
    'Braai (grilled meat)',
    'Steak and potatoes',
    'Chicken curry',
    'Spaghetti bolognese',
    'Roasted chicken with vegetables',
    'Lamb chops',
    'Fish with lemon',
    'Beef stew',
  ],
  snack: [
    'Biltong',
    'Droëwors',
    'Peanuts',
    'Fruit',
    'Yogurt',
    'Cheese and crackers',
    'Chips',
  ],
};

export default function WeeklyPlanner() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [weeklyPlan, setWeeklyPlan] = useState<Record<string, Record<string, string>>>({});
  const [budget, setBudget] = useState<number>(500);
  const [planName, setPlanName] = useState('Weekly Meal Plan');
  const [showMealSelector, setShowMealSelector] = useState<{ day: string; type: string } | null>(null);
  const [selectedDays, setSelectedDays] = useState<Set<string>>(new Set(DAYS_OF_WEEK));

  const toggleDay = (day: string) => {
    const newDays = new Set(selectedDays);
    if (newDays.has(day)) {
      newDays.delete(day);
    } else {
      newDays.add(day);
    }
    setSelectedDays(newDays);
  };

  const toggleAllDays = () => {
    if (selectedDays.size === DAYS_OF_WEEK.length) {
      setSelectedDays(new Set());
    } else {
      setSelectedDays(new Set(DAYS_OF_WEEK));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <h2 className="text-2xl font-bold text-foreground mb-4">Please Log In</h2>
          <p className="text-muted-foreground mb-6">You need to be logged in to use the weekly planner.</p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="w-full bg-primary hover:bg-primary/90"
          >
            Log In
          </Button>
        </Card>
      </div>
    );
  }

  const handleSelectMeal = (day: string, mealType: string, meal: string) => {
    setWeeklyPlan((prev) => ({
      ...prev,
      [day]: {
        ...(prev[day] || {}),
        [mealType]: meal,
      },
    }));
    setShowMealSelector(null);
  };

  const handleGenerateShoppingList = () => {
    // Collect all unique ingredients from selected meals
    const ingredients = new Set<string>();
    Object.values(weeklyPlan).forEach((dayMeals) => {
      Object.values(dayMeals).forEach((meal: string) => {
        // Mock ingredient extraction - in production, this would come from meal database
        const mealIngredients = getMealIngredients(meal);
        mealIngredients.forEach((ing) => ingredients.add(ing));
      });
    });

    console.log('Generated shopping list:', Array.from(ingredients));
    alert(`Shopping list generated with ${ingredients.size} items!`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-gradient-to-r from-sidebar via-sidebar to-sidebar shadow-lg border-b-4 border-primary">
        <div className="container px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation('/')}
              className="p-2 hover:bg-primary/20 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-primary" />
            </button>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-primary drop-shadow-lg">📅 Weekly Meal Planner</h1>
              <p className="text-sm text-primary-foreground/80">Plan your meals and generate shopping lists</p>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container px-4 sm:px-6 lg:px-8 py-8">
        {/* Plan Info Card */}
        <Card className="p-6 mb-8 bg-gradient-to-r from-primary/10 to-accent/10 border-2 border-primary/20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="text-sm font-semibold text-foreground">Plan Name</label>
              <Input
                value={planName}
                onChange={(e) => setPlanName(e.target.value)}
                className="mt-2"
                placeholder="Enter plan name"
              />
            </div>
            <div>
              <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                💰 Weekly Budget (R)
              </label>
              <Input
                type="number"
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                className="mt-2"
                placeholder="Enter budget in Rand"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleGenerateShoppingList}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                disabled={Object.keys(weeklyPlan).length === 0}
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Generate Shopping List
              </Button>
            </div>
          </div>
        </Card>

        {/* Day Selection */}
        <Card className="p-6 mb-8 border-2 border-primary/20">
          <h3 className="text-lg font-bold text-foreground mb-4">📆 Select Days to Plan</h3>
          <div className="flex flex-wrap gap-3 mb-4">
            <Button
              onClick={toggleAllDays}
              variant={selectedDays.size === DAYS_OF_WEEK.length ? 'default' : 'outline'}
              className={selectedDays.size === DAYS_OF_WEEK.length ? 'bg-primary' : ''}
            >
              {selectedDays.size === DAYS_OF_WEEK.length ? '✓ All Days' : 'All Days'}
            </Button>
            {DAYS_OF_WEEK.map((day) => (
              <Button
                key={day}
                onClick={() => toggleDay(day)}
                variant={selectedDays.has(day) ? 'default' : 'outline'}
                className={selectedDays.has(day) ? 'bg-primary' : ''}
              >
                {selectedDays.has(day) ? '✓' : ''} {day.slice(0, 3)}
              </Button>
            ))}
          </div>
          <p className="text-sm text-muted-foreground">
            Planning for {selectedDays.size} day{selectedDays.size !== 1 ? 's' : ''}
          </p>
        </Card>

        {/* Weekly Meal Grid */}
        <div className="space-y-6">
          {DAYS_OF_WEEK.filter((day) => selectedDays.has(day)).map((day) => (
            <Card key={day} className="p-6 border-2 border-primary/20 hover:border-primary/40 transition-colors">
              <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-primary" />
                {day}
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {MEAL_TYPES.map((mealType) => {
                  const selectedMeal = weeklyPlan[day]?.[mealType];
                  return (
                    <div
                      key={mealType}
                      className="p-4 rounded-lg border-2 border-border hover:border-primary/50 transition-colors"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm font-semibold text-foreground capitalize">{mealType}</span>
                      </div>

                      {selectedMeal ? (
                        <div className="space-y-2">
                          <p className="text-sm text-foreground font-medium">{selectedMeal}</p>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setShowMealSelector({ day, type: mealType })}
                            className="w-full text-xs"
                          >
                            Change
                          </Button>
                        </div>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setShowMealSelector({ day, type: mealType })}
                          className="w-full text-xs"
                        >
                          <Plus className="w-3 h-3 mr-1" />
                          Add Meal
                        </Button>
                      )}
                    </div>
                  );
                })}
              </div>
            </Card>
          ))}
        </div>

        {/* Meal Selector Modal */}
        {showMealSelector && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-md max-h-96 overflow-y-auto">
              <div className="sticky top-0 bg-gradient-to-r from-primary to-accent p-4 text-white">
                <h3 className="font-bold text-lg">
                  Select {showMealSelector.type} for {showMealSelector.day}
                </h3>
              </div>

              <div className="p-4 space-y-2">
                {SOUTH_AFRICAN_MEALS[showMealSelector.type as keyof typeof SOUTH_AFRICAN_MEALS].map((meal) => (
                  <button
                    key={meal}
                    onClick={() =>
                      handleSelectMeal(showMealSelector.day, showMealSelector.type, meal)
                    }
                    className="w-full p-3 text-left rounded-lg border-2 border-border hover:border-primary hover:bg-primary/5 transition-all"
                  >
                    <p className="font-medium text-foreground">{meal}</p>
                  </button>
                ))}
              </div>

              <div className="p-4 border-t-2 border-border">
                <Button
                  variant="outline"
                  onClick={() => setShowMealSelector(null)}
                  className="w-full"
                >
                  Close
                </Button>
              </div>
            </Card>
          </div>
        )}

        {/* Summary */}
        {Object.keys(weeklyPlan).length > 0 && (
          <Card className="mt-8 p-6 bg-primary/5 border-2 border-primary/20">
            <h3 className="text-lg font-bold text-foreground mb-4">📊 Plan Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Total Meals Planned</p>
                <p className="text-2xl font-bold text-primary">
                  {Object.values(weeklyPlan).reduce((sum, day) => sum + Object.keys(day).length, 0)}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Days Selected</p>
                <p className="text-2xl font-bold text-primary">{selectedDays.size}/7</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Days Covered</p>
                <p className="text-2xl font-bold text-primary">{Object.keys(weeklyPlan).length}/{selectedDays.size}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Weekly Budget</p>
                <p className="text-2xl font-bold text-primary">R{budget}</p>
              </div>
            </div>
          </Card>
        )}
      </main>
    </div>
  );
}

/**
 * Mock function to get ingredients for a meal
 * In production, this would come from the meal database
 */
function getMealIngredients(meal: string): string[] {
  const mealIngredientsMap: Record<string, string[]> = {
    'Pap with milk and sugar': ['Maize meal', 'Milk', 'Sugar', 'Salt'],
    'Boerewors and eggs': ['Boerewors', 'Eggs', 'Oil'],
    'Bunny chow': ['Bread', 'Curry', 'Meat', 'Onions'],
    'Potjiekos': ['Beef', 'Potatoes', 'Carrots', 'Onions', 'Spices'],
    'Bobotie': ['Ground beef', 'Eggs', 'Bread', 'Milk', 'Spices'],
    'Braai (grilled meat)': ['Meat', 'Charcoal', 'Salt', 'Pepper'],
    'Steak and potatoes': ['Steak', 'Potatoes', 'Butter', 'Salt', 'Pepper'],
    'Chicken curry': ['Chicken', 'Curry powder', 'Coconut milk', 'Onions', 'Garlic'],
  };

  return mealIngredientsMap[meal] || ['Ingredients to be added'];
}
