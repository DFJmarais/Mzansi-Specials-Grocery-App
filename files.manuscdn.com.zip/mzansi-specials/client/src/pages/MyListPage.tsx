import { useState, useEffect } from 'react';
import { Trash2, Plus, Share2, Download, CheckCircle, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface ListItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  price: number;
  retailer: string;
  checked: boolean;
}

const UNITS = ['pcs', 'kg', 'g', 'L', 'ml', 'box', 'pack', 'dozen'];
const RETAILERS = ['Checkers', 'Pick n Pay', 'SPAR', 'Woolworths', 'OK Foods'];

export default function MyListPage() {
  const [listItems, setListItems] = useState<ListItem[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemQuantity, setNewItemQuantity] = useState(1);
  const [newItemUnit, setNewItemUnit] = useState('pcs');
  const [newItemPrice, setNewItemPrice] = useState(0);
  const [newItemRetailer, setNewItemRetailer] = useState('Checkers');
  const [isLoading, setIsLoading] = useState(true);

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('mzansi-shopping-list');
    if (saved) {
      try {
        setListItems(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load shopping list:', e);
        toast.error('Failed to load shopping list');
      }
    }
    setIsLoading(false);
  }, []);

  // Save to localStorage whenever list changes
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('mzansi-shopping-list', JSON.stringify(listItems));
    }
  }, [listItems, isLoading]);

  const addItem = () => {
    if (!newItemName.trim()) {
      toast.error('Please enter an item name');
      return;
    }

    const newItem: ListItem = {
      id: Date.now().toString(),
      name: newItemName,
      quantity: newItemQuantity,
      unit: newItemUnit,
      price: newItemPrice,
      retailer: newItemRetailer,
      checked: false,
    };

    setListItems([...listItems, newItem]);
    setNewItemName('');
    setNewItemQuantity(1);
    setNewItemPrice(0);
    toast.success(`${newItemName} added to your list!`);
  };

  const removeItem = (id: string) => {
    const item = listItems.find((i) => i.id === id);
    setListItems(listItems.filter((i) => i.id !== id));
    toast.success(`${item?.name} removed from your list`);
  };

  const toggleItem = (id: string) => {
    setListItems(
      listItems.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item))
    );
  };

  const updateItem = (id: string, updates: Partial<ListItem>) => {
    setListItems(
      listItems.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const clearCompleted = () => {
    const completed = listItems.filter((i) => i.checked);
    setListItems(listItems.filter((i) => !i.checked));
    toast.success(`${completed.length} items removed`);
  };

  const clearAll = () => {
    if (window.confirm('Are you sure you want to clear your entire shopping list?')) {
      setListItems([]);
      toast.success('Shopping list cleared');
    }
  };

  const totalItems = listItems.length;
  const checkedItems = listItems.filter((i) => i.checked).length;
  const totalPrice = listItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const potentialSavings = totalPrice * 0.20;

  const groupedByRetailer = listItems.reduce(
    (acc, item) => {
      if (!acc[item.retailer]) {
        acc[item.retailer] = [];
      }
      acc[item.retailer].push(item);
      return acc;
    },
    {} as Record<string, ListItem[]>
  );

  const handleShare = () => {
    const listText = listItems
      .map((item) => `${item.quantity}${item.unit} ${item.name} (R${item.price.toFixed(2)})`)
      .join('\n');

    const message = `My Mzansi Specials Shopping List:\n\n${listText}\n\nTotal: R${totalPrice.toFixed(2)}\nPotential Savings: R${potentialSavings.toFixed(2)}`;

    if (navigator.share) {
      navigator.share({
        title: 'My Shopping List',
        text: message,
      });
    } else {
      navigator.clipboard.writeText(message);
      toast.success('List copied to clipboard!');
    }
  };

  const handleDownload = () => {
    const listText = listItems
      .map((item) => `${item.quantity}${item.unit} ${item.name} (R${item.price.toFixed(2)}) @ ${item.retailer}`)
      .join('\n');

    const content = `MZANSI SPECIALS - SHOPPING LIST\n${'='.repeat(40)}\n\n${listText}\n\n${'='.repeat(40)}\nTotal Items: ${totalItems}\nTotal Price: R${totalPrice.toFixed(2)}\nPotential Savings: R${potentialSavings.toFixed(2)}\n\nGenerated: ${new Date().toLocaleString()}`;

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', 'shopping-list.txt');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    toast.success('List downloaded!');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center pb-24">
        <div className="text-center">
          <ShoppingCart className="w-12 h-12 text-primary/30 mx-auto mb-4 animate-pulse" />
          <p className="text-muted-foreground">Loading your shopping list...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary via-secondary to-accent text-white p-6 rounded-b-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-black">📝 My Shopping List</h1>
            <p className="text-sm opacity-90">Build and manage your grocery shopping list</p>
          </div>
          <ShoppingCart className="w-10 h-10 opacity-50" />
        </div>
      </div>

      {/* Stats */}
      {listItems.length > 0 && (
        <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="p-3 border-border text-center">
            <div className="text-2xl font-bold text-primary">{totalItems}</div>
            <div className="text-xs text-muted-foreground font-semibold">Items</div>
          </Card>
          <Card className="p-3 border-border text-center">
            <div className="text-2xl font-bold text-secondary">{checkedItems}</div>
            <div className="text-xs text-muted-foreground font-semibold">Checked</div>
          </Card>
          <Card className="p-3 border-border text-center">
            <div className="text-2xl font-bold text-accent">R{totalPrice.toFixed(2)}</div>
            <div className="text-xs text-muted-foreground font-semibold">Total</div>
          </Card>
          <Card className="p-3 border-border text-center">
            <div className="text-2xl font-bold text-green-600">R{potentialSavings.toFixed(2)}</div>
            <div className="text-xs text-muted-foreground font-semibold">Savings</div>
          </Card>
        </div>
      )}

      {/* Add Item Form */}
      <div className="p-4 space-y-3">
        <h3 className="font-bold text-foreground">Add New Item</h3>
        <div className="space-y-3">
          <input
            type="text"
            placeholder="Item name (e.g., Milk, Bread)"
            value={newItemName}
            onChange={(e) => setNewItemName(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addItem()}
            className="w-full px-4 py-2 border-2 border-border rounded-lg focus:outline-none focus:border-primary"
          />
          <div className="grid grid-cols-3 gap-2">
            <input
              type="number"
              placeholder="Qty"
              min="1"
              value={newItemQuantity}
              onChange={(e) => setNewItemQuantity(parseInt(e.target.value) || 1)}
              className="px-3 py-2 border-2 border-border rounded-lg focus:outline-none focus:border-primary"
            />
            <select
              value={newItemUnit}
              onChange={(e) => setNewItemUnit(e.target.value)}
              className="px-3 py-2 border-2 border-border rounded-lg focus:outline-none focus:border-primary"
            >
              {UNITS.map((unit) => (
                <option key={unit} value={unit}>
                  {unit}
                </option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Price"
              min="0"
              step="0.01"
              value={newItemPrice}
              onChange={(e) => setNewItemPrice(parseFloat(e.target.value) || 0)}
              className="px-3 py-2 border-2 border-border rounded-lg focus:outline-none focus:border-primary"
            />
          </div>
          <select
            value={newItemRetailer}
            onChange={(e) => setNewItemRetailer(e.target.value)}
            className="w-full px-4 py-2 border-2 border-border rounded-lg focus:outline-none focus:border-primary"
          >
            {RETAILERS.map((retailer) => (
              <option key={retailer} value={retailer}>
                {retailer}
              </option>
            ))}
          </select>
          <Button
            onClick={addItem}
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-2 rounded-lg flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Item
          </Button>
        </div>
      </div>

      {/* Shopping List */}
      <div className="p-4">
        {listItems.length === 0 ? (
          <Card className="p-8 border-border text-center">
            <ShoppingCart className="w-12 h-12 text-primary/30 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-foreground mb-2">Your list is empty</h3>
            <p className="text-muted-foreground">Add items from specials or manually to get started</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {Object.entries(groupedByRetailer).map(([retailer, items]) => (
              <div key={retailer}>
                <h4 className="font-bold text-foreground mb-2 text-sm">{retailer}</h4>
                <div className="space-y-2">
                  {items.map((item) => (
                    <Card
                      key={item.id}
                      className={`p-3 border-border flex items-center justify-between ${
                        item.checked ? 'bg-muted/50' : ''
                      }`}
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <button
                          onClick={() => toggleItem(item.id)}
                          className="flex-shrink-0"
                        >
                          <CheckCircle
                            className={`w-5 h-5 ${
                              item.checked ? 'text-green-500 fill-green-500' : 'text-border'
                            }`}
                          />
                        </button>
                        <div className="flex-1">
                          <p
                            className={`font-semibold ${
                              item.checked
                                ? 'line-through text-muted-foreground'
                                : 'text-foreground'
                            }`}
                          >
                            {item.quantity}
                            {item.unit} {item.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            R{(item.price * item.quantity).toFixed(2)}
                          </p>
                        </div>
                      </div>
                      <Button
                        onClick={() => removeItem(item.id)}
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Action Buttons */}
      {listItems.length > 0 && (
        <div className="p-4 space-y-2 fixed bottom-20 left-0 right-0 bg-background border-t border-border">
          <div className="flex gap-2">
            <Button
              onClick={handleShare}
              className="flex-1 bg-secondary hover:bg-secondary/90 text-white font-bold py-2 rounded-lg flex items-center justify-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              Share
            </Button>
            <Button
              onClick={handleDownload}
              className="flex-1 bg-accent hover:bg-accent/90 text-white font-bold py-2 rounded-lg flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              Download
            </Button>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={clearCompleted}
              variant="outline"
              className="flex-1 border-border text-foreground py-2 rounded-lg"
            >
              Clear Completed
            </Button>
            <Button
              onClick={clearAll}
              variant="outline"
              className="flex-1 border-red-300 text-red-600 hover:bg-red-50 py-2 rounded-lg"
            >
              Clear All
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
