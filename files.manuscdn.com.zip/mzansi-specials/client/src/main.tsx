import { trpc } from "@/lib/trpc";
import { UNAUTHED_ERR_MSG } from '@shared/const';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink, TRPCClientError } from "@trpc/client";
import { createRoot } from "react-dom/client";
import superjson from "superjson";
import App from "./App";
import { getLoginUrl } from "./const";
import { AccessibilityProvider } from "./contexts/AccessibilityContext";
import { WishlistProvider } from "./contexts/WishlistContext";
import { MultiLanguageProvider } from "./contexts/MultiLanguageContext";
import { ComparisonHistoryProvider } from "./contexts/ComparisonHistoryContext";
import { OfflineModeProvider } from "./contexts/OfflineModeContext";
import { CartProvider } from "./contexts/CartContext";
import "./index.css";
const queryClient = new QueryClient();

const redirectToLoginIfUnauthorized = (error: unknown) => {
  if (!(error instanceof TRPCClientError)) return;
  if (typeof window === "undefined") return;

  const isUnauthorized = error.message === UNAUTHED_ERR_MSG;

  if (!isUnauthorized) return;

  window.location.href = getLoginUrl();
};

queryClient.getQueryCache().subscribe(event => {
  if (event.type === "updated" && event.action.type === "error") {
    const error = event.query.state.error;
    redirectToLoginIfUnauthorized(error);
    console.error("[API Query Error]", error);
  }
});

queryClient.getMutationCache().subscribe(event => {
  if (event.type === "updated" && event.action.type === "error") {
    const error = event.mutation.state.error;
    redirectToLoginIfUnauthorized(error);
    console.error("[API Mutation Error]", error);
  }
});

const trpcClient = trpc.createClient({
  links: [
    httpBatchLink({
      url: "/api/trpc",
      transformer: superjson,
      fetch(input, init) {
        return globalThis.fetch(input, {
          ...(init ?? {}),
          credentials: "include",
        });
      },
    }),
  ],
});

createRoot(document.getElementById("root")!).render(
  <AccessibilityProvider>
    <WishlistProvider>
      <MultiLanguageProvider>
        <ComparisonHistoryProvider>
          <OfflineModeProvider>
            <CartProvider>
              <trpc.Provider client={trpcClient} queryClient={queryClient}>
                <QueryClientProvider client={queryClient}>
                  <App />
                </QueryClientProvider>
              </trpc.Provider>
            </CartProvider>
          </OfflineModeProvider>
        </ComparisonHistoryProvider>
      </MultiLanguageProvider>
    </WishlistProvider>
  </AccessibilityProvider>
);
