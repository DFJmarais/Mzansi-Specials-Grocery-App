import { describe, it, expect } from 'vitest';
import { t, translations, LANGUAGES, getAvailableLanguages } from './translations';

describe('Multilingual Support', () => {
  describe('translations object', () => {
    it('should have all 11 languages', () => {
      const languages = Object.keys(translations);
      expect(languages).toHaveLength(11);
      expect(languages).toContain('en');
      expect(languages).toContain('af');
      expect(languages).toContain('zu');
      expect(languages).toContain('xh');
      expect(languages).toContain('st');
      expect(languages).toContain('tn');
      expect(languages).toContain('nr');
      expect(languages).toContain('ve');
      expect(languages).toContain('ts');
      expect(languages).toContain('ss');
      expect(languages).toContain('nso');
    });

    it('should have language names for all languages', () => {
      expect(LANGUAGES).toHaveProperty('en', 'English');
      expect(LANGUAGES).toHaveProperty('af', 'Afrikaans');
      expect(LANGUAGES).toHaveProperty('zu', 'isiZulu');
      expect(LANGUAGES).toHaveProperty('xh', 'isiXhosa');
      expect(LANGUAGES).toHaveProperty('st', 'Sesotho');
      expect(LANGUAGES).toHaveProperty('tn', 'Setswana');
      expect(LANGUAGES).toHaveProperty('nr', 'isiNdebele');
      expect(LANGUAGES).toHaveProperty('ve', 'Tshivenda');
      expect(LANGUAGES).toHaveProperty('ts', 'Xitsonga');
      expect(LANGUAGES).toHaveProperty('ss', 'siSwati');
      expect(LANGUAGES).toHaveProperty('nso', 'Sepedi');
    });

    it('should have consistent keys across all languages', () => {
      const englishKeys = Object.keys(translations.en).sort();
      
      Object.entries(translations).forEach(([lang, langTranslations]) => {
        if (lang !== 'en') {
          const langKeys = Object.keys(langTranslations).sort();
          expect(langKeys).toEqual(englishKeys);
        }
      });
    });

    it('should have all required UI keys in English', () => {
      const requiredKeys = [
        'app.title',
        'app.tagline',
        'nav.home',
        'nav.browse',
        'nav.shopping_list',
        'header.search_placeholder',
        'header.change_language',
        'home.hero_title',
        'browse.title',
        'product.details',
        'shopping_list.title',
        'notifications.title',
        'alerts.title',
        'common.search',
        'common.filter',
        'common.loading',
        'common.error',
      ];

      requiredKeys.forEach(key => {
        expect(translations.en).toHaveProperty(key);
        expect(translations.en[key]).toBeTruthy();
      });
    });
  });

  describe('t() function', () => {
    it('should return English translation by default', () => {
      expect(t('app.title')).toBe('Mzansi Specials');
      expect(t('app.tagline')).toBe('Save Big Today');
    });

    it('should return translation for specified language', () => {
      expect(t('app.title', 'af')).toBe('Mzansi Spesiale');
      expect(t('app.title', 'zu')).toBe('Mzansi Specials');
      expect(t('app.tagline', 'af')).toBe('Spaar Groot Vandag');
    });

    it('should return key if translation not found', () => {
      expect(t('non.existent.key', 'en')).toBe('non.existent.key');
    });

    it('should fallback to English if language not found', () => {
      expect(t('app.title', 'invalid' as any)).toBe('Mzansi Specials');
    });

    it('should translate all navigation items', () => {
      const navItems = ['nav.home', 'nav.browse', 'nav.shopping_list', 'nav.notifications'];
      
      navItems.forEach(item => {
        expect(t(item, 'en')).toBeTruthy();
        expect(t(item, 'af')).toBeTruthy();
        expect(t(item, 'zu')).toBeTruthy();
      });
    });

    it('should translate all common action buttons', () => {
      const commonItems = ['common.search', 'common.filter', 'common.save', 'common.cancel'];
      
      commonItems.forEach(item => {
        expect(t(item, 'en')).toBeTruthy();
        expect(t(item, 'af')).toBeTruthy();
      });
    });
  });

  describe('getAvailableLanguages()', () => {
    it('should return array of all available languages', () => {
      const languages = getAvailableLanguages();
      expect(languages).toHaveLength(11);
    });

    it('should have correct structure for each language', () => {
      const languages = getAvailableLanguages();
      
      languages.forEach(lang => {
        expect(lang).toHaveProperty('code');
        expect(lang).toHaveProperty('name');
        expect(typeof lang.code).toBe('string');
        expect(typeof lang.name).toBe('string');
      });
    });

    it('should include all 11 official South African languages', () => {
      const languages = getAvailableLanguages();
      const codes = languages.map(l => l.code);
      
      expect(codes).toContain('en');
      expect(codes).toContain('af');
      expect(codes).toContain('zu');
      expect(codes).toContain('xh');
      expect(codes).toContain('st');
      expect(codes).toContain('tn');
      expect(codes).toContain('nr');
      expect(codes).toContain('ve');
      expect(codes).toContain('ts');
      expect(codes).toContain('ss');
      expect(codes).toContain('nso');
    });
  });

  describe('Language-specific translations', () => {
    it('should have Afrikaans translations for key phrases', () => {
      expect(t('app.title', 'af')).toBe('Mzansi Spesiale');
      expect(t('header.change_language', 'af')).toBe('VERANDER TAAL');
      expect(t('common.search', 'af')).toBe('Soek');
    });

    it('should have Zulu translations for key phrases', () => {
      expect(t('app.title', 'zu')).toBe('Mzansi Specials');
      expect(t('header.change_language', 'zu')).toBe('SHINTSHA ULIMI');
      expect(t('common.search', 'zu')).toBe('Sesha');
    });

    it('should have Xhosa translations for key phrases', () => {
      expect(t('app.title', 'xh')).toBe('Mzansi Specials');
      expect(t('header.change_language', 'xh')).toBe('SHINTSHA ULWIMI');
      expect(t('common.search', 'xh')).toBe('Khangela');
    });

    it('should have Sotho translations for key phrases', () => {
      expect(t('app.title', 'st')).toBe('Mzansi Specials');
      expect(t('header.change_language', 'st')).toBe('FETOLA PUO');
      expect(t('common.search', 'st')).toBe('Batla');
    });

    it('should have Tswana translations for key phrases', () => {
      expect(t('app.title', 'tn')).toBe('Mzansi Specials');
      expect(t('header.change_language', 'tn')).toBe('FETOLA PUO');
      expect(t('common.search', 'tn')).toBe('Batla');
    });
  });

  describe('Browse section translations', () => {
    it('should have browse section translations in all languages', () => {
      const browseKeys = [
        'browse.title',
        'browse.filter_by_category',
        'browse.in_stock',
        'browse.out_of_stock',
      ];

      browseKeys.forEach(key => {
        expect(t(key, 'en')).toBeTruthy();
        expect(t(key, 'af')).toBeTruthy();
        expect(t(key, 'zu')).toBeTruthy();
      });
    });
  });

  describe('Product detail translations', () => {
    it('should have product detail translations in all languages', () => {
      const productKeys = [
        'product.details',
        'product.best_price',
        'product.add_to_list',
        'product.reviews',
      ];

      productKeys.forEach(key => {
        expect(t(key, 'en')).toBeTruthy();
        expect(t(key, 'af')).toBeTruthy();
        expect(t(key, 'zu')).toBeTruthy();
      });
    });
  });

  describe('Shopping list translations', () => {
    it('should have shopping list translations in all languages', () => {
      const shoppingKeys = [
        'shopping_list.title',
        'shopping_list.smart_cart',
        'shopping_list.total_savings',
        'shopping_list.checkout',
      ];

      shoppingKeys.forEach(key => {
        expect(t(key, 'en')).toBeTruthy();
        expect(t(key, 'af')).toBeTruthy();
        expect(t(key, 'zu')).toBeTruthy();
      });
    });
  });
});
