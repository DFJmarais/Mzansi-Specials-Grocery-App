import { Capacitor } from '@capacitor/core';

export interface IAPProduct {
  id: string;
  title: string;
  description: string;
  price: string;
  currency: string;
  priceMicros: number;
}

export interface IAPTransaction {
  transactionId: string;
  productId: string;
  purchaseTime: number;
  purchaseState: string;
  orderId?: string;
}

class IAPService {
  private isInitialized = false;
  private platform: 'ios' | 'android' | 'web' = 'web';

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    if (!Capacitor.isNativePlatform()) {
      console.log('Running on web platform - IAP not available');
      this.platform = 'web';
      return;
    }

    try {
      this.platform = Capacitor.getPlatform() as 'ios' | 'android';
      console.log(`Initializing IAP for ${this.platform}`);
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize IAP:', error);
    }
  }

  async getProducts(productIds: string[]): Promise<IAPProduct[]> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    // For now, return mock products
    // In production, this would call native IAP APIs
    return this.getMockProducts(productIds);
  }

  async requestPurchase(productId: string): Promise<IAPTransaction | null> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    if (this.platform === 'web') {
      // Simulate web purchase
      return {
        transactionId: `web_${Date.now()}`,
        productId,
        purchaseTime: Date.now(),
        purchaseState: 'purchased',
      };
    }

    try {
      // Call native purchase method
      // This will be implemented in native code for iOS/Android
      const result = await (window as any).Capacitor?.Plugins?.InAppPurchase?.purchase?.({
        productId,
      });
      return result as IAPTransaction;
    } catch (error) {
      console.error('Purchase request failed:', error);
      return null;
    }
  }

  async restorePurchases(): Promise<IAPTransaction[]> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    if (this.platform === 'web') {
      return [];
    }

    try {
      const result = await (window as any).Capacitor?.Plugins?.InAppPurchase?.restorePurchases?.();
      return result?.purchases || [];
    } catch (error) {
      console.error('Failed to restore purchases:', error);
      return [];
    }
  }

  async consumePurchase(productId: string): Promise<boolean> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    if (this.platform === 'web') {
      return true;
    }

    try {
      await (window as any).Capacitor?.Plugins?.InAppPurchase?.consume?.({
        productId,
      });
      return true;
    } catch (error) {
      console.error('Failed to consume purchase:', error);
      return false;
    }
  }

  private getMockProducts(productIds: string[]): IAPProduct[] {
    const mockProducts: Record<string, IAPProduct> = {
      'com.mzansispecials.plus': {
        id: 'com.mzansispecials.plus',
        title: 'Mzansi Specials Plus',
        description: 'Monthly subscription for full access to all products and features',
        price: 'R19.99',
        currency: 'ZAR',
        priceMicros: 1999000,
      },
      'com.mzansispecials.pro': {
        id: 'com.mzansispecials.pro',
        title: 'Mzansi Specials Pro',
        description: 'Premium subscription with advanced features and priority support',
        price: 'R49.99',
        currency: 'ZAR',
        priceMicros: 4999000,
      },
    };

    return productIds
      .map((id) => mockProducts[id])
      .filter((product) => product !== undefined);
  }

  isNativePlatform(): boolean {
    return this.platform !== 'web';
  }

  getPlatform(): 'ios' | 'android' | 'web' {
    return this.platform;
  }
}

export const iapService = new IAPService();
