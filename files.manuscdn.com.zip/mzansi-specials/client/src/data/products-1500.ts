/**
 * Complete Grocery Product Database - 1,500 Products
 * Comprehensive catalog covering all grocery store categories
 * South African pricing and retailers
 */

import { getProductImage } from './product-images';

export interface Product {
  id: number;
  name: string;
  category: string;
  subcategory: string;
  unit: string;
  image?: string;
  prices: {
    store: string;
    price: number;
    inStock: boolean;
    special?: boolean;
    discount?: number;
  }[];
  lastUpdated?: string;
}

const STORES = ['Spar', 'Pick n Pay', 'Checkers', 'Woolworths', 'OK Foods', 'Food Lovers'];

const generatePrices = (basePrice: number) => {
  return STORES.map((store) => {
    const variance = (Math.random() - 0.5) * 0.3;
    const price = Math.round((basePrice * (1 + variance)) * 100) / 100;
    const special = Math.random() > 0.7;
    const discount = special ? Math.floor(Math.random() * 30) + 5 : undefined;
    const inStock = Math.random() > 0.15;
    return { store, price, inStock, special, discount };
  });
};

const getLastUpdated = () => {
  const hours = Math.floor(Math.random() * 6);
  return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
};

// Generate 1,500 products across all categories
export const PRODUCTS_1500: Product[] = [
  // ===== DAIRY & EGGS (180 products) =====
  // Milk (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 1,
    name: ['Full Cream', 'Skimmed', 'Semi-Skimmed', 'Long Life', 'Lactose Free', 'A2'][i % 6] + ' Milk ' + [500, 1000, 2000][Math.floor(i / 6) % 3] + 'ml',
    category: 'Dairy',
    subcategory: 'Milk',
    unit: 'ml',
    image: getProductImage('Dairy', 'Milk'),
    prices: generatePrices(15 + Math.random() * 15),
    lastUpdated: getLastUpdated(),
  })),

  // Cheese (25 products)
  ...Array.from({ length: 25 }, (_, i) => ({
    id: i + 31,
    name: ['Cheddar', 'Mozzarella', 'Feta', 'Gouda', 'Edam', 'Brie'][i % 6] + ' Cheese ' + [200, 400, 500][Math.floor(i / 6) % 3] + 'g',
    category: 'Dairy',
    subcategory: 'Cheese',
    unit: 'g',
    image: getProductImage('Dairy', 'Cheese'),
    prices: generatePrices(25 + Math.random() * 30),
    lastUpdated: getLastUpdated(),
  })),

  // Yogurt (20 products)
  ...Array.from({ length: 20 }, (_, i) => ({
    id: i + 56,
    name: ['Plain', 'Strawberry', 'Blueberry', 'Vanilla', 'Greek'][i % 5] + ' Yogurt ' + [500, 1000][Math.floor(i / 5) % 2] + 'g',
    category: 'Dairy',
    subcategory: 'Yogurt',
    unit: 'g',
    image: getProductImage('Dairy', 'Yogurt'),
    prices: generatePrices(10 + Math.random() * 12),
    lastUpdated: getLastUpdated(),
  })),

  // Butter & Spreads (25 products)
  ...Array.from({ length: 25 }, (_, i) => ({
    id: i + 76,
    name: ['Butter', 'Margarine', 'Peanut Butter', 'Jam', 'Honey'][i % 5] + ' ' + [250, 500, 1000][Math.floor(i / 5) % 3] + 'g',
    category: 'Dairy',
    subcategory: 'Butter & Spreads',
    unit: 'g',
    image: getProductImage('Dairy', 'Butter & Spreads'),
    prices: generatePrices(15 + Math.random() * 25),
    lastUpdated: getLastUpdated(),
  })),

  // Eggs (20 products)
  ...Array.from({ length: 20 }, (_, i) => ({
    id: i + 101,
    name: ['Free Range', 'Cage Free', 'Organic', 'Brown', 'White'][i % 5] + ' Eggs ' + [6, 12, 18, 24][Math.floor(i / 5) % 4],
    category: 'Dairy',
    subcategory: 'Eggs',
    unit: 'pack',
    image: getProductImage('Dairy', 'Eggs'),
    prices: generatePrices(12 + Math.random() * 18),
    lastUpdated: getLastUpdated(),
  })),

  // Milk Alternatives (15 products)
  ...Array.from({ length: 15 }, (_, i) => ({
    id: i + 121,
    name: ['Almond', 'Soy', 'Oat', 'Coconut', 'Cashew'][i % 5] + ' Milk ' + [1000, 2000][Math.floor(i / 5) % 2] + 'ml',
    category: 'Dairy',
    subcategory: 'Milk Alternatives',
    unit: 'ml',
    image: getProductImage('Dairy', 'Milk Alternatives'),
    prices: generatePrices(18 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // Cream & Custard (15 products)
  ...Array.from({ length: 15 }, (_, i) => ({
    id: i + 136,
    name: ['Cream', 'Custard', 'Sour Cream', 'Crème Fraîche', 'Ice Cream'][i % 5] + ' ' + [250, 500, 1000][Math.floor(i / 5) % 3] + 'ml',
    category: 'Dairy',
    subcategory: 'Cream & Custard',
    unit: 'ml',
    image: getProductImage('Dairy', 'Cream & Custard'),
    prices: generatePrices(12 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // ===== MEAT & POULTRY (200 products) =====
  // Beef (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 151,
    name: ['Steak', 'Mince', 'Ribs', 'Brisket', 'Roast', 'Sirloin', 'Fillet', 'Rump'][i % 8] + ' ' + [250, 500, 1000][Math.floor(i / 8) % 3] + 'g',
    category: 'Meat',
    subcategory: 'Beef',
    unit: 'g',
    image: getProductImage('Meat', 'Beef'),
    prices: generatePrices(40 + Math.random() * 80),
    lastUpdated: getLastUpdated(),
  })),

  // Chicken (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 191,
    name: ['Breast', 'Thigh', 'Drumstick', 'Wing', 'Whole', 'Mince'][i % 6] + ' ' + [500, 1000, 1500][Math.floor(i / 6) % 3] + 'g',
    category: 'Meat',
    subcategory: 'Chicken',
    unit: 'g',
    image: getProductImage('Meat', 'Chicken'),
    prices: generatePrices(30 + Math.random() * 50),
    lastUpdated: getLastUpdated(),
  })),

  // Pork (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 231,
    name: ['Chop', 'Mince', 'Ribs', 'Belly', 'Shoulder', 'Loin'][i % 6] + ' ' + [500, 1000][Math.floor(i / 6) % 2] + 'g',
    category: 'Meat',
    subcategory: 'Pork',
    unit: 'g',
    image: getProductImage('Meat', 'Pork'),
    prices: generatePrices(35 + Math.random() * 60),
    lastUpdated: getLastUpdated(),
  })),

  // Lamb (25 products)
  ...Array.from({ length: 25 }, (_, i) => ({
    id: i + 261,
    name: ['Chop', 'Leg', 'Shoulder', 'Mince', 'Ribs'][i % 5] + ' ' + [500, 1000][Math.floor(i / 5) % 2] + 'g',
    category: 'Meat',
    subcategory: 'Lamb',
    unit: 'g',
    image: getProductImage('Meat', 'Lamb'),
    prices: generatePrices(50 + Math.random() * 70),
    lastUpdated: getLastUpdated(),
  })),

  // Processed Meat (35 products)
  ...Array.from({ length: 35 }, (_, i) => ({
    id: i + 286,
    name: ['Boerewors', 'Polony', 'Salami', 'Ham', 'Bacon', 'Sausage', 'Biltong'][i % 7] + ' ' + [250, 500, 1000][Math.floor(i / 7) % 3] + 'g',
    category: 'Meat',
    subcategory: 'Processed Meat',
    unit: 'g',
    image: getProductImage('Meat', 'Processed Meat'),
    prices: generatePrices(25 + Math.random() * 40),
    lastUpdated: getLastUpdated(),
  })),

  // Seafood (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 321,
    name: ['Salmon', 'Tuna', 'Cod', 'Hake', 'Prawns', 'Mussels'][i % 6] + ' ' + [250, 500, 1000][Math.floor(i / 6) % 3] + 'g',
    category: 'Meat',
    subcategory: 'Seafood',
    unit: 'g',
    image: getProductImage('Meat', 'Seafood'),
    prices: generatePrices(45 + Math.random() * 100),
    lastUpdated: getLastUpdated(),
  })),

  // ===== PRODUCE (250 products) =====
  // Vegetables (100 products)
  ...Array.from({ length: 100 }, (_, i) => ({
    id: i + 351,
    name: ['Tomato', 'Onion', 'Garlic', 'Carrot', 'Lettuce', 'Cabbage', 'Broccoli', 'Spinach', 'Potato', 'Cucumber', 'Bell Pepper', 'Celery', 'Leek', 'Zucchini', 'Eggplant', 'Radish', 'Turnip', 'Parsnip', 'Beetroot', 'Pumpkin'][i % 20] + ' ' + [250, 500, 1000, 1500][Math.floor(i / 20) % 4] + 'g',
    category: 'Produce',
    subcategory: 'Vegetables',
    unit: 'g',
    image: getProductImage('Produce', 'Vegetables'),
    prices: generatePrices(5 + Math.random() * 15),
    lastUpdated: getLastUpdated(),
  })),

  // Fruits (80 products)
  ...Array.from({ length: 80 }, (_, i) => ({
    id: i + 451,
    name: ['Apple', 'Banana', 'Orange', 'Lemon', 'Lime', 'Grape', 'Strawberry', 'Blueberry', 'Mango', 'Pineapple', 'Papaya', 'Guava', 'Avocado', 'Peach', 'Pear', 'Kiwi'][i % 16] + ' ' + [250, 500, 1000][Math.floor(i / 16) % 3] + 'g',
    category: 'Produce',
    subcategory: 'Fruits',
    unit: 'g',
    image: getProductImage('Produce', 'Fruits'),
    prices: generatePrices(8 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // Herbs & Spices (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 531,
    name: ['Parsley', 'Coriander', 'Basil', 'Thyme', 'Oregano', 'Rosemary', 'Mint', 'Chives'][i % 8] + ' ' + [25, 50, 100][Math.floor(i / 8) % 3] + 'g',
    category: 'Produce',
    subcategory: 'Herbs & Spices',
    unit: 'g',
    image: getProductImage('Produce', 'Herbs & Spices'),
    prices: generatePrices(10 + Math.random() * 15),
    lastUpdated: getLastUpdated(),
  })),

  // Nuts & Seeds (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 571,
    name: ['Almonds', 'Cashews', 'Peanuts', 'Walnuts', 'Sunflower Seeds', 'Pumpkin Seeds'][i % 6] + ' ' + [250, 500, 1000][Math.floor(i / 6) % 3] + 'g',
    category: 'Produce',
    subcategory: 'Nuts & Seeds',
    unit: 'g',
    image: getProductImage('Produce', 'Nuts & Seeds'),
    prices: generatePrices(20 + Math.random() * 40),
    lastUpdated: getLastUpdated(),
  })),

  // ===== BAKERY (120 products) =====
  // Bread (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 601,
    name: ['White', 'Brown', 'Rye', 'Wholemeal', 'Sourdough', 'Ciabatta'][i % 6] + ' Bread ' + [400, 600, 800][Math.floor(i / 6) % 3] + 'g',
    category: 'Bakery',
    subcategory: 'Bread',
    unit: 'g',
    image: getProductImage('Bakery', 'Bread'),
    prices: generatePrices(6 + Math.random() * 10),
    lastUpdated: getLastUpdated(),
  })),

  // Buns & Rolls (25 products)
  ...Array.from({ length: 25 }, (_, i) => ({
    id: i + 631,
    name: ['Hamburger', 'Hot Dog', 'Dinner', 'Croissant', 'Bagel'][i % 5] + ' Buns ' + [4, 6, 8][Math.floor(i / 5) % 3] + ' pack',
    category: 'Bakery',
    subcategory: 'Buns & Rolls',
    unit: 'pack',
    image: getProductImage('Bakery', 'Buns & Rolls'),
    prices: generatePrices(8 + Math.random() * 12),
    lastUpdated: getLastUpdated(),
  })),

  // Cakes & Pastries (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 656,
    name: ['Chocolate', 'Vanilla', 'Carrot', 'Sponge', 'Cheesecake', 'Donut'][i % 6] + ' ' + [200, 400, 600][Math.floor(i / 6) % 3] + 'g',
    category: 'Bakery',
    subcategory: 'Cakes & Pastries',
    unit: 'g',
    image: getProductImage('Bakery', 'Cakes & Pastries'),
    prices: generatePrices(12 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // Biscuits & Cookies (25 products)
  ...Array.from({ length: 25 }, (_, i) => ({
    id: i + 686,
    name: ['Chocolate Chip', 'Oatmeal', 'Digestive', 'Cream', 'Wafer'][i % 5] + ' Biscuits ' + [200, 400][Math.floor(i / 5) % 2] + 'g',
    category: 'Bakery',
    subcategory: 'Biscuits & Cookies',
    unit: 'g',
    image: getProductImage('Bakery', 'Biscuits & Cookies'),
    prices: generatePrices(8 + Math.random() * 12),
    lastUpdated: getLastUpdated(),
  })),

  // ===== PANTRY & STAPLES (300 products) =====
  // Rice & Grains (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 711,
    name: ['Basmati', 'Jasmine', 'Arborio', 'Brown', 'White', 'Wild', 'Quinoa', 'Couscous'][i % 8] + ' Rice ' + [1000, 2000, 5000][Math.floor(i / 8) % 3] + 'g',
    category: 'Pantry',
    subcategory: 'Rice & Grains',
    unit: 'g',
    image: getProductImage('Pantry', 'Rice & Grains'),
    prices: generatePrices(15 + Math.random() * 40),
    lastUpdated: getLastUpdated(),
  })),

  // Pasta (35 products)
  ...Array.from({ length: 35 }, (_, i) => ({
    id: i + 751,
    name: ['Spaghetti', 'Penne', 'Fusilli', 'Linguine', 'Fettuccine', 'Ravioli', 'Lasagna'][i % 7] + ' ' + [500, 1000][Math.floor(i / 7) % 2] + 'g',
    category: 'Pantry',
    subcategory: 'Pasta',
    unit: 'g',
    image: getProductImage('Pantry', 'Pasta'),
    prices: generatePrices(8 + Math.random() * 15),
    lastUpdated: getLastUpdated(),
  })),

  // Flour & Baking (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 786,
    name: ['Wheat', 'Corn', 'Rye', 'Almond', 'Coconut', 'Baking Powder', 'Baking Soda'][i % 7] + ' ' + [500, 1000, 2000][Math.floor(i / 7) % 3] + 'g',
    category: 'Pantry',
    subcategory: 'Flour & Baking',
    unit: 'g',
    image: getProductImage('Pantry', 'Flour & Baking'),
    prices: generatePrices(10 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // Oils & Vinegars (25 products)
  ...Array.from({ length: 25 }, (_, i) => ({
    id: i + 816,
    name: ['Olive', 'Vegetable', 'Sunflower', 'Coconut', 'Sesame'][i % 5] + ' Oil ' + [500, 1000][Math.floor(i / 5) % 2] + 'ml',
    category: 'Pantry',
    subcategory: 'Oils & Vinegars',
    unit: 'ml',
    image: getProductImage('Pantry', 'Oils & Vinegars'),
    prices: generatePrices(20 + Math.random() * 40),
    lastUpdated: getLastUpdated(),
  })),

  // Sauces & Condiments (50 products)
  ...Array.from({ length: 50 }, (_, i) => ({
    id: i + 841,
    name: ['Tomato', 'BBQ', 'Soy', 'Worcestershire', 'Hot', 'Ketchup', 'Mustard', 'Mayo', 'Pesto', 'Teriyaki'][i % 10] + ' Sauce ' + [250, 500, 750][Math.floor(i / 10) % 3] + 'ml',
    category: 'Pantry',
    subcategory: 'Sauces & Condiments',
    unit: 'ml',
    image: getProductImage('Pantry', 'Sauces & Condiments'),
    prices: generatePrices(12 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // Canned & Jarred (60 products)
  ...Array.from({ length: 60 }, (_, i) => ({
    id: i + 891,
    name: ['Beans', 'Chickpeas', 'Lentils', 'Corn', 'Peas', 'Carrots', 'Tomatoes', 'Pumpkin', 'Olives', 'Pickles'][i % 10] + ' ' + [400, 500, 800][Math.floor(i / 10) % 3] + 'g',
    category: 'Pantry',
    subcategory: 'Canned & Jarred',
    unit: 'g',
    image: getProductImage('Pantry', 'Canned & Jarred'),
    prices: generatePrices(8 + Math.random() * 15),
    lastUpdated: getLastUpdated(),
  })),

  // Spices & Seasonings (35 products)
  ...Array.from({ length: 35 }, (_, i) => ({
    id: i + 951,
    name: ['Black Pepper', 'Salt', 'Cumin', 'Coriander', 'Turmeric', 'Paprika', 'Chili'][i % 7] + ' ' + [50, 100, 200][Math.floor(i / 7) % 3] + 'g',
    category: 'Pantry',
    subcategory: 'Spices & Seasonings',
    unit: 'g',
    image: getProductImage('Pantry', 'Spices & Seasonings'),
    prices: generatePrices(8 + Math.random() * 15),
    lastUpdated: getLastUpdated(),
  })),

  // ===== BEVERAGES (200 products) =====
  // Soft Drinks (50 products)
  ...Array.from({ length: 50 }, (_, i) => ({
    id: i + 986,
    name: ['Coca Cola', 'Sprite', 'Fanta', 'Pepsi', 'Mountain Dew', 'Lemonade', 'Ginger Ale', 'Tonic', 'Soda', 'Cola'][i % 10] + ' ' + [330, 500, 1000, 2000][Math.floor(i / 10) % 4] + 'ml',
    category: 'Beverages',
    subcategory: 'Soft Drinks',
    unit: 'ml',
    image: getProductImage('Beverages', 'Soft Drinks'),
    prices: generatePrices(8 + Math.random() * 15),
    lastUpdated: getLastUpdated(),
  })),

  // Juice (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 1036,
    name: ['Orange', 'Apple', 'Grape', 'Mango', 'Pineapple', 'Cranberry', 'Pomegranate', 'Mixed Fruit'][i % 8] + ' Juice ' + [500, 1000, 2000][Math.floor(i / 8) % 3] + 'ml',
    category: 'Beverages',
    subcategory: 'Juice',
    unit: 'ml',
    image: getProductImage('Beverages', 'Juice'),
    prices: generatePrices(10 + Math.random() * 18),
    lastUpdated: getLastUpdated(),
  })),

  // Coffee & Tea (50 products)
  ...Array.from({ length: 50 }, (_, i) => ({
    id: i + 1076,
    name: ['Instant Coffee', 'Ground Coffee', 'Black Tea', 'Green Tea', 'Herbal Tea', 'Rooibos', 'Chamomile', 'Peppermint'][i % 8] + ' ' + [200, 400, 500][Math.floor(i / 8) % 3] + 'g',
    category: 'Beverages',
    subcategory: 'Coffee & Tea',
    unit: 'g',
    image: getProductImage('Beverages', 'Coffee & Tea'),
    prices: generatePrices(15 + Math.random() * 35),
    lastUpdated: getLastUpdated(),
  })),

  // Energy & Sports Drinks (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 1126,
    name: ['Energy Drink', 'Sports Drink', 'Protein Shake', 'Electrolyte Drink'][i % 4] + ' ' + [250, 500, 1000][Math.floor(i / 4) % 3] + 'ml',
    category: 'Beverages',
    subcategory: 'Energy & Sports',
    unit: 'ml',
    image: getProductImage('Beverages', 'Energy & Sports'),
    prices: generatePrices(12 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // Water (20 products)
  ...Array.from({ length: 20 }, (_, i) => ({
    id: i + 1156,
    name: ['Spring Water', 'Mineral Water', 'Sparkling Water', 'Flavored Water'][i % 4] + ' ' + [500, 1000, 1500][Math.floor(i / 4) % 3] + 'ml',
    category: 'Beverages',
    subcategory: 'Water',
    unit: 'ml',
    image: getProductImage('Beverages', 'Water'),
    prices: generatePrices(5 + Math.random() * 10),
    lastUpdated: getLastUpdated(),
  })),

  // ===== FROZEN (120 products) =====
  // Frozen Vegetables (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 1176,
    name: ['Broccoli', 'Carrots', 'Peas', 'Corn', 'Mixed Vegetables', 'Spinach'][i % 6] + ' ' + [500, 1000][Math.floor(i / 6) % 2] + 'g',
    category: 'Frozen',
    subcategory: 'Vegetables',
    unit: 'g',
    image: getProductImage('Frozen', 'Vegetables'),
    prices: generatePrices(12 + Math.random() * 18),
    lastUpdated: getLastUpdated(),
  })),

  // Frozen Fruits (20 products)
  ...Array.from({ length: 20 }, (_, i) => ({
    id: i + 1206,
    name: ['Strawberry', 'Blueberry', 'Mango', 'Mixed Berries', 'Peach'][i % 5] + ' ' + [500, 1000][Math.floor(i / 5) % 2] + 'g',
    category: 'Frozen',
    subcategory: 'Fruits',
    unit: 'g',
    image: getProductImage('Frozen', 'Fruits'),
    prices: generatePrices(15 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // Frozen Meals (35 products)
  ...Array.from({ length: 35 }, (_, i) => ({
    id: i + 1226,
    name: ['Pizza', 'Burger', 'Lasagna', 'Curry', 'Stir Fry', 'Pasta', 'Rice Bowl'][i % 7] + ' ' + [300, 500, 750][Math.floor(i / 7) % 3] + 'g',
    category: 'Frozen',
    subcategory: 'Meals',
    unit: 'g',
    image: getProductImage('Frozen', 'Meals'),
    prices: generatePrices(20 + Math.random() * 30),
    lastUpdated: getLastUpdated(),
  })),

  // Ice Cream (25 products)
  ...Array.from({ length: 25 }, (_, i) => ({
    id: i + 1261,
    name: ['Vanilla', 'Chocolate', 'Strawberry', 'Mint Choc', 'Caramel'][i % 5] + ' Ice Cream ' + [500, 1000][Math.floor(i / 5) % 2] + 'ml',
    category: 'Frozen',
    subcategory: 'Ice Cream',
    unit: 'ml',
    image: getProductImage('Frozen', 'Ice Cream'),
    prices: generatePrices(18 + Math.random() * 25),
    lastUpdated: getLastUpdated(),
  })),

  // ===== SNACKS & CONFECTIONERY (150 products) =====
  // Chips & Crisps (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 1286,
    name: ['Potato', 'Corn', 'Tortilla', 'Prawn', 'Cheese', 'Salt & Vinegar'][i % 6] + ' Chips ' + [50, 100, 150][Math.floor(i / 6) % 3] + 'g',
    category: 'Snacks',
    subcategory: 'Chips & Crisps',
    unit: 'g',
    image: getProductImage('Snacks', 'Chips & Crisps'),
    prices: generatePrices(8 + Math.random() * 12),
    lastUpdated: getLastUpdated(),
  })),

  // Chocolate & Candy (50 products)
  ...Array.from({ length: 50 }, (_, i) => ({
    id: i + 1326,
    name: ['Milk Chocolate', 'Dark Chocolate', 'Hazelnut', 'Caramel', 'Toffee', 'Gummy', 'Lollipop', 'Fudge', 'Nougat', 'Wafer'][i % 10] + ' ' + [30, 50, 100][Math.floor(i / 10) % 3] + 'g',
    category: 'Snacks',
    subcategory: 'Chocolate & Candy',
    unit: 'g',
    image: getProductImage('Snacks', 'Chocolate & Candy'),
    prices: generatePrices(5 + Math.random() * 10),
    lastUpdated: getLastUpdated(),
  })),

  // Nuts & Trail Mix (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 1376,
    name: ['Mixed Nuts', 'Almonds', 'Cashews', 'Trail Mix', 'Granola'][i % 5] + ' ' + [100, 200, 500][Math.floor(i / 5) % 3] + 'g',
    category: 'Snacks',
    subcategory: 'Nuts & Trail Mix',
    unit: 'g',
    image: getProductImage('Snacks', 'Nuts & Trail Mix'),
    prices: generatePrices(15 + Math.random() * 25),
    lastUpdated: getLastUpdated(),
  })),

  // Popcorn & Puffed Snacks (20 products)
  ...Array.from({ length: 20 }, (_, i) => ({
    id: i + 1406,
    name: ['Popcorn', 'Puffed Corn', 'Rice Cakes', 'Pretzels'][i % 4] + ' ' + [100, 200][Math.floor(i / 4) % 2] + 'g',
    category: 'Snacks',
    subcategory: 'Popcorn & Puffed',
    unit: 'g',
    image: getProductImage('Snacks', 'Popcorn & Puffed'),
    prices: generatePrices(8 + Math.random() * 12),
    lastUpdated: getLastUpdated(),
  })),

  // ===== HOUSEHOLD & CLEANING (150 products) =====
  // Laundry (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 1426,
    name: ['Laundry Powder', 'Laundry Liquid', 'Fabric Softener', 'Stain Remover', 'Bleach'][i % 5] + ' ' + [500, 1000, 2000, 3000][Math.floor(i / 5) % 4] + 'ml',
    category: 'Household',
    subcategory: 'Laundry',
    unit: 'ml',
    image: getProductImage('Household', 'Laundry'),
    prices: generatePrices(20 + Math.random() * 40),
    lastUpdated: getLastUpdated(),
  })),

  // Cleaning (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 1466,
    name: ['All Purpose Cleaner', 'Window Cleaner', 'Toilet Cleaner', 'Floor Cleaner', 'Disinfectant'][i % 5] + ' ' + [500, 1000][Math.floor(i / 5) % 2] + 'ml',
    category: 'Household',
    subcategory: 'Cleaning',
    unit: 'ml',
    image: getProductImage('Household', 'Cleaning'),
    prices: generatePrices(15 + Math.random() * 25),
    lastUpdated: getLastUpdated(),
  })),

  // Dishwashing (30 products)
  ...Array.from({ length: 30 }, (_, i) => ({
    id: i + 1506,
    name: ['Dish Liquid', 'Dish Powder', 'Dishwasher Tablets', 'Rinse Aid'][i % 4] + ' ' + [500, 1000][Math.floor(i / 4) % 2] + 'ml',
    category: 'Household',
    subcategory: 'Dishwashing',
    unit: 'ml',
    image: getProductImage('Household', 'Dishwashing'),
    prices: generatePrices(12 + Math.random() * 20),
    lastUpdated: getLastUpdated(),
  })),

  // Personal Care (40 products)
  ...Array.from({ length: 40 }, (_, i) => ({
    id: i + 1536,
    name: ['Shampoo', 'Conditioner', 'Body Wash', 'Soap', 'Lotion', 'Deodorant', 'Toothpaste', 'Mouthwash'][i % 8] + ' ' + [200, 400, 500][Math.floor(i / 8) % 3] + 'ml',
    category: 'Household',
    subcategory: 'Personal Care',
    unit: 'ml',
    image: getProductImage('Household', 'Personal Care'),
    prices: generatePrices(15 + Math.random() * 25),
    lastUpdated: getLastUpdated(),
  })),
];

// Export total count
export const TOTAL_PRODUCTS = PRODUCTS_1500.length;
