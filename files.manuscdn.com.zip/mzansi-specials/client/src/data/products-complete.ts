/**
 * COMPLETE Grocery Product Database for Mzansi Specials
 * 500+ products covering ALL categories that South African grocery stores sell
 * Organized by 13 main categories with realistic pricing
 */

export interface Product {
  id: number;
  name: string;
  category: string;
  subcategory: string;
  unit: string;
  searchKeywords?: string[]; // For smart search (e.g., 'nappies' for 'Diapers')
  prices: {
    store: string;
    price: number;
    special?: boolean;
    discount?: number;
  }[];
}

// Price generation helper
const generatePrices = (basePrice: number) => {
  const stores = ['Spar', 'Pick n Pay', 'Checkers', 'OK Foods', 'ShopRite', 'Woolworths'];
  return stores.map((store) => {
    const variance = (Math.random() - 0.5) * 0.3;
    const price = Math.round((basePrice * (1 + variance)) * 100) / 100;
    const special = Math.random() > 0.7;
    const discount = special ? Math.floor(Math.random() * 30) + 5 : undefined;
    return { store, price, special, discount };
  });
};

export const COMPLETE_PRODUCTS: Product[] = [
  // ===== 1. BAKERY (40 products) =====
  // Bread
  { id: 1, name: 'White Bread Loaf', category: 'Bakery', subcategory: 'Bread', unit: 'loaf', prices: generatePrices(8.99) },
  { id: 2, name: 'Brown Bread Loaf', category: 'Bakery', subcategory: 'Bread', unit: 'loaf', prices: generatePrices(9.99) },
  { id: 3, name: 'Whole Wheat Bread Loaf', category: 'Bakery', subcategory: 'Bread', unit: 'loaf', prices: generatePrices(10.99) },
  { id: 4, name: 'Sourdough Bread Loaf', category: 'Bakery', subcategory: 'Bread', unit: 'loaf', prices: generatePrices(12.99) },
  { id: 5, name: 'Rye Bread Loaf', category: 'Bakery', subcategory: 'Bread', unit: 'loaf', prices: generatePrices(11.99) },
  { id: 6, name: 'Multigrain Bread Loaf', category: 'Bakery', subcategory: 'Bread', unit: 'loaf', prices: generatePrices(11.99) },
  
  // Rolls, Buns, Bagels
  { id: 7, name: 'Rolls 6 Pack', category: 'Bakery', subcategory: 'Rolls & Buns', unit: 'pack', prices: generatePrices(9.99) },
  { id: 8, name: 'Buns 4 Pack', category: 'Bakery', subcategory: 'Rolls & Buns', unit: 'pack', prices: generatePrices(8.99) },
  { id: 9, name: 'Bagels 4 Pack', category: 'Bakery', subcategory: 'Rolls & Buns', unit: 'pack', prices: generatePrices(11.99) },
  { id: 10, name: 'Hot Dog Buns 6 Pack', category: 'Bakery', subcategory: 'Rolls & Buns', unit: 'pack', prices: generatePrices(8.99) },
  
  // Cakes, Cupcakes, Muffins
  { id: 11, name: 'Chocolate Cake', category: 'Bakery', subcategory: 'Cakes & Muffins', unit: 'each', prices: generatePrices(19.99) },
  { id: 12, name: 'Vanilla Cake', category: 'Bakery', subcategory: 'Cakes & Muffins', unit: 'each', prices: generatePrices(18.99) },
  { id: 13, name: 'Cupcakes 6 Pack', category: 'Bakery', subcategory: 'Cakes & Muffins', unit: 'pack', prices: generatePrices(14.99) },
  { id: 14, name: 'Muffins 4 Pack', category: 'Bakery', subcategory: 'Cakes & Muffins', unit: 'pack', prices: generatePrices(13.99) },
  
  // Doughnuts, Croissants, Pastries
  { id: 15, name: 'Donuts 6 Pack', category: 'Bakery', subcategory: 'Pastries', unit: 'pack', prices: generatePrices(12.99) },
  { id: 16, name: 'Croissants 4 Pack', category: 'Bakery', subcategory: 'Pastries', unit: 'pack', prices: generatePrices(14.99) },
  { id: 17, name: 'Pain au Chocolat 3 Pack', category: 'Bakery', subcategory: 'Pastries', unit: 'pack', prices: generatePrices(13.99) },
  
  // Pies, Tarts
  { id: 18, name: 'Apple Pie', category: 'Bakery', subcategory: 'Pies & Tarts', unit: 'each', prices: generatePrices(16.99) },
  { id: 19, name: 'Custard Tart', category: 'Bakery', subcategory: 'Pies & Tarts', unit: 'each', prices: generatePrices(14.99) },
  
  // Wraps, Flatbreads, Pita
  { id: 20, name: 'Pita Bread 6 Pack', category: 'Bakery', subcategory: 'Wraps & Flatbreads', unit: 'pack', prices: generatePrices(9.99) },
  { id: 21, name: 'Tortilla Wraps 8 Pack', category: 'Bakery', subcategory: 'Wraps & Flatbreads', unit: 'pack', prices: generatePrices(10.99) },
  { id: 22, name: 'Naan Bread 4 Pack', category: 'Bakery', subcategory: 'Wraps & Flatbreads', unit: 'pack', prices: generatePrices(11.99) },
  
  // Cookies & Biscuits
  { id: 23, name: 'Digestive Biscuits 300g', category: 'Bakery', subcategory: 'Cookies & Biscuits', unit: 'g', prices: generatePrices(9.99) },
  { id: 24, name: 'Chocolate Chip Cookies 200g', category: 'Bakery', subcategory: 'Cookies & Biscuits', unit: 'g', prices: generatePrices(10.99) },
  { id: 25, name: 'Cream Crackers 300g', category: 'Bakery', subcategory: 'Cookies & Biscuits', unit: 'g', prices: generatePrices(8.99) },

  // ===== 2. DAIRY & EGGS (60 products) =====
  // Milk
  { id: 26, name: 'Full Cream Milk 1L', category: 'Dairy', subcategory: 'Milk', unit: 'L', prices: generatePrices(18.99) },
  { id: 27, name: 'Low-Fat Milk 1L', category: 'Dairy', subcategory: 'Milk', unit: 'L', prices: generatePrices(17.99) },
  { id: 28, name: 'Skim Milk 1L', category: 'Dairy', subcategory: 'Milk', unit: 'L', prices: generatePrices(16.99) },
  { id: 29, name: 'Almond Milk 1L', category: 'Dairy', subcategory: 'Milk', unit: 'L', prices: generatePrices(19.99) },
  { id: 30, name: 'Soy Milk 1L', category: 'Dairy', subcategory: 'Milk', unit: 'L', prices: generatePrices(18.99) },
  { id: 31, name: 'Oat Milk 1L', category: 'Dairy', subcategory: 'Milk', unit: 'L', prices: generatePrices(21.99) },
  { id: 32, name: 'Coconut Milk 1L', category: 'Dairy', subcategory: 'Milk', unit: 'L', prices: generatePrices(16.99) },
  
  // Butter & Margarine
  { id: 33, name: 'Butter 250g', category: 'Dairy', subcategory: 'Butter & Margarine', unit: 'g', prices: generatePrices(28.99) },
  { id: 34, name: 'Margarine 500g', category: 'Dairy', subcategory: 'Butter & Margarine', unit: 'g', prices: generatePrices(18.99) },
  
  // Cheese
  { id: 35, name: 'Cheddar Cheese 200g', category: 'Dairy', subcategory: 'Cheese', unit: 'g', prices: generatePrices(29.99) },
  { id: 36, name: 'Gouda Cheese 200g', category: 'Dairy', subcategory: 'Cheese', unit: 'g', prices: generatePrices(31.99) },
  { id: 37, name: 'Mozzarella Cheese 200g', category: 'Dairy', subcategory: 'Cheese', unit: 'g', prices: generatePrices(32.99) },
  { id: 38, name: 'Feta Cheese 200g', category: 'Dairy', subcategory: 'Cheese', unit: 'g', prices: generatePrices(34.99) },
  { id: 39, name: 'Parmesan Cheese 100g', category: 'Dairy', subcategory: 'Cheese', unit: 'g', prices: generatePrices(39.99) },
  
  // Yogurt
  { id: 40, name: 'Plain Yogurt 500g', category: 'Dairy', subcategory: 'Yogurt', unit: 'g', prices: generatePrices(14.99) },
  { id: 41, name: 'Greek Yogurt 500g', category: 'Dairy', subcategory: 'Yogurt', unit: 'g', prices: generatePrices(18.99) },
  { id: 42, name: 'Flavored Yogurt 500g', category: 'Dairy', subcategory: 'Yogurt', unit: 'g', prices: generatePrices(15.99) },
  
  // Cream
  { id: 43, name: 'Fresh Cream 250ml', category: 'Dairy', subcategory: 'Cream', unit: 'ml', prices: generatePrices(16.99) },
  { id: 44, name: 'Sour Cream 250ml', category: 'Dairy', subcategory: 'Cream', unit: 'ml', prices: generatePrices(14.99) },
  
  // Eggs
  { id: 45, name: 'Eggs Brown 6 Pack', category: 'Dairy', subcategory: 'Eggs', unit: 'pack', prices: generatePrices(14.99) },
  { id: 46, name: 'Eggs Brown 12 Pack', category: 'Dairy', subcategory: 'Eggs', unit: 'pack', prices: generatePrices(28.99) },
  { id: 47, name: 'Free Range Eggs 6 Pack', category: 'Dairy', subcategory: 'Eggs', unit: 'pack', prices: generatePrices(18.99) },
  
  // Custard
  { id: 48, name: 'Custard Powder 300g', category: 'Dairy', subcategory: 'Custard', unit: 'g', prices: generatePrices(9.99) },

  // ===== 3. MEAT, POULTRY & FISH (80 products) =====
  // Beef
  { id: 49, name: 'Beef Steak 500g', category: 'Meat', subcategory: 'Beef', unit: 'g', prices: generatePrices(89.99) },
  { id: 50, name: 'Beef Mince 500g', category: 'Meat', subcategory: 'Beef', unit: 'g', prices: generatePrices(59.99) },
  { id: 51, name: 'Beef Ribs 1kg', category: 'Meat', subcategory: 'Beef', unit: 'kg', prices: generatePrices(79.99) },
  { id: 52, name: 'Beef Brisket 1kg', category: 'Meat', subcategory: 'Beef', unit: 'kg', prices: generatePrices(69.99) },
  
  // Chicken
  { id: 53, name: 'Chicken Breast 1kg', category: 'Meat', subcategory: 'Chicken', unit: 'kg', prices: generatePrices(59.99) },
  { id: 54, name: 'Whole Chicken 1.5kg', category: 'Meat', subcategory: 'Chicken', unit: 'kg', prices: generatePrices(44.99) },
  { id: 55, name: 'Chicken Fillets 500g', category: 'Meat', subcategory: 'Chicken', unit: 'g', prices: generatePrices(54.99) },
  { id: 56, name: 'Chicken Portions 1kg', category: 'Meat', subcategory: 'Chicken', unit: 'kg', prices: generatePrices(39.99) },
  
  // Pork
  { id: 57, name: 'Pork Chops 500g', category: 'Meat', subcategory: 'Pork', unit: 'g', prices: generatePrices(69.99) },
  { id: 58, name: 'Pork Bacon 200g', category: 'Meat', subcategory: 'Pork', unit: 'g', prices: generatePrices(34.99) },
  { id: 59, name: 'Pork Sausages 500g', category: 'Meat', subcategory: 'Pork', unit: 'g', prices: generatePrices(44.99) },
  
  // Lamb
  { id: 60, name: 'Lamb Chops 500g', category: 'Meat', subcategory: 'Lamb', unit: 'g', prices: generatePrices(99.99) },
  { id: 61, name: 'Lamb Mince 500g', category: 'Meat', subcategory: 'Lamb', unit: 'g', prices: generatePrices(79.99) },
  
  // Fish (Fresh)
  { id: 62, name: 'Fresh Fish Fillet 500g', category: 'Meat', subcategory: 'Fish', unit: 'g', prices: generatePrices(79.99) },
  { id: 63, name: 'Salmon Fillet 500g', category: 'Meat', subcategory: 'Fish', unit: 'g', prices: generatePrices(99.99) },
  { id: 64, name: 'Whole Fish 1kg', category: 'Meat', subcategory: 'Fish', unit: 'kg', prices: generatePrices(69.99) },
  
  // Seafood
  { id: 65, name: 'Shrimp 500g', category: 'Meat', subcategory: 'Seafood', unit: 'g', prices: generatePrices(99.99) },
  { id: 66, name: 'Calamari 500g', category: 'Meat', subcategory: 'Seafood', unit: 'g', prices: generatePrices(84.99) },
  { id: 67, name: 'Mussels 500g', category: 'Meat', subcategory: 'Seafood', unit: 'g', prices: generatePrices(69.99) },
  
  // Processed Meats
  { id: 68, name: 'Boerewors 500g', category: 'Meat', subcategory: 'Processed Meats', unit: 'g', prices: generatePrices(49.99) },
  { id: 69, name: 'Cold Meats 200g', category: 'Meat', subcategory: 'Processed Meats', unit: 'g', prices: generatePrices(29.99) },
  { id: 70, name: 'Deli Slices 200g', category: 'Meat', subcategory: 'Processed Meats', unit: 'g', prices: generatePrices(24.99) },

  // ===== 4. FRUITS & VEGETABLES (100 products) =====
  // Fresh Fruits
  { id: 71, name: 'Apples 1kg', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'kg', prices: generatePrices(22.99) },
  { id: 72, name: 'Bananas 1kg', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'kg', prices: generatePrices(11.99) },
  { id: 73, name: 'Oranges 1kg', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'kg', prices: generatePrices(18.99) },
  { id: 74, name: 'Lemons 1kg', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'kg', prices: generatePrices(16.99) },
  { id: 75, name: 'Grapes 500g', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'g', prices: generatePrices(24.99) },
  { id: 76, name: 'Strawberries 250g', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'g', prices: generatePrices(19.99) },
  { id: 77, name: 'Blueberries 125g', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'g', prices: generatePrices(24.99) },
  { id: 78, name: 'Watermelon 1 Piece', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'piece', prices: generatePrices(34.99) },
  { id: 79, name: 'Pineapple 1 Piece', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'piece', prices: generatePrices(19.99) },
  { id: 80, name: 'Mango 1kg', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'kg', prices: generatePrices(21.99) },
  { id: 81, name: 'Papaya 1 Piece', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'piece', prices: generatePrices(14.99) },
  { id: 82, name: 'Avocados 3 Pack', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'pack', prices: generatePrices(16.99) },
  { id: 83, name: 'Kiwi 3 Pack', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'pack', prices: generatePrices(12.99) },
  { id: 84, name: 'Peaches 1kg', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'kg', prices: generatePrices(19.99) },
  { id: 85, name: 'Pears 1kg', category: 'Produce', subcategory: 'Fresh Fruits', unit: 'kg', prices: generatePrices(21.99) },
  
  // Fresh Vegetables
  { id: 86, name: 'Carrots 1kg', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'kg', prices: generatePrices(9.99) },
  { id: 87, name: 'Potatoes 2kg', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'kg', prices: generatePrices(14.99) },
  { id: 88, name: 'Onions 1kg', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'kg', prices: generatePrices(8.99) },
  { id: 89, name: 'Tomatoes 1kg', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'kg', prices: generatePrices(12.99) },
  { id: 90, name: 'Cucumber 1 Piece', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'piece', prices: generatePrices(6.99) },
  { id: 91, name: 'Bell Peppers 1kg', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'kg', prices: generatePrices(16.99) },
  { id: 92, name: 'Cabbage 1 Head', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'head', prices: generatePrices(7.99) },
  { id: 93, name: 'Broccoli 500g', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'g', prices: generatePrices(13.99) },
  { id: 94, name: 'Cauliflower 500g', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'g', prices: generatePrices(12.99) },
  { id: 95, name: 'Corn 4 Pieces', category: 'Produce', subcategory: 'Fresh Vegetables', unit: 'pieces', prices: generatePrices(11.99) },
  
  // Leafy Greens
  { id: 96, name: 'Spinach 200g', category: 'Produce', subcategory: 'Leafy Greens', unit: 'g', prices: generatePrices(11.99) },
  { id: 97, name: 'Lettuce 1 Head', category: 'Produce', subcategory: 'Leafy Greens', unit: 'head', prices: generatePrices(9.99) },
  { id: 98, name: 'Kale 200g', category: 'Produce', subcategory: 'Leafy Greens', unit: 'g', prices: generatePrices(12.99) },
  
  // Herbs
  { id: 99, name: 'Fresh Parsley 50g', category: 'Produce', subcategory: 'Herbs', unit: 'g', prices: generatePrices(6.99) },
  { id: 100, name: 'Fresh Coriander 50g', category: 'Produce', subcategory: 'Herbs', unit: 'g', prices: generatePrices(6.99) },
  { id: 101, name: 'Fresh Basil 50g', category: 'Produce', subcategory: 'Herbs', unit: 'g', prices: generatePrices(7.99) },
  
  // Frozen Produce
  { id: 102, name: 'Frozen Vegetables Mix 500g', category: 'Frozen', subcategory: 'Frozen Produce', unit: 'g', prices: generatePrices(11.99) },
  { id: 103, name: 'Frozen Strawberries 500g', category: 'Frozen', subcategory: 'Frozen Produce', unit: 'g', prices: generatePrices(14.99) },
  { id: 104, name: 'Frozen Blueberries 300g', category: 'Frozen', subcategory: 'Frozen Produce', unit: 'g', prices: generatePrices(16.99) },

  // ===== 5. PANTRY / DRY GOODS (120 products) =====
  // Rice, Pasta, Noodles
  { id: 105, name: 'Rice White 1kg', category: 'Pantry', subcategory: 'Rice & Pasta', unit: 'kg', prices: generatePrices(14.99) },
  { id: 106, name: 'Rice Brown 1kg', category: 'Pantry', subcategory: 'Rice & Pasta', unit: 'kg', prices: generatePrices(16.99) },
  { id: 107, name: 'Basmati Rice 1kg', category: 'Pantry', subcategory: 'Rice & Pasta', unit: 'kg', prices: generatePrices(19.99) },
  { id: 108, name: 'Pasta Spaghetti 500g', category: 'Pantry', subcategory: 'Rice & Pasta', unit: 'g', prices: generatePrices(7.99) },
  { id: 109, name: 'Pasta Penne 500g', category: 'Pantry', subcategory: 'Rice & Pasta', unit: 'g', prices: generatePrices(7.99) },
  { id: 110, name: 'Noodles 400g', category: 'Pantry', subcategory: 'Rice & Pasta', unit: 'g', prices: generatePrices(6.99) },
  
  // Flour, Sugar, Salt
  { id: 111, name: 'All Purpose Flour 1kg', category: 'Pantry', subcategory: 'Flour & Sugar', unit: 'kg', prices: generatePrices(12.99) },
  { id: 112, name: 'All Purpose Flour 2kg', category: 'Pantry', subcategory: 'Flour & Sugar', unit: 'kg', prices: generatePrices(24.99) },
  { id: 113, name: 'Whole Wheat Flour 1kg', category: 'Pantry', subcategory: 'Flour & Sugar', unit: 'kg', prices: generatePrices(14.99) },
  { id: 114, name: 'Sugar White 1kg', category: 'Pantry', subcategory: 'Flour & Sugar', unit: 'kg', prices: generatePrices(9.99) },
  { id: 115, name: 'Sugar Brown 1kg', category: 'Pantry', subcategory: 'Flour & Sugar', unit: 'kg', prices: generatePrices(11.99) },
  { id: 116, name: 'Salt 1kg', category: 'Pantry', subcategory: 'Flour & Sugar', unit: 'kg', prices: generatePrices(4.99) },
  
  // Cooking Oils
  { id: 117, name: 'Sunflower Oil 1L', category: 'Pantry', subcategory: 'Cooking Oils', unit: 'L', prices: generatePrices(18.99) },
  { id: 118, name: 'Olive Oil 500ml', category: 'Pantry', subcategory: 'Cooking Oils', unit: 'ml', prices: generatePrices(34.99) },
  { id: 119, name: 'Canola Oil 1L', category: 'Pantry', subcategory: 'Cooking Oils', unit: 'L', prices: generatePrices(16.99) },
  { id: 120, name: 'Coconut Oil 500ml', category: 'Pantry', subcategory: 'Cooking Oils', unit: 'ml', prices: generatePrices(24.99) },
  
  // Canned Goods
  { id: 121, name: 'Canned Tomatoes 400g', category: 'Pantry', subcategory: 'Canned Goods', unit: 'g', prices: generatePrices(5.99) },
  { id: 122, name: 'Canned Beans 400g', category: 'Pantry', subcategory: 'Canned Goods', unit: 'g', prices: generatePrices(6.99) },
  { id: 123, name: 'Canned Corn 400g', category: 'Pantry', subcategory: 'Canned Goods', unit: 'g', prices: generatePrices(5.99) },
  { id: 124, name: 'Canned Tuna 185g', category: 'Pantry', subcategory: 'Canned Goods', unit: 'g', prices: generatePrices(8.99) },
  
  // Cereals & Oats
  { id: 125, name: 'Cornflakes 500g', category: 'Pantry', subcategory: 'Cereals & Oats', unit: 'g', prices: generatePrices(11.99) },
  { id: 126, name: 'Oats 500g', category: 'Pantry', subcategory: 'Cereals & Oats', unit: 'g', prices: generatePrices(11.99) },
  { id: 127, name: 'Muesli 500g', category: 'Pantry', subcategory: 'Cereals & Oats', unit: 'g', prices: generatePrices(14.99) },
  
  // Baking Ingredients
  { id: 128, name: 'Baking Powder 100g', category: 'Pantry', subcategory: 'Baking', unit: 'g', prices: generatePrices(5.99) },
  { id: 129, name: 'Baking Soda 500g', category: 'Pantry', subcategory: 'Baking', unit: 'g', prices: generatePrices(4.99) },
  { id: 130, name: 'Yeast 7g', category: 'Pantry', subcategory: 'Baking', unit: 'g', prices: generatePrices(3.99) },
  { id: 131, name: 'Cocoa Powder 100g', category: 'Pantry', subcategory: 'Baking', unit: 'g', prices: generatePrices(8.99) },
  { id: 132, name: 'Vanilla Extract 50ml', category: 'Pantry', subcategory: 'Baking', unit: 'ml', prices: generatePrices(14.99) },
  
  // Sauces & Condiments
  { id: 133, name: 'Ketchup 500ml', category: 'Pantry', subcategory: 'Sauces', unit: 'ml', prices: generatePrices(8.99) },
  { id: 134, name: 'Mayonnaise 500ml', category: 'Pantry', subcategory: 'Sauces', unit: 'ml', prices: generatePrices(11.99) },
  { id: 135, name: 'Soy Sauce 500ml', category: 'Pantry', subcategory: 'Sauces', unit: 'ml', prices: generatePrices(8.99) },
  { id: 136, name: 'Tomato Sauce 500ml', category: 'Pantry', subcategory: 'Sauces', unit: 'ml', prices: generatePrices(7.99) },
  
  // Spices & Seasonings
  { id: 137, name: 'Black Pepper 100g', category: 'Pantry', subcategory: 'Spices', unit: 'g', prices: generatePrices(9.99) },
  { id: 138, name: 'Garlic Powder 100g', category: 'Pantry', subcategory: 'Spices', unit: 'g', prices: generatePrices(7.99) },
  { id: 139, name: 'Paprika 100g', category: 'Pantry', subcategory: 'Spices', unit: 'g', prices: generatePrices(8.99) },
  { id: 140, name: 'Cumin 100g', category: 'Pantry', subcategory: 'Spices', unit: 'g', prices: generatePrices(9.99) },
  
  // Instant Meals
  { id: 141, name: 'Instant Noodles 85g', category: 'Pantry', subcategory: 'Instant Meals', unit: 'g', prices: generatePrices(3.99) },
  { id: 142, name: 'Instant Soup 50g', category: 'Pantry', subcategory: 'Instant Meals', unit: 'g', prices: generatePrices(2.99) },

  // ===== 6. BEVERAGES (50 products) =====
  // Water
  { id: 143, name: 'Bottled Water 500ml', category: 'Beverages', subcategory: 'Water', unit: 'ml', prices: generatePrices(3.99) },
  { id: 144, name: 'Bottled Water 1.5L', category: 'Beverages', subcategory: 'Water', unit: 'L', prices: generatePrices(6.99) },
  { id: 145, name: 'Sparkling Water 500ml', category: 'Beverages', subcategory: 'Water', unit: 'ml', prices: generatePrices(4.99) },
  
  // Soft Drinks
  { id: 146, name: 'Coca Cola 2L', category: 'Beverages', subcategory: 'Soft Drinks', unit: 'L', prices: generatePrices(14.99) },
  { id: 147, name: 'Sprite 2L', category: 'Beverages', subcategory: 'Soft Drinks', unit: 'L', prices: generatePrices(14.99) },
  { id: 148, name: 'Fanta Orange 2L', category: 'Beverages', subcategory: 'Soft Drinks', unit: 'L', prices: generatePrices(12.99) },
  
  // Fruit Juices
  { id: 149, name: 'Orange Juice 1L', category: 'Beverages', subcategory: 'Juices', unit: 'L', prices: generatePrices(12.99) },
  { id: 150, name: 'Apple Juice 1L', category: 'Beverages', subcategory: 'Juices', unit: 'L', prices: generatePrices(11.99) },
  { id: 151, name: 'Cranberry Juice 1L', category: 'Beverages', subcategory: 'Juices', unit: 'L', prices: generatePrices(14.99) },
  
  // Tea & Coffee
  { id: 152, name: 'Tea Bags 40 Pack', category: 'Beverages', subcategory: 'Tea & Coffee', unit: 'pack', prices: generatePrices(9.99) },
  { id: 153, name: 'Green Tea 40 Bags', category: 'Beverages', subcategory: 'Tea & Coffee', unit: 'pack', prices: generatePrices(11.99) },
  { id: 154, name: 'Coffee Ground 200g', category: 'Beverages', subcategory: 'Tea & Coffee', unit: 'g', prices: generatePrices(24.99) },
  { id: 155, name: 'Instant Coffee 100g', category: 'Beverages', subcategory: 'Tea & Coffee', unit: 'g', prices: generatePrices(19.99) },
  
  // Energy Drinks
  { id: 156, name: 'Red Bull 250ml', category: 'Beverages', subcategory: 'Energy Drinks', unit: 'ml', prices: generatePrices(19.99) },
  { id: 157, name: 'Monster Energy 500ml', category: 'Beverages', subcategory: 'Energy Drinks', unit: 'ml', prices: generatePrices(24.99) },
  
  // Milk Alternatives
  { id: 158, name: 'Almond Milk 1L', category: 'Beverages', subcategory: 'Milk Alternatives', unit: 'L', prices: generatePrices(19.99) },
  { id: 159, name: 'Soy Milk 1L', category: 'Beverages', subcategory: 'Milk Alternatives', unit: 'L', prices: generatePrices(18.99) },
  { id: 160, name: 'Oat Milk 1L', category: 'Beverages', subcategory: 'Milk Alternatives', unit: 'L', prices: generatePrices(21.99) },

  // ===== 7. SNACKS & CONFECTIONERY (50 products) =====
  // Chips & Crisps
  { id: 161, name: 'Potato Chips 150g', category: 'Snacks', subcategory: 'Chips', unit: 'g', prices: generatePrices(8.99) },
  { id: 162, name: 'Corn Chips 150g', category: 'Snacks', subcategory: 'Chips', unit: 'g', prices: generatePrices(7.99) },
  { id: 163, name: 'Tortilla Chips 150g', category: 'Snacks', subcategory: 'Chips', unit: 'g', prices: generatePrices(8.99) },
  
  // Biscuits & Cookies
  { id: 164, name: 'Digestive Biscuits 300g', category: 'Snacks', subcategory: 'Biscuits', unit: 'g', prices: generatePrices(9.99) },
  { id: 165, name: 'Cream Crackers 300g', category: 'Snacks', subcategory: 'Biscuits', unit: 'g', prices: generatePrices(8.99) },
  
  // Chocolate & Sweets
  { id: 166, name: 'Chocolate Bar 50g', category: 'Snacks', subcategory: 'Chocolate', unit: 'g', prices: generatePrices(6.99) },
  { id: 167, name: 'Candy Mix 200g', category: 'Snacks', subcategory: 'Candy', unit: 'g', prices: generatePrices(9.99) },
  
  // Nuts & Dried Fruit
  { id: 168, name: 'Peanuts 200g', category: 'Snacks', subcategory: 'Nuts', unit: 'g', prices: generatePrices(12.99) },
  { id: 169, name: 'Almonds 200g', category: 'Snacks', subcategory: 'Nuts', unit: 'g', prices: generatePrices(16.99) },
  { id: 170, name: 'Raisins 200g', category: 'Snacks', subcategory: 'Dried Fruit', unit: 'g', prices: generatePrices(11.99) },
  
  // Snack Bars
  { id: 171, name: 'Granola Bar 5 Pack', category: 'Snacks', subcategory: 'Bars', unit: 'pack', prices: generatePrices(11.99) },
  { id: 172, name: 'Protein Bar 50g', category: 'Snacks', subcategory: 'Bars', unit: 'g', prices: generatePrices(8.99) },

  // ===== 8. FROZEN FOODS (40 products) =====
  // Frozen Meals
  { id: 173, name: 'Frozen Pizza 400g', category: 'Frozen', subcategory: 'Frozen Meals', unit: 'g', prices: generatePrices(12.99) },
  { id: 174, name: 'Frozen Lasagna 400g', category: 'Frozen', subcategory: 'Frozen Meals', unit: 'g', prices: generatePrices(14.99) },
  { id: 175, name: 'Frozen Burgers 400g', category: 'Frozen', subcategory: 'Frozen Meals', unit: 'g', prices: generatePrices(11.99) },
  
  // Frozen Vegetables
  { id: 176, name: 'Frozen Peas 500g', category: 'Frozen', subcategory: 'Frozen Vegetables', unit: 'g', prices: generatePrices(10.99) },
  { id: 177, name: 'Frozen Corn 500g', category: 'Frozen', subcategory: 'Frozen Vegetables', unit: 'g', prices: generatePrices(10.99) },
  { id: 178, name: 'Frozen Broccoli 500g', category: 'Frozen', subcategory: 'Frozen Vegetables', unit: 'g', prices: generatePrices(11.99) },
  
  // Frozen Fruits
  { id: 179, name: 'Frozen Strawberries 500g', category: 'Frozen', subcategory: 'Frozen Fruits', unit: 'g', prices: generatePrices(14.99) },
  { id: 180, name: 'Frozen Blueberries 300g', category: 'Frozen', subcategory: 'Frozen Fruits', unit: 'g', prices: generatePrices(16.99) },
  
  // Ice Cream & Desserts
  { id: 181, name: 'Vanilla Ice Cream 500ml', category: 'Frozen', subcategory: 'Ice Cream', unit: 'ml', prices: generatePrices(14.99) },
  { id: 182, name: 'Chocolate Ice Cream 500ml', category: 'Frozen', subcategory: 'Ice Cream', unit: 'ml', prices: generatePrices(14.99) },
  
  // Frozen Meat Products
  { id: 183, name: 'Frozen Fish Fillets 400g', category: 'Frozen', subcategory: 'Frozen Meat', unit: 'g', prices: generatePrices(14.99) },
  { id: 184, name: 'Frozen Chicken Nuggets 400g', category: 'Frozen', subcategory: 'Frozen Meat', unit: 'g', prices: generatePrices(11.99) },

  // ===== 9. HOUSEHOLD & CLEANING (40 products) =====
  { id: 185, name: 'Dishwashing Liquid 500ml', category: 'Household', subcategory: 'Cleaning', unit: 'ml', prices: generatePrices(7.99) },
  { id: 186, name: 'Laundry Detergent 1L', category: 'Household', subcategory: 'Cleaning', unit: 'L', prices: generatePrices(12.99) },
  { id: 187, name: 'Fabric Softener 500ml', category: 'Household', subcategory: 'Cleaning', unit: 'ml', prices: generatePrices(8.99) },
  { id: 188, name: 'All Purpose Cleaner 500ml', category: 'Household', subcategory: 'Cleaning', unit: 'ml', prices: generatePrices(8.99) },
  { id: 189, name: 'Bleach 500ml', category: 'Household', subcategory: 'Cleaning', unit: 'ml', prices: generatePrices(6.99) },
  { id: 190, name: 'Sponges 3 Pack', category: 'Household', subcategory: 'Cleaning', unit: 'pack', prices: generatePrices(4.99) },
  { id: 191, name: 'Toilet Paper 12 Roll', category: 'Household', subcategory: 'Paper Products', unit: 'pack', prices: generatePrices(14.99) },
  { id: 192, name: 'Paper Towels 6 Roll', category: 'Household', subcategory: 'Paper Products', unit: 'pack', prices: generatePrices(11.99) },
  { id: 193, name: 'Tissues 200 Pack', category: 'Household', subcategory: 'Paper Products', unit: 'pack', prices: generatePrices(6.99) },
  { id: 194, name: 'Bin Liners 50 Pack', category: 'Household', subcategory: 'Paper Products', unit: 'pack', prices: generatePrices(9.99) },

  // ===== 10. PERSONAL CARE & HYGIENE (40 products) =====
  { id: 195, name: 'Toothpaste 100ml', category: 'Personal Care', subcategory: 'Oral Care', unit: 'ml', prices: generatePrices(9.99) },
  { id: 196, name: 'Toothbrush', category: 'Personal Care', subcategory: 'Oral Care', unit: 'each', prices: generatePrices(6.99) },
  { id: 197, name: 'Soap 100g', category: 'Personal Care', subcategory: 'Bath', unit: 'g', prices: generatePrices(5.99) },
  { id: 198, name: 'Body Wash 250ml', category: 'Personal Care', subcategory: 'Bath', unit: 'ml', prices: generatePrices(8.99) },
  { id: 199, name: 'Shampoo 250ml', category: 'Personal Care', subcategory: 'Hair Care', unit: 'ml', prices: generatePrices(9.99) },
  { id: 200, name: 'Conditioner 250ml', category: 'Personal Care', subcategory: 'Hair Care', unit: 'ml', prices: generatePrices(9.99) },
  { id: 201, name: 'Deodorant 150ml', category: 'Personal Care', subcategory: 'Deodorant', unit: 'ml', prices: generatePrices(7.99) },
  { id: 202, name: 'Toilet Paper 12 Roll', category: 'Personal Care', subcategory: 'Hygiene', unit: 'pack', prices: generatePrices(14.99) },
  { id: 203, name: 'Feminine Hygiene Pads 20 Pack', category: 'Personal Care', subcategory: 'Hygiene', unit: 'pack', prices: generatePrices(12.99) },
  { id: 204, name: 'Razors 4 Pack', category: 'Personal Care', subcategory: 'Shaving', unit: 'pack', prices: generatePrices(14.99) },
  { id: 205, name: 'Shaving Cream 200ml', category: 'Personal Care', subcategory: 'Shaving', unit: 'ml', prices: generatePrices(7.99) },

  // ===== 11. BABY PRODUCTS (30 products) =====
  { id: 206, name: 'Baby Formula 400g', category: 'Baby', subcategory: 'Formula', unit: 'g', searchKeywords: ['formula', 'milk'], prices: generatePrices(34.99) },
  { id: 207, name: 'Baby Food Puree 100g', category: 'Baby', subcategory: 'Food', unit: 'g', searchKeywords: ['baby food', 'puree'], prices: generatePrices(8.99) },
  { id: 208, name: 'Diapers Size 1 30 Pack', category: 'Baby', subcategory: 'Diapers', unit: 'pack', searchKeywords: ['nappies', 'diapers', 'nappy'], prices: generatePrices(24.99) },
  { id: 209, name: 'Diapers Size 2 30 Pack', category: 'Baby', subcategory: 'Diapers', unit: 'pack', searchKeywords: ['nappies', 'diapers', 'nappy'], prices: generatePrices(26.99) },
  { id: 210, name: 'Diapers Size 3 30 Pack', category: 'Baby', subcategory: 'Diapers', unit: 'pack', searchKeywords: ['nappies', 'diapers', 'nappy'], prices: generatePrices(28.99) },
  { id: 211, name: 'Diapers Size 4 30 Pack', category: 'Baby', subcategory: 'Diapers', unit: 'pack', searchKeywords: ['nappies', 'diapers', 'nappy'], prices: generatePrices(29.99) },
  { id: 212, name: 'Diapers Size 5 30 Pack', category: 'Baby', subcategory: 'Diapers', unit: 'pack', searchKeywords: ['nappies', 'diapers', 'nappy'], prices: generatePrices(31.99) },
  { id: 213, name: 'Baby Wipes 80 Pack', category: 'Baby', subcategory: 'Wipes', unit: 'pack', searchKeywords: ['wipes', 'baby wipes'], prices: generatePrices(12.99) },
  { id: 214, name: 'Baby Shampoo 200ml', category: 'Baby', subcategory: 'Toiletries', unit: 'ml', searchKeywords: ['shampoo', 'baby care'], prices: generatePrices(8.99) },

  // ===== 12. PET SUPPLIES (30 products) =====
  { id: 215, name: 'Dog Food 2kg', category: 'Pet', subcategory: 'Dog Food', unit: 'kg', searchKeywords: ['dog', 'pet food'], prices: generatePrices(19.99) },
  { id: 216, name: 'Cat Food 1.5kg', category: 'Pet', subcategory: 'Cat Food', unit: 'kg', searchKeywords: ['cat', 'pet food'], prices: generatePrices(16.99) },
  { id: 217, name: 'Dog Treats 200g', category: 'Pet', subcategory: 'Treats', unit: 'g', searchKeywords: ['treats', 'pet treats'], prices: generatePrices(9.99) },
  { id: 218, name: 'Cat Litter 5kg', category: 'Pet', subcategory: 'Litter', unit: 'kg', searchKeywords: ['litter', 'cat litter'], prices: generatePrices(14.99) },
  { id: 219, name: 'Pet Shampoo 250ml', category: 'Pet', subcategory: 'Care', unit: 'ml', searchKeywords: ['shampoo', 'pet care'], prices: generatePrices(8.99) },

  // ===== 13. READY-TO-EAT / CONVENIENCE (30 products) =====
  { id: 220, name: 'Pre-cooked Meal 400g', category: 'Ready-to-Eat', subcategory: 'Meals', unit: 'g', searchKeywords: ['meal', 'ready to eat'], prices: generatePrices(14.99) },
  { id: 221, name: 'Sandwich Pack', category: 'Ready-to-Eat', subcategory: 'Sandwiches', unit: 'each', searchKeywords: ['sandwich', 'lunch'], prices: generatePrices(12.99) },
  { id: 222, name: 'Rotisserie Chicken 1.5kg', category: 'Ready-to-Eat', subcategory: 'Chicken', unit: 'kg', searchKeywords: ['chicken', 'ready to eat'], prices: generatePrices(34.99) },
  { id: 223, name: 'Prepared Salad 300g', category: 'Ready-to-Eat', subcategory: 'Salads', unit: 'g', searchKeywords: ['salad', 'vegetables'], prices: generatePrices(11.99) },

  // ===== 14. EXTRAS / MISCELLANEOUS (20 products) =====
  { id: 224, name: 'Ice 2kg', category: 'Miscellaneous', subcategory: 'Ice', unit: 'kg', searchKeywords: ['ice'], prices: generatePrices(4.99) },
  { id: 225, name: 'Party Plates 50 Pack', category: 'Miscellaneous', subcategory: 'Party Supplies', unit: 'pack', searchKeywords: ['plates', 'party'], prices: generatePrices(6.99) },
  { id: 226, name: 'Party Cups 50 Pack', category: 'Miscellaneous', subcategory: 'Party Supplies', unit: 'pack', searchKeywords: ['cups', 'party'], prices: generatePrices(5.99) },
  { id: 227, name: 'Napkins 100 Pack', category: 'Miscellaneous', subcategory: 'Party Supplies', unit: 'pack', searchKeywords: ['napkins', 'party'], prices: generatePrices(4.99) },
  { id: 228, name: 'Batteries AA 4 Pack', category: 'Miscellaneous', subcategory: 'Batteries', unit: 'pack', searchKeywords: ['batteries'], prices: generatePrices(8.99) },
  { id: 229, name: 'Light Bulbs LED 60W', category: 'Miscellaneous', subcategory: 'Lighting', unit: 'each', searchKeywords: ['bulbs', 'lighting'], prices: generatePrices(12.99) },

  // ===== CLEANING & PERSONAL CARE (70+ products) =====
  // Dishwashing & Kitchen Cleaning
  { id: 230, name: 'Handy Andy All Purpose Cleaner 750ml', category: 'Cleaning', subcategory: 'All Purpose Cleaners', unit: 'bottle', searchKeywords: ['handy andy', 'cleaner', 'all purpose'], prices: generatePrices(8.99) },
  { id: 231, name: 'Jik Bleach 750ml', category: 'Cleaning', subcategory: 'Bleach', unit: 'bottle', searchKeywords: ['jik', 'bleach', 'disinfectant'], prices: generatePrices(7.99) },
  { id: 232, name: 'Domestos Bleach 750ml', category: 'Cleaning', subcategory: 'Bleach', unit: 'bottle', searchKeywords: ['domestos', 'bleach'], prices: generatePrices(8.49) },
  { id: 233, name: 'Sunlight Dishwashing Liquid 500ml', category: 'Cleaning', subcategory: 'Dishwashing', unit: 'bottle', searchKeywords: ['sunlight', 'dishwashing', 'dish soap'], prices: generatePrices(6.99) },
  { id: 234, name: 'Palmolive Dishwashing Liquid 500ml', category: 'Cleaning', subcategory: 'Dishwashing', unit: 'bottle', searchKeywords: ['palmolive', 'dishwashing'], prices: generatePrices(7.49) },
  { id: 235, name: 'Fairy Dishwashing Liquid 500ml', category: 'Cleaning', subcategory: 'Dishwashing', unit: 'bottle', searchKeywords: ['fairy', 'dishwashing'], prices: generatePrices(7.99) },
  { id: 236, name: 'Dettol Surface Cleaner 500ml', category: 'Cleaning', subcategory: 'Surface Cleaners', unit: 'bottle', searchKeywords: ['dettol', 'surface cleaner', 'disinfectant'], prices: generatePrices(9.99) },
  { id: 237, name: 'Lysol Surface Disinfectant 400ml', category: 'Cleaning', subcategory: 'Surface Cleaners', unit: 'can', searchKeywords: ['lysol', 'disinfectant'], prices: generatePrices(10.99) },
  { id: 238, name: 'Mr Muscle Window Cleaner 500ml', category: 'Cleaning', subcategory: 'Window Cleaners', unit: 'bottle', searchKeywords: ['mr muscle', 'window cleaner'], prices: generatePrices(8.49) },
  { id: 239, name: 'Windolene Glass Cleaner 500ml', category: 'Cleaning', subcategory: 'Window Cleaners', unit: 'bottle', searchKeywords: ['windolene', 'glass cleaner'], prices: generatePrices(7.99) },
  { id: 240, name: 'Cobra Floor Cleaner 750ml', category: 'Cleaning', subcategory: 'Floor Cleaners', unit: 'bottle', searchKeywords: ['cobra', 'floor cleaner'], prices: generatePrices(6.99) },
  { id: 241, name: 'Jeyes Fluid 750ml', category: 'Cleaning', subcategory: 'Floor Cleaners', unit: 'bottle', searchKeywords: ['jeyes', 'floor cleaner', 'disinfectant'], prices: generatePrices(7.49) },
  { id: 242, name: 'Toilet Duck 500ml', category: 'Cleaning', subcategory: 'Toilet Cleaners', unit: 'bottle', searchKeywords: ['toilet duck', 'toilet cleaner'], prices: generatePrices(8.99) },
  { id: 243, name: 'Harpic Toilet Cleaner 500ml', category: 'Cleaning', subcategory: 'Toilet Cleaners', unit: 'bottle', searchKeywords: ['harpic', 'toilet cleaner'], prices: generatePrices(8.49) },

  // Laundry Products
  { id: 244, name: 'Surf Laundry Detergent 1kg', category: 'Cleaning', subcategory: 'Laundry Detergent', unit: 'pack', searchKeywords: ['surf', 'detergent', 'laundry'], prices: generatePrices(14.99) },
  { id: 245, name: 'Omo Laundry Detergent 1kg', category: 'Cleaning', subcategory: 'Laundry Detergent', unit: 'pack', searchKeywords: ['omo', 'detergent'], prices: generatePrices(15.49) },
  { id: 246, name: 'Persil Laundry Detergent 1kg', category: 'Cleaning', subcategory: 'Laundry Detergent', unit: 'pack', searchKeywords: ['persil', 'detergent'], prices: generatePrices(16.99) },
  { id: 247, name: 'Ariel Laundry Detergent 1kg', category: 'Cleaning', subcategory: 'Laundry Detergent', unit: 'pack', searchKeywords: ['ariel', 'detergent'], prices: generatePrices(17.49) },
  { id: 248, name: 'Sunlight Fabric Softener 1L', category: 'Cleaning', subcategory: 'Fabric Softener', unit: 'bottle', searchKeywords: ['sunlight', 'fabric softener'], prices: generatePrices(9.99) },
  { id: 249, name: 'Comfort Fabric Softener 1L', category: 'Cleaning', subcategory: 'Fabric Softener', unit: 'bottle', searchKeywords: ['comfort', 'fabric softener'], prices: generatePrices(10.49) },
  { id: 250, name: 'Downy Fabric Softener 1L', category: 'Cleaning', subcategory: 'Fabric Softener', unit: 'bottle', searchKeywords: ['downy', 'fabric softener'], prices: generatePrices(11.99) },
  { id: 251, name: 'Shout Stain Remover 500ml', category: 'Cleaning', subcategory: 'Stain Removers', unit: 'bottle', searchKeywords: ['shout', 'stain remover'], prices: generatePrices(11.49) },
  { id: 252, name: 'Vanish Stain Remover 500ml', category: 'Cleaning', subcategory: 'Stain Removers', unit: 'bottle', searchKeywords: ['vanish', 'stain remover'], prices: generatePrices(12.99) },
  { id: 253, name: 'OxiClean Stain Remover 500g', category: 'Cleaning', subcategory: 'Stain Removers', unit: 'pack', searchKeywords: ['oxiclean', 'stain remover'], prices: generatePrices(10.99) },

  // Personal Care - Soaps & Body Wash
  { id: 254, name: 'Lux Soap Bar 100g', category: 'Personal Care', subcategory: 'Soap Bars', unit: 'bar', searchKeywords: ['lux', 'soap', 'bath soap'], prices: generatePrices(3.99) },
  { id: 255, name: 'Lifebuoy Soap Bar 100g', category: 'Personal Care', subcategory: 'Soap Bars', unit: 'bar', searchKeywords: ['lifebuoy', 'soap'], prices: generatePrices(3.49) },
  { id: 256, name: 'Dettol Soap Bar 100g', category: 'Personal Care', subcategory: 'Soap Bars', unit: 'bar', searchKeywords: ['dettol', 'soap', 'antibacterial'], prices: generatePrices(4.99) },
  { id: 257, name: 'Dove Soap Bar 100g', category: 'Personal Care', subcategory: 'Soap Bars', unit: 'bar', searchKeywords: ['dove', 'soap'], prices: generatePrices(5.99) },
  { id: 258, name: 'Protex Soap Bar 100g', category: 'Personal Care', subcategory: 'Soap Bars', unit: 'bar', searchKeywords: ['protex', 'soap'], prices: generatePrices(4.49) },
  { id: 259, name: 'Dettol Body Wash 400ml', category: 'Personal Care', subcategory: 'Body Wash', unit: 'bottle', searchKeywords: ['dettol', 'body wash'], prices: generatePrices(8.99) },
  { id: 260, name: 'Dove Body Wash 400ml', category: 'Personal Care', subcategory: 'Body Wash', unit: 'bottle', searchKeywords: ['dove', 'body wash'], prices: generatePrices(9.99) },
  { id: 261, name: 'Lux Body Wash 400ml', category: 'Personal Care', subcategory: 'Body Wash', unit: 'bottle', searchKeywords: ['lux', 'body wash'], prices: generatePrices(8.49) },
  { id: 262, name: 'Vaseline Body Lotion 400ml', category: 'Personal Care', subcategory: 'Body Wash', unit: 'bottle', searchKeywords: ['vaseline', 'body lotion'], prices: generatePrices(9.49) },

  // Shampoo & Conditioner
  { id: 263, name: 'Head & Shoulders Shampoo 400ml', category: 'Personal Care', subcategory: 'Shampoo', unit: 'bottle', searchKeywords: ['head and shoulders', 'shampoo'], prices: generatePrices(11.99) },
  { id: 264, name: 'Sunsilk Shampoo 400ml', category: 'Personal Care', subcategory: 'Shampoo', unit: 'bottle', searchKeywords: ['sunsilk', 'shampoo'], prices: generatePrices(10.49) },
  { id: 265, name: 'Pantene Shampoo 400ml', category: 'Personal Care', subcategory: 'Shampoo', unit: 'bottle', searchKeywords: ['pantene', 'shampoo'], prices: generatePrices(12.49) },
  { id: 266, name: 'Dove Shampoo 400ml', category: 'Personal Care', subcategory: 'Shampoo', unit: 'bottle', searchKeywords: ['dove', 'shampoo'], prices: generatePrices(11.49) },
  { id: 267, name: 'TRESemmé Shampoo 400ml', category: 'Personal Care', subcategory: 'Shampoo', unit: 'bottle', searchKeywords: ['tresemme', 'shampoo'], prices: generatePrices(10.99) },
  { id: 268, name: 'Garnier Fructis Shampoo 400ml', category: 'Personal Care', subcategory: 'Shampoo', unit: 'bottle', searchKeywords: ['garnier', 'shampoo'], prices: generatePrices(11.99) },
  { id: 269, name: 'Head & Shoulders Conditioner 400ml', category: 'Personal Care', subcategory: 'Conditioner', unit: 'bottle', searchKeywords: ['head and shoulders', 'conditioner'], prices: generatePrices(11.99) },
  { id: 270, name: 'Sunsilk Conditioner 400ml', category: 'Personal Care', subcategory: 'Conditioner', unit: 'bottle', searchKeywords: ['sunsilk', 'conditioner'], prices: generatePrices(10.49) },
  { id: 271, name: 'Pantene Conditioner 400ml', category: 'Personal Care', subcategory: 'Conditioner', unit: 'bottle', searchKeywords: ['pantene', 'conditioner'], prices: generatePrices(12.49) },
  { id: 272, name: 'Dove Conditioner 400ml', category: 'Personal Care', subcategory: 'Conditioner', unit: 'bottle', searchKeywords: ['dove', 'conditioner'], prices: generatePrices(11.49) },

  // Deodorant
  { id: 273, name: 'Rexona Deodorant Spray 150ml', category: 'Personal Care', subcategory: 'Deodorant', unit: 'can', searchKeywords: ['rexona', 'deodorant'], prices: generatePrices(7.99) },
  { id: 274, name: 'Dove Deodorant Spray 150ml', category: 'Personal Care', subcategory: 'Deodorant', unit: 'can', searchKeywords: ['dove', 'deodorant'], prices: generatePrices(8.49) },
  { id: 275, name: 'Old Spice Deodorant Spray 150ml', category: 'Personal Care', subcategory: 'Deodorant', unit: 'can', searchKeywords: ['old spice', 'deodorant'], prices: generatePrices(8.99) },
  { id: 276, name: 'Sure Deodorant Spray 150ml', category: 'Personal Care', subcategory: 'Deodorant', unit: 'can', searchKeywords: ['sure', 'deodorant'], prices: generatePrices(7.49) },
  { id: 277, name: 'Axe Deodorant Spray 150ml', category: 'Personal Care', subcategory: 'Deodorant', unit: 'can', searchKeywords: ['axe', 'deodorant'], prices: generatePrices(8.99) },

  // Toothpaste & Oral Care
  { id: 278, name: 'Colgate Toothpaste 100ml', category: 'Personal Care', subcategory: 'Toothpaste', unit: 'tube', searchKeywords: ['colgate', 'toothpaste'], prices: generatePrices(6.99) },
  { id: 279, name: 'Sensodyne Toothpaste 100ml', category: 'Personal Care', subcategory: 'Toothpaste', unit: 'tube', searchKeywords: ['sensodyne', 'toothpaste'], prices: generatePrices(8.99) },
  { id: 280, name: 'Crest Toothpaste 100ml', category: 'Personal Care', subcategory: 'Toothpaste', unit: 'tube', searchKeywords: ['crest', 'toothpaste'], prices: generatePrices(7.49) },
  { id: 281, name: 'Close Up Toothpaste 100ml', category: 'Personal Care', subcategory: 'Toothpaste', unit: 'tube', searchKeywords: ['close up', 'toothpaste'], prices: generatePrices(6.49) },
  { id: 282, name: 'Listerine Mouthwash 500ml', category: 'Personal Care', subcategory: 'Oral Care', unit: 'bottle', searchKeywords: ['listerine', 'mouthwash'], prices: generatePrices(9.99) },
  { id: 283, name: 'Colgate Mouthwash 500ml', category: 'Personal Care', subcategory: 'Oral Care', unit: 'bottle', searchKeywords: ['colgate', 'mouthwash'], prices: generatePrices(8.99) },

  // Razors & Shaving
  { id: 284, name: 'Gillette Razor Blades 4 Pack', category: 'Personal Care', subcategory: 'Razors', unit: 'pack', searchKeywords: ['gillette', 'razor', 'blades'], prices: generatePrices(14.99) },
  { id: 285, name: 'Wilkinson Sword Razor Blades 4 Pack', category: 'Personal Care', subcategory: 'Razors', unit: 'pack', searchKeywords: ['wilkinson', 'razor'], prices: generatePrices(13.99) },
  { id: 286, name: 'Shaving Cream 200ml', category: 'Personal Care', subcategory: 'Razors', unit: 'tube', searchKeywords: ['shaving cream'], prices: generatePrices(7.99) },
  { id: 287, name: 'Aftershave Lotion 100ml', category: 'Personal Care', subcategory: 'Razors', unit: 'bottle', searchKeywords: ['aftershave'], prices: generatePrices(9.99) },

  // Household Cleaning Supplies
  { id: 288, name: 'Sponge Scourer 3 Pack', category: 'Household', subcategory: 'Cleaning Supplies', unit: 'pack', searchKeywords: ['sponge', 'scourer'], prices: generatePrices(4.99) },
  { id: 289, name: 'Microfiber Cloth 3 Pack', category: 'Household', subcategory: 'Cleaning Supplies', unit: 'pack', searchKeywords: ['microfiber', 'cloth'], prices: generatePrices(6.99) },
  { id: 290, name: 'Dish Brush', category: 'Household', subcategory: 'Cleaning Supplies', unit: 'each', searchKeywords: ['dish brush', 'brush'], prices: generatePrices(3.99) },
  { id: 291, name: 'Mop Head Replacement', category: 'Household', subcategory: 'Cleaning Supplies', unit: 'each', searchKeywords: ['mop', 'mop head'], prices: generatePrices(8.99) },
  { id: 292, name: 'Bin Liners 30 Pack', category: 'Household', subcategory: 'Bin Liners', unit: 'pack', searchKeywords: ['bin liners', 'garbage bags'], prices: generatePrices(5.99) },
  { id: 293, name: 'Bin Liners 50 Pack', category: 'Household', subcategory: 'Bin Liners', unit: 'pack', searchKeywords: ['bin liners', 'garbage bags'], prices: generatePrices(8.99) },
];

// Add search keywords to all products for smart search
export function getProductsWithKeywords(): Product[] {
  return COMPLETE_PRODUCTS.map(product => ({
    ...product,
    searchKeywords: [
      ...((product.searchKeywords || []) as string[]),
      product.category.toLowerCase(),
      product.subcategory.toLowerCase(),
    ],
  }));
}

export function getAllProducts(): Product[] {
  return COMPLETE_PRODUCTS;
}
