/**
 * Product Image Mapping System
 * Smart category-based image URLs for all 1,500 products
 * Uses Unsplash and reliable sources for high-quality images
 */

export const CATEGORY_IMAGES: Record<string, Record<string, string>> = {
  Dairy: {
    Milk: 'https://images.unsplash.com/photo-1550583573-3ceba9fda8a9?w=400&q=80',
    Cheese: 'https://images.unsplash.com/photo-1452894895917-032f4b319b23?w=400&q=80',
    Yogurt: 'https://images.unsplash.com/photo-1488477181946-6428a0291840?w=400&q=80',
    'Butter & Spreads': 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&q=80',
    Eggs: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=400&q=80',
    'Milk Alternatives': 'https://images.unsplash.com/photo-1585518419759-66b5f1b46d51?w=400&q=80',
    'Cream & Custard': 'https://images.unsplash.com/photo-1488477181946-6428a0291840?w=400&q=80',
  },
  Meat: {
    Beef: 'https://images.unsplash.com/photo-1555939594-58d7cb561404?w=400&q=80',
    Chicken: 'https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=400&q=80',
    Pork: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&q=80',
    Lamb: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&q=80',
    'Processed Meat': 'https://images.unsplash.com/photo-1585238341710-4913d3a3a48f?w=400&q=80',
    Seafood: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&q=80',
  },
  Produce: {
    Vegetables: 'https://images.unsplash.com/photo-1488459716781-6918f33fc993?w=400&q=80',
    Fruits: 'https://images.unsplash.com/photo-1599599810694-b5ac4dd64e90?w=400&q=80',
    'Herbs & Spices': 'https://images.unsplash.com/photo-1596040694312-923340fdce63?w=400&q=80',
    'Nuts & Seeds': 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
  },
  Bakery: {
    Bread: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&q=80',
    'Buns & Rolls': 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&q=80',
    'Cakes & Pastries': 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&q=80',
    'Biscuits & Cookies': 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400&q=80',
  },
  Pantry: {
    'Rice & Grains': 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=400&q=80',
    Pasta: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&q=80',
    'Flour & Baking': 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
    'Oils & Vinegars': 'https://images.unsplash.com/photo-1587734414071-8151a3a9c488?w=400&q=80',
    'Sauces & Condiments': 'https://images.unsplash.com/photo-1599599810694-b5ac4dd64e90?w=400&q=80',
    'Canned & Jarred': 'https://images.unsplash.com/photo-1599599810694-b5ac4dd64e90?w=400&q=80',
    'Spices & Seasonings': 'https://images.unsplash.com/photo-1596040694312-923340fdce63?w=400&q=80',
  },
  Beverages: {
    'Soft Drinks': 'https://images.unsplash.com/photo-1554866585-e9c0a7c8f3c5?w=400&q=80',
    Juice: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&q=80',
    'Coffee & Tea': 'https://images.unsplash.com/photo-1559056199-641a0ac8b3f4?w=400&q=80',
    'Energy & Sports': 'https://images.unsplash.com/photo-1554866585-e9c0a7c8f3c5?w=400&q=80',
    Water: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400&q=80',
  },
  Frozen: {
    Vegetables: 'https://images.unsplash.com/photo-1488459716781-6918f33fc993?w=400&q=80',
    Fruits: 'https://images.unsplash.com/photo-1599599810694-b5ac4dd64e90?w=400&q=80',
    Meals: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&q=80',
    'Ice Cream': 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&q=80',
  },
  Snacks: {
    'Chips & Crisps': 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
    'Chocolate & Candy': 'https://images.unsplash.com/photo-1599599810694-b5ac4dd64e90?w=400&q=80',
    'Nuts & Trail Mix': 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
    'Popcorn & Puffed': 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
  },
  Household: {
    Laundry: 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
    Cleaning: 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
    Dishwashing: 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
    'Personal Care': 'https://images.unsplash.com/photo-1585707032515-6213f3a845fd?w=400&q=80',
  },
};

// Fallback image for missing products
export const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1488459716781-6918f33fc993?w=400&q=80';

/**
 * Get product image URL based on category and subcategory
 */
export function getProductImage(category: string, subcategory: string): string {
  const categoryImages = CATEGORY_IMAGES[category];
  if (categoryImages && categoryImages[subcategory]) {
    return categoryImages[subcategory];
  }
  return FALLBACK_IMAGE;
}

/**
 * Product image with fallback handling
 */
export function getProductImageWithFallback(category: string, subcategory: string): string {
  return getProductImage(category, subcategory);
}
