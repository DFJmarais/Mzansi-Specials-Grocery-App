/**
 * Store Locations Database
 * Contains coordinates for all major South African retailers
 * Covers major cities and regions
 */

export interface StoreLocation {
  id: string;
  name: string;
  store: 'Spar' | 'Pick n Pay' | 'Checkers' | 'OK Foods' | 'ShopRite' | 'Woolworths';
  latitude: number;
  longitude: number;
  address: string;
  city: string;
  province: string;
  phone?: string;
  hours?: string;
}

export const STORE_LOCATIONS: StoreLocation[] = [
  // JOHANNESBURG & GAUTENG
  // Spar locations
  { id: 'spar_jnb_1', name: 'Spar Sandton', store: 'Spar', latitude: -26.1055, longitude: 28.0550, address: 'Sandton City, Johannesburg', city: 'Johannesburg', province: 'Gauteng', phone: '011 784 8000', hours: '08:00-21:00' },
  { id: 'spar_jnb_2', name: 'Spar Rosebank', store: 'Spar', latitude: -26.1373, longitude: 28.0425, address: 'The Zone, Rosebank', city: 'Johannesburg', province: 'Gauteng', phone: '011 788 1000', hours: '08:00-21:00' },
  { id: 'spar_jnb_3', name: 'Spar Midrand', store: 'Spar', latitude: -25.9881, longitude: 28.1149, address: 'Midrand Shopping Centre', city: 'Midrand', province: 'Gauteng', phone: '011 314 3000', hours: '08:00-20:00' },
  { id: 'spar_jnb_4', name: 'Spar Fourways', store: 'Spar', latitude: -25.9506, longitude: 27.9889, address: 'Fourways Mall', city: 'Johannesburg', province: 'Gauteng', phone: '011 467 1000', hours: '08:00-21:00' },

  // Pick n Pay locations
  { id: 'pnp_jnb_1', name: 'Pick n Pay Sandton', store: 'Pick n Pay', latitude: -26.1040, longitude: 28.0565, address: 'Sandton City, Johannesburg', city: 'Johannesburg', province: 'Gauteng', phone: '011 784 9000', hours: '08:00-22:00' },
  { id: 'pnp_jnb_2', name: 'Pick n Pay Rosebank', store: 'Pick n Pay', latitude: -26.1380, longitude: 28.0430, address: 'Rosebank Towers', city: 'Johannesburg', province: 'Gauteng', phone: '011 788 2000', hours: '08:00-22:00' },
  { id: 'pnp_jnb_3', name: 'Pick n Pay Midrand', store: 'Pick n Pay', latitude: -25.9875, longitude: 28.1155, address: 'Midrand Centre', city: 'Midrand', province: 'Gauteng', phone: '011 314 4000', hours: '08:00-21:00' },

  // Checkers locations
  { id: 'chk_jnb_1', name: 'Checkers Sandton', store: 'Checkers', latitude: -26.1050, longitude: 28.0555, address: 'Sandton City', city: 'Johannesburg', province: 'Gauteng', phone: '011 784 7000', hours: '08:00-21:00' },
  { id: 'chk_jnb_2', name: 'Checkers Rosebank', store: 'Checkers', latitude: -26.1375, longitude: 28.0420, address: 'The Zone Rosebank', city: 'Johannesburg', province: 'Gauteng', phone: '011 788 3000', hours: '08:00-21:00' },

  // Woolworths locations
  { id: 'wool_jnb_1', name: 'Woolworths Sandton', store: 'Woolworths', latitude: -26.1045, longitude: 28.0560, address: 'Sandton City', city: 'Johannesburg', province: 'Gauteng', phone: '011 784 6000', hours: '08:00-21:00' },
  { id: 'wool_jnb_2', name: 'Woolworths Rosebank', store: 'Woolworths', latitude: -26.1378, longitude: 28.0425, address: 'The Zone Rosebank', city: 'Johannesburg', province: 'Gauteng', phone: '011 788 4000', hours: '08:00-21:00' },

  // CAPE TOWN & WESTERN CAPE
  // Spar locations
  { id: 'spar_cpt_1', name: 'Spar V&A Waterfront', store: 'Spar', latitude: -33.9025, longitude: 18.4355, address: 'V&A Waterfront', city: 'Cape Town', province: 'Western Cape', phone: '021 408 7000', hours: '08:00-21:00' },
  { id: 'spar_cpt_2', name: 'Spar Constantia Nek', store: 'Spar', latitude: -34.0381, longitude: 18.3893, address: 'Constantia Centre', city: 'Cape Town', province: 'Western Cape', phone: '021 794 3000', hours: '08:00-20:00' },

  // Pick n Pay locations
  { id: 'pnp_cpt_1', name: 'Pick n Pay V&A', store: 'Pick n Pay', latitude: -33.9030, longitude: 18.4360, address: 'V&A Waterfront', city: 'Cape Town', province: 'Western Cape', phone: '021 408 8000', hours: '08:00-22:00' },
  { id: 'pnp_cpt_2', name: 'Pick n Pay Constantia', store: 'Pick n Pay', latitude: -34.0385, longitude: 18.3895, address: 'Constantia Centre', city: 'Cape Town', province: 'Western Cape', phone: '021 794 4000', hours: '08:00-21:00' },

  // Checkers locations
  { id: 'chk_cpt_1', name: 'Checkers V&A', store: 'Checkers', latitude: -33.9020, longitude: 18.4350, address: 'V&A Waterfront', city: 'Cape Town', province: 'Western Cape', phone: '021 408 6000', hours: '08:00-21:00' },

  // Woolworths locations
  { id: 'wool_cpt_1', name: 'Woolworths V&A', store: 'Woolworths', latitude: -33.9028, longitude: 18.4358, address: 'V&A Waterfront', city: 'Cape Town', province: 'Western Cape', phone: '021 408 5000', hours: '08:00-21:00' },

  // DURBAN & KWAZULU-NATAL
  // Spar locations
  { id: 'spar_dbn_1', name: 'Spar Umhlanga', store: 'Spar', latitude: -29.7241, longitude: 31.0801, address: 'Umhlanga Ridge', city: 'Durban', province: 'KwaZulu-Natal', phone: '031 566 3000', hours: '08:00-21:00' },
  { id: 'spar_dbn_2', name: 'Spar Gateway', store: 'Spar', latitude: -29.8241, longitude: 31.0301, address: 'Gateway Theatre', city: 'Durban', province: 'KwaZulu-Natal', phone: '031 566 4000', hours: '08:00-21:00' },

  // Pick n Pay locations
  { id: 'pnp_dbn_1', name: 'Pick n Pay Umhlanga', store: 'Pick n Pay', latitude: -29.7245, longitude: 31.0805, address: 'Umhlanga Ridge', city: 'Durban', province: 'KwaZulu-Natal', phone: '031 566 5000', hours: '08:00-22:00' },

  // Checkers locations
  { id: 'chk_dbn_1', name: 'Checkers Gateway', store: 'Checkers', latitude: -29.8245, longitude: 31.0305, address: 'Gateway Theatre', city: 'Durban', province: 'KwaZulu-Natal', phone: '031 566 6000', hours: '08:00-21:00' },

  // Woolworths locations
  { id: 'wool_dbn_1', name: 'Woolworths Umhlanga', store: 'Woolworths', latitude: -29.7240, longitude: 31.0800, address: 'Umhlanga Ridge', city: 'Durban', province: 'KwaZulu-Natal', phone: '031 566 7000', hours: '08:00-21:00' },

  // PRETORIA & TSHWANE
  // Spar locations
  { id: 'spar_pta_1', name: 'Spar Menlyn', store: 'Spar', latitude: -25.7461, longitude: 28.2500, address: 'Menlyn Shopping Centre', city: 'Pretoria', province: 'Gauteng', phone: '012 368 1000', hours: '08:00-20:00' },

  // Pick n Pay locations
  { id: 'pnp_pta_1', name: 'Pick n Pay Menlyn', store: 'Pick n Pay', latitude: -25.7465, longitude: 28.2505, address: 'Menlyn Shopping Centre', city: 'Pretoria', province: 'Gauteng', phone: '012 368 2000', hours: '08:00-21:00' },

  // Woolworths locations
  { id: 'wool_pta_1', name: 'Woolworths Menlyn', store: 'Woolworths', latitude: -25.7460, longitude: 28.2495, address: 'Menlyn Shopping Centre', city: 'Pretoria', province: 'Gauteng', phone: '012 368 3000', hours: '08:00-20:00' },

  // BLOEMFONTEIN & FREE STATE
  // Spar locations
  { id: 'spar_blm_1', name: 'Spar Bloemfontein', store: 'Spar', latitude: -29.1136, longitude: 25.5184, address: 'Mimosa Mall', city: 'Bloemfontein', province: 'Free State', phone: '051 447 1000', hours: '08:00-20:00' },

  // Pick n Pay locations
  { id: 'pnp_blm_1', name: 'Pick n Pay Bloemfontein', store: 'Pick n Pay', latitude: -29.1140, longitude: 25.5190, address: 'Mimosa Mall', city: 'Bloemfontein', province: 'Free State', phone: '051 447 2000', hours: '08:00-21:00' },

  // EAST LONDON & EASTERN CAPE
  // Spar locations
  { id: 'spar_el_1', name: 'Spar East London', store: 'Spar', latitude: -33.0156, longitude: 27.9116, address: 'Hemingways', city: 'East London', province: 'Eastern Cape', phone: '043 722 1000', hours: '08:00-20:00' },

  // PORT ELIZABETH & EASTERN CAPE
  // Spar locations
  { id: 'spar_pe_1', name: 'Spar Port Elizabeth', store: 'Spar', latitude: -33.9841, longitude: 25.6045, address: 'Walmer Shopping Centre', city: 'Port Elizabeth', province: 'Eastern Cape', phone: '041 373 1000', hours: '08:00-20:00' },
];

/**
 * Calculate distance between two coordinates using Haversine formula
 * Returns distance in kilometers
 */
export const calculateDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371; // Earth's radius in kilometers
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

/**
 * Find nearest stores for a given location and store type
 */
export const findNearestStores = (
  userLat: number,
  userLon: number,
  storeType?: string,
  limit: number = 5
): (StoreLocation & { distance: number })[] => {
  let filtered = STORE_LOCATIONS;

  if (storeType) {
    filtered = filtered.filter((store) => store.store === storeType);
  }

  const withDistance = filtered.map((store) => ({
    ...store,
    distance: calculateDistance(userLat, userLon, store.latitude, store.longitude),
  }));

  return withDistance.sort((a, b) => a.distance - b.distance).slice(0, limit);
};

/**
 * Get all unique store types
 */
export const getStoreTypes = (): string[] => {
  return Array.from(new Set(STORE_LOCATIONS.map((store) => store.store)));
};

/**
 * Get stores by province
 */
export const getStoresByProvince = (province: string): StoreLocation[] => {
  return STORE_LOCATIONS.filter((store) => store.province === province);
};
