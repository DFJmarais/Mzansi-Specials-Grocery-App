CREATE TABLE `dietCategories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`slug` varchar(100) NOT NULL,
	`description` text,
	`icon` varchar(50),
	`color` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `dietCategories_id` PRIMARY KEY(`id`),
	CONSTRAINT `dietCategories_name_unique` UNIQUE(`name`),
	CONSTRAINT `dietCategories_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `dietRecommendations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productId` int NOT NULL,
	`dietCategoryId` int NOT NULL,
	`reason` varchar(255),
	`score` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`viewedAt` timestamp,
	CONSTRAINT `dietRecommendations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `productDietTags` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productId` int NOT NULL,
	`dietCategoryId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `productDietTags_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userDietPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dietCategoryId` int NOT NULL,
	`isPrimary` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userDietPreferences_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `dietRecommendations` ADD CONSTRAINT `dietRecommendations_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `dietRecommendations` ADD CONSTRAINT `dietRecommendations_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `dietRecommendations` ADD CONSTRAINT `dietRecommendations_dietCategoryId_dietCategories_id_fk` FOREIGN KEY (`dietCategoryId`) REFERENCES `dietCategories`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `productDietTags` ADD CONSTRAINT `productDietTags_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `productDietTags` ADD CONSTRAINT `productDietTags_dietCategoryId_dietCategories_id_fk` FOREIGN KEY (`dietCategoryId`) REFERENCES `dietCategories`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `userDietPreferences` ADD CONSTRAINT `userDietPreferences_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `userDietPreferences` ADD CONSTRAINT `userDietPreferences_dietCategoryId_dietCategories_id_fk` FOREIGN KEY (`dietCategoryId`) REFERENCES `dietCategories`(`id`) ON DELETE cascade ON UPDATE no action;