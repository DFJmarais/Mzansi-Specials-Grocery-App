import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, date, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Saved shopping lists for authenticated users
 */
export const shoppingLists = mysqlTable("shoppingLists", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  isDefault: int("isDefault").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ShoppingList = typeof shoppingLists.$inferSelect;
export type InsertShoppingList = typeof shoppingLists.$inferInsert;

/**
 * Items in shopping lists
 */
export const shoppingListItems = mysqlTable("shoppingListItems", {
  id: int("id").autoincrement().primaryKey(),
  listId: int("listId").notNull().references(() => shoppingLists.id, { onDelete: "cascade" }),
  productName: varchar("productName", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  quantity: int("quantity").default(1).notNull(),
  unit: varchar("unit", { length: 50 }).default("item"),
  estimatedPrice: int("estimatedPrice"),
  isChecked: int("isChecked").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ShoppingListItem = typeof shoppingListItems.$inferSelect;
export type InsertShoppingListItem = typeof shoppingListItems.$inferInsert;

/**
 * Community savings posts - users share their deals and savings
 */
export const savingsPosts = mysqlTable("savingsPosts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  amountSaved: int("amountSaved").notNull(),
  store: varchar("store", { length: 100 }),
  productCategory: varchar("productCategory", { length: 100 }),
  likes: int("likes").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SavingsPost = typeof savingsPosts.$inferSelect;
export type InsertSavingsPost = typeof savingsPosts.$inferInsert;

/**
 * Product reviews and ratings
 */
export const productReviews = mysqlTable("productReviews", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  productName: varchar("productName", { length: 255 }).notNull(),
  store: varchar("store", { length: 100 }).notNull(),
  rating: int("rating").notNull(),
  comment: text("comment"),
  helpful: int("helpful").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProductReview = typeof productReviews.$inferSelect;
export type InsertProductReview = typeof productReviews.$inferInsert;

/**
 * User achievements and badges
 */
export const userAchievements = mysqlTable("userAchievements", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  badge: varchar("badge", { length: 100 }).notNull(),
  earnedAt: timestamp("earnedAt").defaultNow().notNull(),
});

export type UserAchievement = typeof userAchievements.$inferSelect;
export type InsertUserAchievement = typeof userAchievements.$inferInsert;

// Old priceAlerts table removed - using new schema below

/**
 * Product catalog for grocery items
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  category: varchar("category", { length: 100 }).notNull(),
  description: text("description"),
  imageUrl: varchar("imageUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Live prices from different retailers with trust scoring
 */
export const prices = mysqlTable("prices", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull().references(() => products.id, { onDelete: "cascade" }),
  storeName: varchar("storeName", { length: 100 }).notNull(),
  price: int("price").notNull(),
  originalPrice: int("originalPrice"),
  discount: int("discount"),
  url: varchar("url", { length: 500 }),
  
  // Trust & Verification Fields
  trustScore: int("trustScore").default(100).notNull(), // 0-100
  trustLevel: mysqlEnum("trustLevel", ["HIGH", "MEDIUM", "LOW"]).default("MEDIUM").notNull(),
  verificationStatus: mysqlEnum("verificationStatus", ["VERIFIED", "UNVERIFIED", "FLAGGED"]).default("UNVERIFIED").notNull(),
  sourcesCount: int("sourcesCount").default(0).notNull(), // Number of verified sources
  sources: json("sources"), // Array of source objects: {sourceName, sourceType, sourceUrl, verified, timestamp}
  flags: json("flags"), // Array of issues: ["price_outlier", "stale_data", etc]
  
  // Timestamps
  lastUpdated: timestamp("lastUpdated").defaultNow().notNull(),
  lastVerified: timestamp("lastVerified"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Price = typeof prices.$inferSelect;
export type InsertPrice = typeof prices.$inferInsert;

/**
 * Price verification logs for audit trail
 */
export const priceVerificationLogs = mysqlTable("priceVerificationLogs", {
  id: int("id").autoincrement().primaryKey(),
  priceId: int("priceId").notNull().references(() => prices.id, { onDelete: "cascade" }),
  productId: int("productId").notNull().references(() => products.id, { onDelete: "cascade" }),
  previousPrice: int("previousPrice"),
  newPrice: int("newPrice"),
  previousTrustScore: int("previousTrustScore"),
  newTrustScore: int("newTrustScore"),
  changeReason: varchar("changeReason", { length: 255 }), // "verified", "manual_update", "price_drop", etc
  verifiedBy: varchar("verifiedBy", { length: 100 }), // source name or "system"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PriceVerificationLog = typeof priceVerificationLogs.$inferSelect;
export type InsertPriceVerificationLog = typeof priceVerificationLogs.$inferInsert;

/**
 * Diet categories for filtering products
 * Includes: Gluten-Free, Vegan, Keto, Dairy-Free, Organic, Sugar-Free, Halal, Kosher, Low-Sodium
 */
export const dietCategories = mysqlTable("dietCategories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }),
  color: varchar("color", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DietCategory = typeof dietCategories.$inferSelect;
export type InsertDietCategory = typeof dietCategories.$inferInsert;

/**
 * Junction table: Products tagged with diet categories
 */
export const productDietTags = mysqlTable("productDietTags", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull().references(() => products.id, { onDelete: "cascade" }),
  dietCategoryId: int("dietCategoryId").notNull().references(() => dietCategories.id, { onDelete: "cascade" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProductDietTag = typeof productDietTags.$inferSelect;
export type InsertProductDietTag = typeof productDietTags.$inferInsert;

/**
 * User diet preferences for personalized recommendations
 */
export const userDietPreferences = mysqlTable("userDietPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  dietCategoryId: int("dietCategoryId").notNull().references(() => dietCategories.id, { onDelete: "cascade" }),
  isPrimary: int("isPrimary").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserDietPreference = typeof userDietPreferences.$inferSelect;
export type InsertUserDietPreference = typeof userDietPreferences.$inferInsert;

/**
 * Diet-based product recommendations
 */
export const dietRecommendations = mysqlTable("dietRecommendations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  productId: int("productId").notNull().references(() => products.id, { onDelete: "cascade" }),
  dietCategoryId: int("dietCategoryId").notNull().references(() => dietCategories.id, { onDelete: "cascade" }),
  reason: varchar("reason", { length: 255 }),
  score: int("score").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  viewedAt: timestamp("viewedAt"),
});

export type DietRecommendation = typeof dietRecommendations.$inferSelect;
export type InsertDietRecommendation = typeof dietRecommendations.$inferInsert;

/**
 * Weekly meal plans for users
 */
export const weeklyPlans = mysqlTable("weeklyPlans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  startDate: date("startDate").notNull(),
  endDate: date("endDate").notNull(),
  budget: decimal("budget", { precision: 10, scale: 2 }),
  estimatedTotal: decimal("estimatedTotal", { precision: 10, scale: 2 }),
  actualTotal: decimal("actualTotal", { precision: 10, scale: 2 }),
  isCompleted: int("isCompleted").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeeklyPlan = typeof weeklyPlans.$inferSelect;
export type InsertWeeklyPlan = typeof weeklyPlans.$inferInsert;

/**
 * Daily meals in weekly plans
 */
export const weeklyMeals = mysqlTable("weeklyMeals", {
  id: int("id").autoincrement().primaryKey(),
  planId: int("planId").notNull().references(() => weeklyPlans.id, { onDelete: "cascade" }),
  dayOfWeek: int("dayOfWeek").notNull(), // 0-6 (Monday-Sunday)
  mealType: varchar("mealType", { length: 50 }).notNull(), // breakfast, lunch, dinner, snack
  mealName: varchar("mealName", { length: 255 }).notNull(),
  description: text("description"),
  servings: int("servings").default(1).notNull(),
  estimatedCost: decimal("estimatedCost", { precision: 10, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeeklyMeal = typeof weeklyMeals.$inferSelect;
export type InsertWeeklyMeal = typeof weeklyMeals.$inferInsert;

/**
 * Ingredients for weekly meals
 */
export const mealIngredients = mysqlTable("mealIngredients", {
  id: int("id").autoincrement().primaryKey(),
  mealId: int("mealId").notNull().references(() => weeklyMeals.id, { onDelete: "cascade" }),
  productId: int("productId").references(() => products.id, { onDelete: "set null" }),
  ingredientName: varchar("ingredientName", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 50 }).notNull(), // kg, g, ml, l, cups, tbsp, etc
  estimatedPrice: decimal("estimatedPrice", { precision: 10, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MealIngredient = typeof mealIngredients.$inferSelect;
export type InsertMealIngredient = typeof mealIngredients.$inferInsert;

/**
 * Weekly shopping lists generated from meal plans
 */
export const weeklyShoppingLists = mysqlTable("weeklyShoppingLists", {
  id: int("id").autoincrement().primaryKey(),
  planId: int("planId").notNull().references(() => weeklyPlans.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  totalItems: int("totalItems").default(0).notNull(),
  estimatedCost: decimal("estimatedCost", { precision: 10, scale: 2 }),
  checkedItems: int("checkedItems").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeeklyShoppingList = typeof weeklyShoppingLists.$inferSelect;
export type InsertWeeklyShoppingList = typeof weeklyShoppingLists.$inferInsert;

/**
 * Items in weekly shopping lists
 */
export const weeklyShoppingItems = mysqlTable("weeklyShoppingItems", {
  id: int("id").autoincrement().primaryKey(),
  listId: int("listId").notNull().references(() => weeklyShoppingLists.id, { onDelete: "cascade" }),
  productId: int("productId").references(() => products.id, { onDelete: "set null" }),
  itemName: varchar("itemName", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 50 }).notNull(),
  category: varchar("category", { length: 100 }),
  estimatedPrice: decimal("estimatedPrice", { precision: 10, scale: 2 }),
  bestStore: varchar("bestStore", { length: 100 }),
  isChecked: int("isChecked").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeeklyShoppingItem = typeof weeklyShoppingItems.$inferSelect;
export type InsertWeeklyShoppingItem = typeof weeklyShoppingItems.$inferInsert;

/**
 * Meal plan templates for quick planning
 */
export const mealTemplates = mysqlTable("mealTemplates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }).notNull(), // vegan, keto, budget-friendly, quick-meals, etc
  difficulty: varchar("difficulty", { length: 50 }).notNull(), // easy, medium, hard
  prepTime: int("prepTime"), // minutes
  servings: int("servings").default(4).notNull(),
  estimatedCost: decimal("estimatedCost", { precision: 10, scale: 2 }),
  ingredients: text("ingredients"), // JSON array of ingredients
  instructions: text("instructions"),
  isPublic: int("isPublic").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MealTemplate = typeof mealTemplates.$inferSelect;
export type InsertMealTemplate = typeof mealTemplates.$inferInsert;


/**
 * Price alerts for users to track price drops
 */
export const priceAlerts = mysqlTable("price_alerts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  productId: int("productId").notNull().references(() => products.id, { onDelete: "cascade" }),
  targetPrice: int("targetPrice").notNull(), // Stored in cents
  alertType: mysqlEnum("alertType", ["below_price", "on_sale", "price_drop"]).default("below_price").notNull(),
  isActive: int("isActive").default(1).notNull(),
  notificationsSent: int("notificationsSent").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PriceAlert = typeof priceAlerts.$inferSelect;
export type InsertPriceAlert = typeof priceAlerts.$inferInsert;

/**
 * History of price alert notifications
 */
export const priceAlertHistory = mysqlTable("price_alert_history", {
  id: int("id").autoincrement().primaryKey(),
  alertId: int("alertId").notNull().references(() => priceAlerts.id, { onDelete: "cascade" }),
  productId: int("productId").notNull().references(() => products.id, { onDelete: "cascade" }),
  storeName: varchar("storeName", { length: 100 }).notNull(),
  priceAtAlert: int("priceAtAlert").notNull(), // Stored in cents
  targetPrice: int("targetPrice").notNull(), // Stored in cents
  savings: int("savings"), // Stored in cents
  notificationSent: int("notificationSent").default(0).notNull(),
  sentAt: timestamp("sentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PriceAlertHistory = typeof priceAlertHistory.$inferSelect;
export type InsertPriceAlertHistory = typeof priceAlertHistory.$inferInsert;


/**
 * In-app notifications for users
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: mysqlEnum("type", ["price_drop", "list_shared", "deal_alert", "system"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  productId: int("productId").references(() => products.id, { onDelete: "set null" }),
  relatedData: json("relatedData"), // Additional context: {oldPrice, newPrice, storeName, etc}
  isRead: int("isRead").default(0).notNull(),
  actionUrl: varchar("actionUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  readAt: timestamp("readAt"),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Shopping list sharing and collaboration
 */
export const shoppingListShares = mysqlTable("shoppingListShares", {
  id: int("id").autoincrement().primaryKey(),
  listId: int("listId").notNull().references(() => shoppingLists.id, { onDelete: "cascade" }),
  ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
  sharedWithUserId: int("sharedWithUserId").references(() => users.id, { onDelete: "cascade" }),
  shareToken: varchar("shareToken", { length: 64 }).unique(), // For public/link sharing
  permission: mysqlEnum("permission", ["view", "edit"]).default("view").notNull(),
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ShoppingListShare = typeof shoppingListShares.$inferSelect;
export type InsertShoppingListShare = typeof shoppingListShares.$inferInsert;

/**
 * Price drop detection history for analytics
 */
export const priceDropHistory = mysqlTable("priceDropHistory", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull().references(() => products.id, { onDelete: "cascade" }),
  storeName: varchar("storeName", { length: 100 }).notNull(),
  previousPrice: int("previousPrice").notNull(),
  currentPrice: int("currentPrice").notNull(),
  percentageDrop: decimal("percentageDrop", { precision: 5, scale: 2 }).notNull(),
  amountSaved: int("amountSaved").notNull(),
  notificationsSent: int("notificationsSent").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PriceDropHistory = typeof priceDropHistory.$inferSelect;
export type InsertPriceDropHistory = typeof priceDropHistory.$inferInsert;

/**
 * Web scraping job logs for monitoring
 */
export const scrapingLogs = mysqlTable("scrapingLogs", {
  id: int("id").autoincrement().primaryKey(),
  storeName: varchar("storeName", { length: 100 }).notNull(),
  jobType: mysqlEnum("jobType", ["price_scrape", "image_scrape", "facebook_scrape"]).notNull(),
  status: mysqlEnum("status", ["pending", "running", "success", "failed"]).notNull(),
  itemsProcessed: int("itemsProcessed").default(0).notNull(),
  itemsSuccessful: int("itemsSuccessful").default(0).notNull(),
  itemsFailed: int("itemsFailed").default(0).notNull(),
  errorMessage: text("errorMessage"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  durationMs: int("durationMs"),
});

export type ScrapingLog = typeof scrapingLogs.$inferSelect;
export type InsertScrapingLog = typeof scrapingLogs.$inferInsert;
