DROP TABLE `notifications`;--> statement-breakpoint
DROP TABLE `priceDropHistory`;--> statement-breakpoint
DROP TABLE `scrapingLogs`;--> statement-breakpoint
DROP TABLE `shoppingListShares`;