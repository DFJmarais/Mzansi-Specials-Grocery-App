CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('price_drop','list_shared','deal_alert','system') NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`productId` int,
	`relatedData` json,
	`isRead` int NOT NULL DEFAULT 0,
	`actionUrl` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`readAt` timestamp,
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `priceDropHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productId` int NOT NULL,
	`storeName` varchar(100) NOT NULL,
	`previousPrice` int NOT NULL,
	`currentPrice` int NOT NULL,
	`percentageDrop` decimal(5,2) NOT NULL,
	`amountSaved` int NOT NULL,
	`notificationsSent` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `priceDropHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `scrapingLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`storeName` varchar(100) NOT NULL,
	`jobType` enum('price_scrape','image_scrape','facebook_scrape') NOT NULL,
	`status` enum('pending','running','success','failed') NOT NULL,
	`itemsProcessed` int NOT NULL DEFAULT 0,
	`itemsSuccessful` int NOT NULL DEFAULT 0,
	`itemsFailed` int NOT NULL DEFAULT 0,
	`errorMessage` text,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`durationMs` int,
	CONSTRAINT `scrapingLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shoppingListShares` (
	`id` int AUTO_INCREMENT NOT NULL,
	`listId` int NOT NULL,
	`ownerId` int NOT NULL,
	`sharedWithUserId` int,
	`shareToken` varchar(64),
	`permission` enum('view','edit') NOT NULL DEFAULT 'view',
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shoppingListShares_id` PRIMARY KEY(`id`),
	CONSTRAINT `shoppingListShares_shareToken_unique` UNIQUE(`shareToken`)
);
--> statement-breakpoint
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `priceDropHistory` ADD CONSTRAINT `priceDropHistory_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `shoppingListShares` ADD CONSTRAINT `shoppingListShares_listId_shoppingLists_id_fk` FOREIGN KEY (`listId`) REFERENCES `shoppingLists`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `shoppingListShares` ADD CONSTRAINT `shoppingListShares_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `shoppingListShares` ADD CONSTRAINT `shoppingListShares_sharedWithUserId_users_id_fk` FOREIGN KEY (`sharedWithUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;