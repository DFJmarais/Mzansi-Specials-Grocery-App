CREATE TABLE `mealIngredients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`mealId` int NOT NULL,
	`productId` int,
	`ingredientName` varchar(255) NOT NULL,
	`quantity` decimal(10,2) NOT NULL,
	`unit` varchar(50) NOT NULL,
	`estimatedPrice` decimal(10,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mealIngredients_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mealTemplates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100) NOT NULL,
	`difficulty` varchar(50) NOT NULL,
	`prepTime` int,
	`servings` int NOT NULL DEFAULT 4,
	`estimatedCost` decimal(10,2),
	`ingredients` text,
	`instructions` text,
	`isPublic` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mealTemplates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weeklyMeals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`planId` int NOT NULL,
	`dayOfWeek` int NOT NULL,
	`mealType` varchar(50) NOT NULL,
	`mealName` varchar(255) NOT NULL,
	`description` text,
	`servings` int NOT NULL DEFAULT 1,
	`estimatedCost` decimal(10,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weeklyMeals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weeklyPlans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`startDate` date NOT NULL,
	`endDate` date NOT NULL,
	`budget` decimal(10,2),
	`estimatedTotal` decimal(10,2),
	`actualTotal` decimal(10,2),
	`isCompleted` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weeklyPlans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weeklyShoppingItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`listId` int NOT NULL,
	`productId` int,
	`itemName` varchar(255) NOT NULL,
	`quantity` decimal(10,2) NOT NULL,
	`unit` varchar(50) NOT NULL,
	`category` varchar(100),
	`estimatedPrice` decimal(10,2),
	`bestStore` varchar(100),
	`isChecked` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weeklyShoppingItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weeklyShoppingLists` (
	`id` int AUTO_INCREMENT NOT NULL,
	`planId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`totalItems` int NOT NULL DEFAULT 0,
	`estimatedCost` decimal(10,2),
	`checkedItems` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weeklyShoppingLists_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `mealIngredients` ADD CONSTRAINT `mealIngredients_mealId_weeklyMeals_id_fk` FOREIGN KEY (`mealId`) REFERENCES `weeklyMeals`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mealIngredients` ADD CONSTRAINT `mealIngredients_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `weeklyMeals` ADD CONSTRAINT `weeklyMeals_planId_weeklyPlans_id_fk` FOREIGN KEY (`planId`) REFERENCES `weeklyPlans`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `weeklyPlans` ADD CONSTRAINT `weeklyPlans_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `weeklyShoppingItems` ADD CONSTRAINT `weeklyShoppingItems_listId_weeklyShoppingLists_id_fk` FOREIGN KEY (`listId`) REFERENCES `weeklyShoppingLists`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `weeklyShoppingItems` ADD CONSTRAINT `weeklyShoppingItems_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `weeklyShoppingLists` ADD CONSTRAINT `weeklyShoppingLists_planId_weeklyPlans_id_fk` FOREIGN KEY (`planId`) REFERENCES `weeklyPlans`(`id`) ON DELETE cascade ON UPDATE no action;