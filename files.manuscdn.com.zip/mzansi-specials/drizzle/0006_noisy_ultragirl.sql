CREATE TABLE `price_alert_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`alertId` int NOT NULL,
	`productId` int NOT NULL,
	`storeName` varchar(100) NOT NULL,
	`priceAtAlert` int NOT NULL,
	`targetPrice` int NOT NULL,
	`savings` int,
	`notificationSent` int NOT NULL DEFAULT 0,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `price_alert_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `price_alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productId` int NOT NULL,
	`targetPrice` int NOT NULL,
	`alertType` enum('below_price','on_sale','price_drop') NOT NULL DEFAULT 'below_price',
	`isActive` int NOT NULL DEFAULT 1,
	`notificationsSent` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `price_alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `priceVerificationLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`priceId` int NOT NULL,
	`productId` int NOT NULL,
	`previousPrice` int,
	`newPrice` int,
	`previousTrustScore` int,
	`newTrustScore` int,
	`changeReason` varchar(255),
	`verifiedBy` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `priceVerificationLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
DROP TABLE `priceAlerts`;--> statement-breakpoint
ALTER TABLE `prices` ADD `trustScore` int DEFAULT 100 NOT NULL;--> statement-breakpoint
ALTER TABLE `prices` ADD `trustLevel` enum('HIGH','MEDIUM','LOW') DEFAULT 'MEDIUM' NOT NULL;--> statement-breakpoint
ALTER TABLE `prices` ADD `verificationStatus` enum('VERIFIED','UNVERIFIED','FLAGGED') DEFAULT 'UNVERIFIED' NOT NULL;--> statement-breakpoint
ALTER TABLE `prices` ADD `sourcesCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `prices` ADD `sources` json;--> statement-breakpoint
ALTER TABLE `prices` ADD `flags` json;--> statement-breakpoint
ALTER TABLE `prices` ADD `lastVerified` timestamp;--> statement-breakpoint
ALTER TABLE `price_alert_history` ADD CONSTRAINT `price_alert_history_alertId_price_alerts_id_fk` FOREIGN KEY (`alertId`) REFERENCES `price_alerts`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `price_alert_history` ADD CONSTRAINT `price_alert_history_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `price_alerts` ADD CONSTRAINT `price_alerts_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `price_alerts` ADD CONSTRAINT `price_alerts_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `priceVerificationLogs` ADD CONSTRAINT `priceVerificationLogs_priceId_prices_id_fk` FOREIGN KEY (`priceId`) REFERENCES `prices`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `priceVerificationLogs` ADD CONSTRAINT `priceVerificationLogs_productId_products_id_fk` FOREIGN KEY (`productId`) REFERENCES `products`(`id`) ON DELETE cascade ON UPDATE no action;