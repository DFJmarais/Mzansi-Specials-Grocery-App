-- Subscription tiers table
CREATE TABLE IF NOT EXISTS subscription_tiers (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,
  price_rands DECIMAL(10, 2) NOT NULL,
  billing_cycle VARCHAR(20) NOT NULL,
  features JSON NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User subscriptions table
CREATE TABLE IF NOT EXISTS user_subscriptions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  tier_id INT NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'active',
  started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP,
  auto_renew BOOLEAN DEFAULT TRUE,
  app_store_receipt VARCHAR(1000),
  google_play_receipt VARCHAR(1000),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES user(id),
  FOREIGN KEY (tier_id) REFERENCES subscription_tiers(id),
  INDEX idx_user_id (user_id),
  INDEX idx_status (status)
);

-- Subscription history for audit trail
CREATE TABLE IF NOT EXISTS subscription_history (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  tier_id INT NOT NULL,
  action VARCHAR(50) NOT NULL,
  previous_tier_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES user(id),
  FOREIGN KEY (tier_id) REFERENCES subscription_tiers(id),
  INDEX idx_user_id (user_id)
);

-- Insert default subscription tiers
INSERT INTO subscription_tiers (name, price_rands, billing_cycle, features) VALUES
('Free', 0, 'free', '{"products": 50, "search": true, "price_alerts": false, "shopping_lists": false, "barcode_scanning": false, "receipt_ocr": false}'),
('Plus', 19.99, 'monthly', '{"products": 1500, "search": true, "price_alerts": true, "shopping_lists": true, "barcode_scanning": true, "receipt_ocr": false}'),
('Pro', 49.99, 'monthly', '{"products": 1500, "search": true, "price_alerts": true, "shopping_lists": true, "barcode_scanning": true, "receipt_ocr": true, "analytics": true, "priority_support": true}');
