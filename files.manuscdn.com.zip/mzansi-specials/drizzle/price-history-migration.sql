-- Create price history table for tracking price trends
CREATE TABLE IF NOT EXISTS price_history (
  id VARCHAR(191) PRIMARY KEY,
  productId VARCHAR(191) NOT NULL,
  storeName VARCHAR(255) NOT NULL,
  price INT NOT NULL,
  recordedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_product_store (productId, storeName),
  INDEX idx_recorded_at (recordedAt)
);

-- Seed initial price history from current prices (7 days ago)
INSERT INTO price_history (id, productId, storeName, price, recordedAt, createdAt)
SELECT 
  CONCAT(p.id, '-', pr.storeName, '-', DATE_SUB(NOW(), INTERVAL 6 DAY)),
  p.id,
  pr.storeName,
  ROUND(pr.price * (0.98 + RAND() * 0.04)),
  DATE_SUB(NOW(), INTERVAL 6 DAY),
  DATE_SUB(NOW(), INTERVAL 6 DAY)
FROM prices pr
JOIN products p ON pr.productId = p.id
WHERE NOT EXISTS (
  SELECT 1 FROM price_history WHERE price_history.productId = p.id AND price_history.storeName = pr.storeName
);

-- Add more historical data points (5 days ago)
INSERT INTO price_history (id, productId, storeName, price, recordedAt, createdAt)
SELECT 
  CONCAT(p.id, '-', pr.storeName, '-', DATE_SUB(NOW(), INTERVAL 5 DAY)),
  p.id,
  pr.storeName,
  ROUND(pr.price * (0.98 + RAND() * 0.04)),
  DATE_SUB(NOW(), INTERVAL 5 DAY),
  DATE_SUB(NOW(), INTERVAL 5 DAY)
FROM prices pr
JOIN products p ON pr.productId = p.id
LIMIT 5000;

-- Add historical data (3 days ago)
INSERT INTO price_history (id, productId, storeName, price, recordedAt, createdAt)
SELECT 
  CONCAT(p.id, '-', pr.storeName, '-', DATE_SUB(NOW(), INTERVAL 3 DAY)),
  p.id,
  pr.storeName,
  ROUND(pr.price * (0.99 + RAND() * 0.02)),
  DATE_SUB(NOW(), INTERVAL 3 DAY),
  DATE_SUB(NOW(), INTERVAL 3 DAY)
FROM prices pr
JOIN products p ON pr.productId = p.id
LIMIT 5000;

-- Add historical data (1 day ago)
INSERT INTO price_history (id, productId, storeName, price, recordedAt, createdAt)
SELECT 
  CONCAT(p.id, '-', pr.storeName, '-', DATE_SUB(NOW(), INTERVAL 1 DAY)),
  p.id,
  pr.storeName,
  pr.price,
  DATE_SUB(NOW(), INTERVAL 1 DAY),
  DATE_SUB(NOW(), INTERVAL 1 DAY)
FROM prices pr
JOIN products p ON pr.productId = p.id
LIMIT 5000;
